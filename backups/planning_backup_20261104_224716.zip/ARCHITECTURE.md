# Architecture

A map of what lives where. The app is a single Tkinter desktop app. Modules
are grouped into folders by role, so a new contributor (or future-you) can
tell what a file does from its path alone, and every import is a plain
`from <folder>.<module> import ...` with no root-level clutter.

## Layout

```
main.py                 entry point

gui/                     Tkinter UI: windows, tabs, widgets
  gui.py                 main window, notebook, cross-tab wiring
  workflows/             Purchase Orders, Bolla, and Elvy Invoice workflows
  modern_widgets.py       shared custom widgets (RoundedButton, ...)
  tabs/                   one file per notebook tab, plus focused mixins for
                          shared-order dialogs/actions and Situazione sources/
                          refresh workflows

calculate/               pure business logic, no Tkinter
  situazione.py           Copertura / machine-queue / compute_situation
  situazione_settimana.py
  magazino.py, lotti.py, prezzi.py
  abbina_calculator.py, abbina_suggestions.py
  constants.py            shared machine capacity/code tables

parsers/                 read a specific file shape into a dataframe/rows
  pdf_parser.py, bolla_parser.py, elvy_invoice_parser.py, kamal_parser.py
  dfm_lookup.py, prod_lookup.py, situazione_loaders.py, elvy_mapping.py

exporters/               write Excel/Word output
  excel_exporter.py, bolla_exporter.py, elvy_invoice_exporter.py
  kamal_excel_exporter.py, biglietti_exporter.py

pipelines/               customer-specific "raw order -> ticket/workbook" flows
  ordine_kamal.py, ordine_med.py, ordini_elvy.py
  master_import.py        "load everything from one folder" for Overview

utility/                 shared infra: generic helpers, path/file caches, db
  utils.py, path_manager.py, file_cache.py
  articoli_cache.py, densita_cache.py, lotti_cache.py, magazino_cache.py,
  prezzi_cache.py
  situazione_db.py        SQLite-backed upload log + Articolo->TITOLO table
  notifications.py        persisted, deduplicated application notifications
  master_data.py          local JSON reference data (temporary, not central DB)

tests/                   regression tests (pytest/unittest)
```

## Notifications

The main window has a global `Notifications` button. Notices are stored in
`settings/notifications.json`, deduplicated by key, and remain visible until
the user marks them resolved. The notification window shows severity, title,
page, message, and creation time.

`Ordine > Ordine Med` creates a high-severity notice after conversion when an
article required by `Filato X Tinturia` is missing from `Magazino Filato`.
The notice lists the missing article codes so the operator can upload or fix
the Magazino source. `Situazione Generale` also compares the displayed color
price against `Prezzi` using `Articolo + Codice`; missing matches and existing
price differences become notifications. The machine surcharge rule is applied
for both capacity values `24/32/56` and machine numbers `12/9/10`: add $2 to
the Listini price.

## Master Data (local phase)

The `Master Data` tab intentionally contains only the two manually maintained
tables that are useful globally: `Customers` and `Machines`. Machines use the
fields `Code`, `Number`, and `Rocche`; for example `3307 - 7 - 72`. The seeded
machine registry is loaded by `calculate/constants.py` and supplies the
machine-code, machine-number, and capacity mappings used by planning logic.
Article files remain managed through their dedicated upload flow, and the
G/C article-prefix rule remains business logic rather than a separate table.
Changes are saved in `settings/master_data.json` and are picked up on the
next application start.

## SQLite-first source architecture

SQLite is the local runtime source of truth. Excel workbooks are **import/update inputs only**. After a successful upload, normalized data is persisted as a SQLite snapshot and runtime consumers restore that snapshot after restart. The original workbook path is metadata and is not required for normal operation.

When a workbook is uploaded again, its normalized fingerprint is compared with the stored snapshot. Identical data keeps the existing snapshot and can show a "No changes" warning; changed data replaces the snapshot. File-path fallback exists only to migrate installations that predate SQLite snapshots.

## Local SQLite persistence

`utility/situazione_db.py` owns the normalized source snapshots, upload metadata, and operational state. Shared sources such as DFM, Articoli, Listini, Densita, Magazino, LOTTI, Produzione, Copertura, Wincoint, Uscita, and Qualita are restored from SQLite on startup. `utility/source_manager.py` is the small runtime facade used by cross-tab consumers.

The old `*_cache.py` files remain as compatibility metadata stores (last filename/path and migration support); they are not the runtime data source. `settings/`, `cache/`, and source workbook paths may disappear without invalidating an already-imported snapshot.

Packaging/build tooling stays at the repo root since it isn't application
code: `main.spec`, `build.bat`, `installer.iss`, `requirements.txt`,
`runtime_hook.py`, `sync_venv_packages.py`, `icon.ico`, plus the two
standalone smoke-test scripts `test_startup.py` / `test_update.py` (these
are manual scripts, not part of the `tests/` pytest package).

### Import rule
New code imports from these packages directly — `from calculate.situazione
import ...`, `from utility.utils import ...`, etc. There are no more
root-level `*_tab.py` / `*_logic.py` compatibility shims: the folder reorg
finished the migration that this file previously described as in-progress,
so every caller now points straight at the canonical module. If you're
looking at an old note/branch that still says `import situazione_logic` or
`import ui.tabs...`, update it to `import calculate.situazione` /
`import gui.tabs...`.

### Maintenance map
- `gui/tabs/` — Tkinter widgets, event handlers, and rendering only.
- `calculate/*.py` — pure dataframe/business rules and calculations.
- `parsers/*.py` — input normalization and validation.
- `exporters/*.py` — Excel, Word, and PDF output.
- `utility/*_cache.py`, `utility/file_cache.py`, `utility/path_manager.py` —
  persisted source paths and shared cache state.
- `pipelines/master_import.py` — orchestration boundary for folder/master-file
  imports; it may call tab adapters but should not contain business
  calculations.

## Business logic (`calculate/`)
Pure(ish) computation, no Tkinter: `calculate/situazione.py` (Copertura,
machine-queue scheduling, `compute_situation`), `calculate/magazino.py`,
`calculate/prezzi.py`, `calculate/lotti.py`. These take dataframes/paths in,
return dataframes/values out — safe to unit-test without a display.

## Loaders / parsers (`parsers/`)
Read a specific file shape into a dataframe or a list of dataclass rows:
`situazione_loaders.py` (DFM/Copertura/Produzione/Wincoint/Uscita/
Qualita/Articoli), `pdf_parser.py` (the Elvy PO PDF), `dfm_lookup.py`,
`prod_lookup.py`.

## Customer-specific pipelines (`pipelines/`)
Each customer's "raw order -> ticket/workbook" flow is one module:
- `exporters/biglietti_exporter.py` — ELVY / MED / EL KAMAL dyeing tickets
  (Biglietti) + their Excel workbook. `load_order`/`load_el_kamal_order`
  parse, `enrich_records` fills in Titolo/M-C/KG/Prezzo/etc.,
  `export_workbook`/`export_word` write the output.
- `pipelines/ordine_med.py` — the "Ordine da creare" / Filato-availability
  extraction (separate from Biglietti; different source shape).
- `pipelines/ordini_elvy.py` — the ERP-import "Ordini ELVY" sheet built from
  PDF orders.
- `pipelines/ordine_kamal.py` / `exporters/kamal_excel_exporter.py` — the
  older Kamal-specific PDF pipeline (predates `biglietti_exporter.py`'s own
  EL KAMAL support; kept for its own tab, not merged in).

Each pipeline module owns its own field-normalization helpers
(`_clean`/`_key`/`_number`/`_read_sheet_rows`) rather than sharing one
"utils" grab-bag — they're one-liners, and duplicating them keeps each
module's logic self-contained.

## Centralized source paths (`utility/path_manager.py` + `utility/file_cache.py`)
`path_manager.py` is the canonical registry for every shared source name used
by the pages and by Overview's bulk import. It normalizes aliases such as
`data_prod`/`produzione` and `listini`/`prezzi`, while `file_cache.py` remains
the single JSON persistence implementation. Individual `*_cache.py` modules
are thin wrappers, so uploads from any page resolve to the same stored path
and survive application restarts. Data Ordine and Dispo-Bagno are also
recorded centrally for Biglietti and Ordine MED.

## "Where was that file last uploaded" caches (`utility/*_cache.py`)
One JSON file per source (`settings/<key>_file_cache.json`) remembering
the last path used, so re-opening the app or switching tabs doesn't
require re-browsing. All of them are thin wrappers around
`file_cache.py`'s `save_file_cache(key, path)` / `load_file_cache(key)`
— the actual read/write logic lives in exactly one place. Add a new
cached source by adding a new few-line wrapper in the same shape, not by
extending `file_cache.py` itself. Note: Ordine MED's raw-yarn
availability check reuses `magazino_cache.py` (the same shared Magazino
Filato source as Ordine Elvy/Ordine Kamal/Situazione/Magazino Filato) —
there is no separate "Filato Disponibile" cache; that file shape is the
same as Magazino's own export.

## Cross-tab / bulk import
- `pipelines/master_import.py` — "load everything from one folder/file" for
  Overview: matches files by name (falling back to content-sniffing for
  Data Ordine/Dispo-Bagno, which have no stable filename), routes each to
  the same handler its own tab's upload button uses.
- `utility/situazione_db.py` — SQLite persistence for normalized source snapshots,
  upload metadata, situation state, and the shared Articolo->TITOLO codes table.
- `utility/source_manager.py` — shared snapshot lifecycle, freshness checks, and
  process-local memoization so a source is not decoded from SQLite repeatedly.

`Ordine MED` selects an output directory (rather than a file) and writes
`Ordine_MED.xlsx`. Its ERP panel follows the Ordine Kamal pattern: separate
ERP and Filato folder rows, each with its own extraction checkbox. The ERP
checkbox writes `Ordine_MED_ERP.xlsx`; the Filato checkbox writes a standalone
`Filato X Tinturia.xlsx`; the combined workbook remains unchanged.

`Ordine MED` also writes `Prezzi.xlsx` (sheet `MED`: Riga, ARTICOLO, TITOLO,
COLORE, Q.TA, DESCR COL, LIVELLO, M/C, PREZZO, prezzo + (2$)) next to
`Ordine_MED.xlsx`.  Its Commento follows `pipelines.ordine_med.pg_token`: a PT GRG
that starts with 1 is one of our raw batches (`PG-159233-PM...`); any other number is
the MED customer's lot (`PG-X(837756)-PM...`); blank is `PG-X-PM...`.
`calculate/raw_batch.py` is the single definition of that rule: in Create
(EXCEL+Biglietti) a MED row gets Partita GG only from its comment (never from the raw
sheet).  A customer lot whose number does not start with `1` remains visible and its
KG/VMM22/Densita/Color Tube values can be looked up, but it waits in PG-X and is never
included in Filato x Tinturia.  Smart Auto-Assign takes the lot from the comment (or from a lot typed in
Partita GG) to find the stock, and "Print Assigned PG-X" prints only rows holding one of
our batches.  The Create page never deletes earlier orders' files, and no
`.previous` copy is written unless `safe_save_workbook(..., keep_backup=True)` asks.

`Ordine Elvy` writes `Prezzi-PO-<POD No>.xlsx` (`Prezzi-PO-1500 & 1501.xlsx` when
the lines belong to several POs) next to its order Excel -- one per PDF, or one for the
merged workbook.  It is the same sheet as Ordine MED's Prezzi (`exporters/prezzi_workbook.py`
holds the layout; `pipelines/prezzi_elvy.py` turns PO lines into rows, with M/C taken from
the Abbina and the +2$ surcharge from `apply_machine_surcharge`).

Create (EXCEL+Biglietti) names its files per customer without the word "Biglietti":
ELVY `<stem>.xlsx` / `<stem>.docx` (/ `<stem>-pg-x.docx`), where the stem is built from the
values of the Excel's Commento column (`_elvy_file_stem`: `PO-1500-2026`, several POs
`PO-1500 & 1501-2026`, `ELVY` when there is none); MED `<stem>_MED.xlsx` / `<stem>_MED.docx`;
EL KAMAL `<excel stem>_EL_KAMAL.xlsx` / `<ticket stem>.docx`.

Pages.  "Biglietti" (`gui/tabs/biglietti_tab.py`) has one tab per customer -- ELVY, MED,
EL KAMAL -- each with its own inputs, ticket template, output folders, e-mail actions and
Convert button.  A conversion handles ONE customer: `pipelines/create_conversion.py` (no Tk)
reads that customer's rows, writes its workbook / tickets (ELVY and MED also a Filato file --
`Filato x Tinturia <customer>.xlsx`, one per customer because the three tabs share one Filato
folder -- and their rows of the Show Orders workbook) and never touches another customer's
files.  "Shared Orders" (`gui/tabs/show_orders_tab.py`, right after Overview) is a page of its
own for the Show Orders workbook; converting ELVY or MED without one chosen shows a warning
and opens that page (EL KAMAL does not use the workbook; "Create New" only picks the place,
the file is written by the first conversion).  Values shown on all three tabs (folders, status)
are kept in step through `_dir_labels` / `_status_labels`.

Ordine Elvy raw yarn.  The PDF's `Lot :` text is the row's customer lot (empty when nothing
follows it).  `match_raw_yarn(..., lotti_summary=...)` looks the lot up in Magazino Filato
first (`match_by_lot`: the Lotti file gives partita <-> lotto, the batch must be the row's
raw article), then by article; rows neither finds keep `PG-X(<lot>)` (or plain `PG-X`) in
their Commento, followed by `-PO-<n>-<year>`.  Those rows behave like MED's customer-lot
rows (`calculate/raw_batch.py`): Biglietti shows the lot in Partita GG, keeps it out of
Filato x Tinturia, files the row under PG-X, Smart Auto-Assign looks the lot up and "Print
Assigned PG-X" skips it; Situazione colours a `PG-X(<lot>)` row red when no batch of the lot
was found.  A customer lot is anything that is not one of our batches (digits starting
with 1): numbers for MED, numbers and letters for ELVY.

The Overview's ticket and machine tables (`gui/tree_fit.py`) size every column to its
data (capped, the spare width shared equally, centred), alternate two row colours, format their rows once, search through a pre-computed text per row with a
150 ms debounce, and scroll horizontally.  `find_price_anomalies` reads columns as plain
lists (it used to build a pandas Series per row: ~0.6 s per 4,000 rows, on the UI thread).

`Situazione Generale` also runs a background synchronization pass for every
shared source (Copertura, WINCOINT, Uscita, Qualita, Articoli, Listini, DFM,
and Produzione). A successful upload from another page invokes the same pass,
so the file is read into the correct page state instead of merely displaying a
saved filename.

## Dev-mode data location (`utility/utils.py`)
`APP_DATA_DIR` decides where `logs/`, `settings/`, and the Situazione SQLite
file live. When frozen (PyInstaller build) it uses the per-user AppData
folder; when running from source it uses "the folder next to this file" —
which, since `utils.py` sits one level under the project root now
(`utility/utils.py`), is computed as `Path(__file__).resolve().parent.parent`
so dev-mode data keeps landing at the repo root, exactly as it did before the
folder reorg. If `utility/utils.py` ever moves again, update that parent
count to match its new depth.

## Packaging
`main.spec` (PyInstaller) + `requirements.txt` + `installer.iss` (Inno
Setup) + `build.bat`. `pathex=['.']` plus PyInstaller's import-following
analysis means the `gui/`, `calculate/`, `parsers/`, `exporters/`,
`pipelines/`, `utility/` packages need no extra spec changes — PyInstaller
discovers them the same way it always discovered `ui/`/`logic/`. When a
module gains a new third-party import, add it to `requirements.txt` and, if
PyInstaller's static analysis won't find it on its own (dynamic imports, C
extensions), to `extra_hiddenimports` in `main.spec` too. `build.bat` reuses
an existing `venv` in place: it calls `venv\Scripts\python.exe` by full path
(never `activate.bat`/`pip.exe`, which hard-code the folder the venv was created
in) and runs `sync_venv_packages.py --sync`, which does nothing when
`requirements.txt` is unchanged and every package is present, and otherwise
removes what is no longer listed and installs only what is new.  The venv is
recreated only when its `python.exe` is missing or cannot run.

Build speed: `main.spec` tells `collect_all()` up front to skip every package's
test suite, conftest files, `numpy.f2py` and the matplotlib backend
(`filter_submodules` / `exclude_datas`), so those modules are neither imported
while the spec is evaluated nor analysed nor copied into `dist\` (pandas and numpy
ship about 1,600 test files).  UPX is off.  `build.bat` keeps `build\` (PyInstaller's
analysis cache -- keep that folder too when replacing the project files), no longer
passes `--clean`, and creates the release ZIP only on request (`build.bat zip`; the
in-app updater downloads a ZIP from the GitHub release).

## Number/text parsing (deliberately NOT consolidated)
`biglietti_exporter._clean`/`_number`, `utils.clean_text`/`parse_number`,
`abbina_suggestions._number`, and `elvy_invoice_parser._parse_number`
(which already just wraps `utils.parse_number`) look like duplicates at
a glance, but they aren't behaviorally identical: `utils.parse_number`
disambiguates thousands-vs-decimal separators for the general case
("1,234.56" vs "1.234,56"), while `biglietti_exporter._number` and
`abbina_suggestions._number` take the simpler, deliberate assumption
that a comma is always a decimal separator (correct for the real
Italian/Egyptian ERP exports Biglietti/Ordine MED parse, which use
comma-decimals without thousands separators) and differ from each other
in their None-vs-0.0 failure return. Merging any of these would risk
silently changing parsed values across pipelines that are already
verified against real data -- if you're looking at this thinking "these
should be one function," they were considered and kept apart on purpose.


## Runtime data lifecycle

- Excel uploads are parsed by `parsers/` and business rules live in `calculate/`.
- Normalized runtime sources and operational state are persisted in SQLite (`utility/situazione_db.py`).
- File-location caches are lightweight JSON metadata under the per-user AppData directory; they remember selected paths but are not the canonical data store.
- DFM is SQLite-backed like the other normalized sources. A fresh DFM upload replaces the stored normalized snapshot and its customer-prefix lookups; restart restores the snapshot without requiring the workbook.
- Listini category resolution follows: manual/reference category -> explicit Listini Customer/Marca when present -> article-prefix customer + Articoli Marca (only when Articoli has a Marca for the article; otherwise it stays unplaced rather than joining a bare `MED -` category) -> peer inference/review. Everything that feeds `CATEGORY` (reference map, manual overrides, the Articoli file) is part of `prezzi.category_sources_fingerprint()`, which every cache of categorised data must include in its key.
- UI refresh notifications are debounced so a burst of shared-source changes produces one sync pass.

## SQLite-first source persistence (v1.1.5)

Uploaded/normalized source data is persisted as SQLite snapshots. On restart, the application restores the normalized snapshot first and does not require the original Excel workbook to remain at its old path. Re-uploading a source compares the normalized data fingerprint: identical data triggers a warning and keeps the existing snapshot; changed data replaces the snapshot. DFM follows the same rule, including the normalized customer-prefix lookups used by Ordine MED/Kamal.

## Runtime rules added in the 1.1.8 review

- **Lazy pages are imported with `import` statements** (`make_*` factories in `gui/gui.py`), never `__import__("...")`:
  PyInstaller only bundles modules it sees in import statements. `tests/test_runtime_fixes.py` checks this.
- **The scheduled PG-X e-mail report lives in the Create page's constructor.** When the schedule is enabled the page is
  built in the background after first paint (`pgx_schedule_enabled`), otherwise the report would never fire.
- **SQLite snapshots keep their column types** (`source_snapshot.column_meta`): date columns come back as datetimes, so
  `compute_situation` gives the same result from restored frames as from freshly parsed ones. An identical re-upload does
  not rewrite the rows.
- **A snapshot older than its file is not served** (`utility.source_manager.is_current/load`): if the file registered for
  Magazino / Lotti / Listini / Densità / Articoli (path cache) differs from the one the snapshot was built from -- another
  page registered a new file, or today's export overwrote the same file name -- callers fall back to reading the file, which
  refreshes the snapshot. If the workbook is gone the snapshot is trusted (SQLite-first).
- **DFM is read once per upload** (`save_dfm_workbook`): lookups for every customer prefix plus every Articolo/Colore pair
  (`dfm:pairs`, used by Ordine MED's Check Articolo, including rows without CLDESCR and other customers).
- **Startup never opens a modal**: Situazione refreshes at launch only when all six sources are available.


## SQLite performance hardening (v1.1.10)

- New snapshots use pandas' vectorized JSON serializer and one `payload_json` value per source instead of Python-serializing every row into `source_snapshot_row`. Legacy row-wise snapshots are restored with their column/date metadata, then migrated to the compact payload on first read.
- Identical re-uploads update only source metadata when the compact snapshot is already current; they do not rewrite the payload. Content changes replace the snapshot inside a transaction.
- `utility/source_manager.py` caches a defensive in-memory copy keyed by the SQLite content fingerprint. Callers still validate the registered source path and its modification time before serving the cache, so explicit uploads from another page cannot leave old data in use.
- SQLite connection setup uses `busy_timeout`, `synchronous=NORMAL`, and foreign keys on each connection; WAL mode is set by database initialization rather than reissued for every short-lived read connection.
- The reviewed runtime fixes from 1.1.8 remain in place: direct imports for lazy pages (PyInstaller), scheduled PG-X startup, date-dtype restoration, stale-source detection, and DFM Article+Color pair snapshots.

## Merge of 1.1.9, 1.1.10 and the 1.1.8 review (v1.1.11)

- **Background imports are back** (from 1.1.9; 1.1.10 had dropped them): Situazione sources, Articoli, Listini, the
  Settimana page and Lotti parse and save to SQLite on a worker thread; the UI thread only publishes the result. A
  source button is always re-enabled, even if publishing the result fails (`tests/test_background_uploads.py`).
- **The refresh after an upload runs in the background** (`_refresh_after_upload_async`) once all six sources are loaded.
  It behaves like the startup refresh (`preserve_comment_history=True`): stored Old Comm. values are kept; the manual
  Refresh button remains the only thing that advances the comment history (with its confirmation).
- **Data Elvy is a sub-page of Master Data** (`MasterDataTab(extra_pages=[...])`), built together with Master Data on its
  first visit. Its state lives in the page itself and its data in `settings/elvy_mapping.json`, which the Purchase Orders
  conversion reads directly, so nothing needs the page to exist.
- **SQLite snapshots** (1.1.9 payload format + 1.1.10 migration/in-memory reuse + the column types and staleness guard of
  the 1.1.8 review): one compact payload per source; dates restored as datetimes (ISO text, or epoch milliseconds from
  older blobs); identical re-uploads write nothing; a snapshot older than its registered file is not served.
