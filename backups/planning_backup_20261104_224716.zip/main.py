"""
main.py — Entry point for Planning (the Delta Dyeing PDF-to-Excel Converter).

Run with:
    python main.py
"""

from __future__ import annotations

import os
import warnings
from pathlib import Path
import traceback

# Harmless pandas notices (date-format guessing, dtype downcasting) that otherwise
# print dozens of lines in the terminal on every upload.
warnings.filterwarnings("ignore", message="Could not infer format", category=UserWarning)
warnings.filterwarnings("ignore", message="Downcasting object dtype arrays", category=FutureWarning)
warnings.filterwarnings("ignore", message="DataFrameGroupBy.apply operated on the grouping columns", category=FutureWarning)


def _write_startup_error() -> Path | None:
    """Persist a frozen/source startup traceback where the user can retrieve it."""
    try:
        if getattr(os.sys, "frozen", False):
            base = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "Planning"
        else:
            base = Path(__file__).resolve().parent / "logs"
        base.mkdir(parents=True, exist_ok=True)
        path = base / "startup_error.log"
        path.write_text(traceback.format_exc(), encoding="utf-8")
        return path
    except Exception:
        return None


def main() -> None:
    from gui import ConverterApp

    app = ConverterApp()
    app.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        error_path = _write_startup_error()
        try:
            from tkinter import messagebox

            location = f"\n\nسجل الخطأ: {error_path}" if error_path else ""
            messagebox.showerror(
                "Planning - Startup error",
                "تعذر تشغيل البرنامج. راجع سجل الخطأ للحصول على التفاصيل." + location,
            )
        except Exception:
            # The startup error has already been persisted; there may be no
            # usable Tk environment in which to display a dialog.
            pass
