"""
magazino_filato_tab.py
Raw yarn warehouse summary tab ("Magazino Filato"): upload the Magazino
export, apply the filter rules in magazino_logic.py, and show one row per
raw-yarn Partita with its total cones (Mag.rocche) and weight (Mag.peso).
Optionally upload the LOTTI reference too, to add each Partita's Lotto
number (the same reference Kamal calls their raw yarn "message number").
"""
import os
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk, filedialog, messagebox
from typing import Callable
import pandas as pd

from calculate import lotti as lotti_logic
from calculate import magazino as logic
from utility.excel_io import safe_save_workbook
from utility.lotti_cache import load_lotti_cache, save_lotti_cache
from utility.magazino_cache import load_magazino_cache, save_magazino_cache
from utility.utils import logger
from utility.ui_thread import post_to_ui

COLUMNS = ["articolo", "titolo", "partita", "mag_rocche", "mag_peso", "lotto"]
HEADERS = {
    "articolo": "Articolo", "titolo": "Titolo", "partita": "Partita", "mag_rocche": "Mag.rocche",
    "mag_peso": "Mag.peso", "lotto": "Lotto",
}


class MagazinoFilatoTab(ttk.Frame):
    """Embeddable 'Magazino Filato' tab."""

    def __init__(self, master, on_shared_cache_changed: Callable[[], None] | None = None):
        """Create the Magazino Filato page: the Magazino and Lotti frames, the shared-source state and the widgets, then restore the saved sources."""
        super().__init__(master)
        self.magazino_summary = pd.DataFrame()
        self.lotti_summary = pd.DataFrame()
        self._base_df = pd.DataFrame()
        self.summary_df = pd.DataFrame()
        self._shared_path = ""
        self._shared_lotti_path = ""
        self._lotti_syncing = False
        self._syncing = False
        self._uploading = False
        self._on_shared_cache_changed = on_shared_cache_changed
        self._data_revision = 0
        self._search_var = tk.StringVar()
        self._filter_after_id = None
        self.total_available_var = tk.StringVar(value="Totale disponibile: 0 rocche | 0 kg")
        self._sort_column = ""
        self._sort_reverse = False

        self._build_upload_panel()
        self._build_treeview()
        # Use the last normalized summary immediately; the source workbook is
        # still re-read asynchronously below so the cache never blocks startup.
        self._restore_summary_from_cache()
        self.after_idle(self.sync_shared_lotti_async)
        self.after_idle(self.sync_shared_async)

    def _restore_summary_from_cache(self):
        """Restore the normalized Magazino summary from SQLite only."""
        try:
            from utility.source_manager import load as load_source, source_name
            summary = load_source("magazino_summary")
            if summary is not None and not summary.empty:
                required = {"articolo", "partita", "mag_rocche", "mag_peso"}
                if required.issubset(summary.columns):
                    self.magazino_summary = summary.copy()
                    self._base_df = summary.copy()
                    self._shared_path = "sqlite://magazino_summary"
                    self.status_var.set(f"✅ SQLite: {len(summary)} batches - {source_name('magazino_summary')}")
                    self._data_revision += 1
                    self._recompute()
                    return
        except Exception as exc:
            logger.warning("Could not restore Magazino from SQLite: %s", exc)

        # Legacy cache fallback for installations created before SQLite snapshots.
        cache = load_magazino_cache()
        rows = cache.get("summary_rows")
        if not isinstance(rows, list) or not rows:
            return
        try:
            summary = pd.DataFrame(rows)
            required = {"articolo", "partita", "mag_rocche", "mag_peso"}
            if required.issubset(summary.columns):
                self.magazino_summary = summary
                self._base_df = summary.copy()
                self._shared_path = "legacy-cache://magazino"
                self.status_var.set(f"✅ Cached: {len(summary)} batches")
                self._data_revision += 1
                self._recompute()
        except Exception as exc:
            logger.warning("Could not restore legacy Magazino summary cache: %s", exc)

    def _restore_shared_lotti(self):
        """Reload the last Lotti file saved in the cache (when it still exists and nothing is loaded yet)."""
        cache = load_lotti_cache()
        source_path = cache.get("source_path", "")
        if not source_path or not Path(source_path).is_file() or not self.lotti_summary.empty:
            return

        try:
            df, errors = lotti_logic.load_lotti(source_path)
        except Exception as exc:  # noqa: BLE001
            df, errors = None, [str(exc)]

        if errors or df is None or df.empty:
            return

        self.lotti_summary = lotti_logic.summarize_by_partita(df)
        self._shared_lotti_path = str(source_path)
        self.lotti_status_var.set(
            f"✅ {len(self.lotti_summary)} Partita/Lotto pairs - {Path(source_path)}"
        )
        self._recompute()

    def sync_shared_lotti(self):
        """Restore a LOTTI file selected elsewhere in the app."""
        cache = load_lotti_cache()
        source_path = cache.get("source_path", "")
        if not source_path or not Path(source_path).is_file():
            return
        if self._shared_lotti_path == str(source_path):
            return

        try:
            df, errors = lotti_logic.load_lotti(source_path)
        except Exception as exc:  # noqa: BLE001
            df, errors = None, [str(exc)]

        if errors or df is None or df.empty:
            return

        self.lotti_summary = lotti_logic.summarize_by_partita(df)
        self._shared_lotti_path = str(source_path)
        self.lotti_status_var.set(
            f"✅ {len(self.lotti_summary)} Partita/Lotto pairs - {Path(source_path)}"
        )
        self._recompute()

    def sync_shared_lotti_async(self):
        """Restore normalized LOTTI data from SQLite; Excel is upload-only."""
        if self._lotti_syncing:
            return
        try:
            from utility import situazione_db
            from utility.source_manager import is_current, load as load_source, source_name
            if is_current("lotti_summary"):
                fingerprint = situazione_db.snapshot_fingerprint("lotti_summary")
                if fingerprint and fingerprint == getattr(self, "_restored_lotti_fp", None):
                    return
                cached = load_source("lotti_summary")
                if cached is not None and not cached.empty:
                    self.lotti_summary = cached.copy(deep=True)
                    self._shared_lotti_path = "sqlite://lotti_summary"
                    self._restored_lotti_fp = fingerprint
                    self.lotti_status_var.set(f"✅ {len(self.lotti_summary)} Partita/Lotto pairs - SQLite ({source_name('lotti_summary')})")
                    self._recompute()
                    return
        except Exception as _ignored:
            logger.debug("gui.tabs.magazino_filato_tab.sync_shared_lotti_async: ignored %r", _ignored)
        source_path = str(load_lotti_cache().get("source_path", ""))
        if not source_path or not Path(source_path).is_file() or self._shared_lotti_path == source_path:
            return

        self._lotti_syncing = True

        def worker():
            """Worker: load the shared Lotti file and give the result to apply_result."""
            try:
                df, errors = lotti_logic.load_lotti(source_path)
            except Exception as exc:  # noqa: BLE001
                df, errors = None, [str(exc)]

            def apply_result():
                """Take the shared Lotti into use (summary by partita, SQLite snapshots) and refresh the table."""
                self._lotti_syncing = False
                if errors or df is None or df.empty:
                    return
                self.lotti_summary = lotti_logic.summarize_by_partita(df)
                self._shared_lotti_path = source_path
                try:
                    from utility.source_manager import save as save_source_frame
                    save_source_frame("lotti_data", df, source_path)
                    save_source_frame("lotti_summary", self.lotti_summary, source_path)
                except Exception as _ignored:
                    logger.debug("gui.tabs.magazino_filato_tab.apply_result: ignored %r", _ignored)
                self.lotti_status_var.set(
                    f"✅ {len(self.lotti_summary)} Partita/Lotto pairs - {Path(source_path)}"
                )
                self._recompute()
                if self._on_shared_cache_changed:
                    self._on_shared_cache_changed()

            post_to_ui(self, apply_result)

        threading.Thread(target=worker, daemon=True).start()

    def _build_upload_panel(self):
        """Build the upload panel: the buttons to select the Magazino and Lotti files and their status labels."""
        panel = ttk.LabelFrame(self, text="1) Upload files")
        panel.pack(side="top", fill="x", padx=8, pady=6)

        row = ttk.Frame(panel)
        row.pack(fill="x", padx=4, pady=4)
        self.status_var = tk.StringVar(value="No Magazino file uploaded")
        self._btn_magazino = ttk.Button(row, text="📦 Select Magazino File…", command=self._on_upload_magazino)
        self._btn_magazino.pack(side="left")
        ttk.Label(row, textvariable=self.status_var, foreground="#666666").pack(side="left", padx=8)

        row2 = ttk.Frame(panel)
        row2.pack(fill="x", padx=4, pady=4)
        self.lotti_status_var = tk.StringVar(value="No LOTTI file uploaded (optional)")
        self._btn_lotti = ttk.Button(row2, text="📦 Select LOTTI File…", command=self._on_upload_lotti)
        self._btn_lotti.pack(side="left")
        ttk.Label(row2, textvariable=self.lotti_status_var, foreground="#666666").pack(side="left", padx=8)

        row_search = ttk.Frame(panel)
        row_search.pack(fill="x", padx=4, pady=4)
        ttk.Label(row_search, text="Search:").pack(side="left", padx=(0, 8))
        search_entry = ttk.Entry(row_search, textvariable=self._search_var, width=36)
        search_entry.pack(side="left", padx=(0, 4))
        ttk.Button(row_search, text="Clear", width=6, command=lambda: self._search_var.set("")).pack(side="left")
        self._search_var.trace_add("write", lambda *_: self._on_search_changed())

        row3 = ttk.Frame(panel)
        row3.pack(fill="x", padx=4, pady=4)
        ttk.Button(row3, text="📤 Export to Excel", command=self._on_export).pack(side="right")

    def _build_treeview(self):
        """Build the summary line and the table of the Magazino summary."""
        summary_bar = ttk.Frame(self)
        summary_bar.pack(side="top", fill="x", padx=8, pady=(2, 0))
        ttk.Label(summary_bar, textvariable=self.total_available_var,
                  foreground="#16324f", font=("Segoe UI", 11, "bold")).pack(side="left")

        frame = ttk.Frame(self)
        frame.pack(side="top", fill="both", expand=True, padx=8, pady=6)

        self.tree = ttk.Treeview(frame, columns=COLUMNS, show="headings", selectmode="browse")
        for c in COLUMNS:
            self.tree.heading(c, text=HEADERS[c], command=lambda c=c: self._sort_by(c))
            self.tree.column(c, width=140, anchor="w" if c == "articolo" else "center")
        self.tree.tag_configure("oddrow", background="#FFFFFF")
        self.tree.tag_configure("evenrow", background="#EAF1FB")

        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

    def _on_upload_magazino(self, path=None, cache_path=None):
        """cache_path, if given, is what gets persisted/shown instead of
        path -- used by the Overview 'import everything' button, which
        loads from a temp extract of the real (master) file."""
        if self._uploading:
            return
        if path is None:
            path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx *.xls")])
        if not path:
            return
        display_path = cache_path or path
        self._uploading = True
        self._btn_magazino.config(state="disabled")
        self.status_var.set("Loading Magazino file…")

        def worker():
            """Read the chosen Magazino file off the UI thread and hand the result to
            apply_result, which updates the status, aggregates raw files into the summary
            (app-generated summaries are used as they are) and refreshes the table.
            """
            try:
                df, errors = logic.load_magazino(path, articolo_prefix=None)
            except Exception as exc:  # noqa: BLE001
                errors = [f"An error occurred while reading the file: {exc}"]
                df = None

            def apply_result():
                """UI-thread end of the Magazino upload: show the error, or summarise by partita (raw files are aggregated, summaries used as they are), update the status and refresh."""
                self._uploading = False
                self._btn_magazino.config(state="normal")
                if errors or df is None or df.empty:
                    msg = "; ".join(errors) if errors else "The file is empty after filtering"
                    self.status_var.set(f"❌ {msg}")
                    if cache_path is None:
                        messagebox.showerror("Error", msg)
                    return

                # Raw files need aggregation; app-generated summary files are
                # already normalized and can be used as-is.
                if {"mag_rocche", "mag_peso"}.issubset(df.columns):
                    self.magazino_summary = df
                else:
                    self.magazino_summary = logic.summarize_by_partita(df)
                self._data_revision += 1
                self._base_df = self.magazino_summary.copy()
                self._shared_path = display_path
                save_magazino_cache(display_path, self.magazino_summary)
                try:
                    from utility.source_manager import save as save_source_frame
                    save_source_frame("magazino_summary", self.magazino_summary, display_path)
                except Exception as _ignored:
                    logger.debug("gui.tabs.magazino_filato_tab.apply_result: ignored %r", _ignored)
                if self._on_shared_cache_changed:
                    self._on_shared_cache_changed()
                self.status_var.set(f"✅ {len(self.magazino_summary)} batches - {os.path.basename(display_path)}")
                logger.info("Magazino Filato: loaded %d batches from %s",
                            len(self.magazino_summary), os.path.basename(display_path))
                self._recompute()

            post_to_ui(self, apply_result)

        threading.Thread(target=worker, daemon=True).start()

    def _on_upload_lotti(self, path=None, cache_path=None):
        """Import LOTTI off-thread so large workbooks do not freeze the GUI."""
        if getattr(self, "_lotti_uploading", False):
            return
        if path is None:
            path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx *.xls")])
        if not path:
            return
        display_path = cache_path or path
        self._lotti_uploading = True
        if hasattr(self, "_btn_lotti"):
            self._btn_lotti.configure(state="disabled")
        if hasattr(self, "lotti_status_var"):
            self.lotti_status_var.set("Loading LOTTI file…")

        def worker():
            """Worker: load the uploaded Lotti file, summarise it by partita and save the snapshots; any error is passed on."""
            try:
                df, errors = lotti_logic.load_lotti(path)
                if errors or df is None or df.empty:
                    raise ValueError("; ".join(errors) if errors else "The file is empty after filtering")
                summary = lotti_logic.summarize_by_partita(df)
                from utility.source_manager import save as save_source_frame
                save_source_frame("lotti_data", df, display_path)
                save_source_frame("lotti_summary", summary, display_path)
                save_lotti_cache(display_path)
                error = None
            except Exception as exc:
                df, summary, error = None, None, exc

            def apply_result():
                """UI-thread end of the Lotti upload: show the error or the new status and refresh the table."""
                self._lotti_uploading = False
                if hasattr(self, "_btn_lotti"):
                    self._btn_lotti.configure(state="normal")
                if error is not None:
                    msg = str(error)
                    self.lotti_status_var.set(f"❌ {msg}")
                    if cache_path is None:
                        messagebox.showerror("Error", msg)
                    return
                self.lotti_summary = summary
                self._shared_lotti_path = display_path
                if self._on_shared_cache_changed:
                    self._on_shared_cache_changed()
                self.lotti_status_var.set(f"✅ {len(summary)} Partita/Lotto pairs - {display_path}")
                logger.info("Magazino Filato: loaded %d Lotto entries from %s", len(df), os.path.basename(path))
                self._recompute()

            post_to_ui(self, apply_result)
        threading.Thread(target=worker, daemon=True, name="planning-upload-lotti").start()

    def sync_shared_async(self):
        """Restore normalized Magazino data from SQLite; Excel is upload-only."""
        if self._syncing:
            return
        try:
            from utility import situazione_db
            from utility.source_manager import is_current, load as load_source, source_name
            if is_current("magazino_summary"):
                fingerprint = situazione_db.snapshot_fingerprint("magazino_summary")
                if fingerprint and fingerprint == getattr(self, "_restored_magazino_fp", None):
                    return          # SQLite holds nothing new since the last restore
                cached = load_source("magazino_summary")
                if cached is not None and not cached.empty:
                    self.magazino_summary = cached.copy(deep=True)
                    self._base_df = self.magazino_summary.copy()
                    self._data_revision += 1
                    self._shared_path = "sqlite://magazino_summary"
                    self._restored_magazino_fp = fingerprint
                    self.status_var.set(f"✅ {len(self.magazino_summary)} batches - SQLite ({source_name('magazino_summary')})")
                    self._recompute()
                    return
        except Exception as _ignored:
            logger.debug("gui.tabs.magazino_filato_tab.sync_shared_async: ignored %r", _ignored)
        cache = load_magazino_cache()
        source_path = str(cache.get("source_path", ""))
        if not source_path or self._shared_path == source_path or not os.path.isfile(source_path):
            return

        self._syncing = True

        def worker():
            """Worker: load the shared Magazino file and give the result to apply_result."""
            try:
                df, errors = logic.load_magazino(source_path, articolo_prefix=None)
            except Exception as exc:  # noqa: BLE001
                df, errors = None, [str(exc)]

            def apply_result():
                """Take the shared Magazino into use: summary by partita, cache it and refresh the table."""
                self._syncing = False
                if errors or df is None or df.empty:
                    return
                self.magazino_summary = logic.summarize_by_partita(df)
                self._data_revision += 1
                self._base_df = self.magazino_summary.copy()
                self._shared_path = source_path
                save_magazino_cache(source_path, self.magazino_summary)
                try:
                    # The file was chosen on another page: bring SQLite up to date with it.
                    from utility.source_manager import save as save_source_frame
                    save_source_frame("magazino_summary", self.magazino_summary, source_path)
                except Exception as _ignored:
                    logger.debug("gui.tabs.magazino_filato_tab.apply_result: ignored %r", _ignored)
                self.status_var.set(f"✅ {len(self.magazino_summary)} batches - {source_path}")
                self._recompute()
                if self._on_shared_cache_changed:
                    self._on_shared_cache_changed()

            post_to_ui(self, apply_result)

        threading.Thread(target=worker, daemon=True).start()

    def _get_unfiltered_df(self):
        """The Magazino summary joined with the Lotti by partita (empty lotto when there are no Lotti), before any search filter."""
        if self._base_df.empty:
            return pd.DataFrame()

        if not self.lotti_summary.empty:
            df = self._base_df.merge(self.lotti_summary, on="partita", how="left")
        else:
            df = self._base_df.copy()
            df["lotto"] = ""
        if "titolo" not in df.columns:
            df["titolo"] = ""

        # A missing Lotto from the left merge must stay visually empty; do
        # not let pandas' NaN leak into the Treeview, search, or export.
        if "lotto" in df.columns:
            df["lotto"] = df["lotto"].fillna("").astype(str).replace({"nan": "", "NaT": ""})
        return df

    def _recompute(self):
        self._update_total_available()
        self._apply_search_and_sort()

    def _update_total_available(self):
        if self.magazino_summary.empty:
            self.total_available_var.set("Totale disponibile: 0 rocche | 0 kg")
            return
        rocche_values = self.magazino_summary["mag_rocche"] if "mag_rocche" in self.magazino_summary else pd.Series(dtype=float)
        peso_values = self.magazino_summary["mag_peso"] if "mag_peso" in self.magazino_summary else pd.Series(dtype=float)
        rocche = pd.to_numeric(rocche_values, errors="coerce").fillna(0).sum()
        peso = pd.to_numeric(peso_values, errors="coerce").fillna(0).sum()
        self.total_available_var.set(f"Totale disponibile: {rocche:,.0f} rocche | {peso:,.0f} kg")

    def _render(self):
        self.tree.delete(*self.tree.get_children())
        for idx, r in self.summary_df.iterrows():
            tag = "evenrow" if idx % 2 == 0 else "oddrow"
            self.tree.insert("", "end", values=(
                r["articolo"], r.get("titolo", ""), r["partita"],
                f"{r['mag_rocche']:g}", f"{r['mag_peso']:g}",
                r.get("lotto", "") if pd.notna(r.get("lotto", "")) else "",
            ), tags=(tag,))

    def _apply_search_and_sort(self):
        """Apply the search text and the current sort to the table and draw it."""
        self._filter_after_id = None
        df = self._get_unfiltered_df()
        if df.empty:
            self.summary_df = pd.DataFrame()
            self._render()
            return

        q = self._search_var.get().strip().lower()
        if q:
            searchable = df.astype(str)
            mask = searchable.apply(
                lambda column: column.str.lower().str.contains(q, regex=False)
            ).any(axis=1)
            df = df[mask]

        if self._sort_column:
            ascending = not self._sort_reverse
            df = df.sort_values(self._sort_column, ascending=ascending, kind="mergesort")

        self.summary_df = df.reset_index(drop=True)
        self._render()

    def _sort_by(self, column: str) -> None:
        if self._sort_column == column:
            self._sort_reverse = not self._sort_reverse
        else:
            self._sort_column = column
            self._sort_reverse = False
        self._apply_search_and_sort()

    def _on_search_changed(self):
        # Avoid rebuilding the dataframe and Treeview once per keystroke.
        if self._filter_after_id is not None:
            try:
                self.after_cancel(self._filter_after_id)
            except tk.TclError:
                pass
        self._filter_after_id = self.after(180, self._apply_search_and_sort)

    def _on_export(self):
        """Export the Magazino summary table to a styled Excel file chosen by the user
        (header colours, borders, centred columns).
        """
        if self.summary_df.empty:
            messagebox.showinfo("No data", "Upload the Magazino file first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".xlsx",
                                             filetypes=[("Excel", "*.xlsx")],
                                             initialfile="Magazino_Filato.xlsx")
        if not path:
            return

        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

        thin = Side(style="thin", color="B0B0B0")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        center = Alignment(horizontal="center", vertical="center")
        header_fill = PatternFill(start_color="16324F", end_color="16324F", fill_type="solid")

        header_font = Font(bold=True, name="Arial", color="FFFFFF")
        body_font = Font(name="Arial")
        wb = Workbook()
        ws = wb.active
        ws.title = "Magazino Filato"
        ws.append([HEADERS[c] for c in COLUMNS])
        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = center
            cell.border = border

        # Styling via `for cell in ws[ws.max_row]:` after every append()
        # is quadratic in row count -- `ws[n]` recomputes max_column by
        # rescanning every cell written so far. Tracking (row, column)
        # numbers by hand and writing via ws.cell(...) instead keeps this
        # linear (same fix, same reasoning, as calculate/prezzi.py's
        # export -- see gui/tabs/prezzi_tab.py's own comment on this).
        row_num = 1
        for _, r in self.summary_df.iterrows():
            lotto_val = r.get("lotto", "")
            lotto_val = "" if pd.isna(lotto_val) else lotto_val
            row_num += 1
            for col_num, value in enumerate(
                [r["articolo"], r.get("titolo", ""), r["partita"], r["mag_rocche"], r["mag_peso"], lotto_val], start=1
            ):
                cell = ws.cell(row=row_num, column=col_num, value=value)
                cell.font = body_font
                cell.alignment = center
                cell.border = border

        last_row = ws.max_row
        last_col_letter = get_column_letter(len(COLUMNS))
        if last_row > 1:
            ws.auto_filter.ref = f"A1:{last_col_letter}{last_row}"
        ws.freeze_panes = "A2"
        for i in range(1, len(COLUMNS) + 1):
            ws.column_dimensions[get_column_letter(i)].width = 16

        safe_save_workbook(wb, path)
        logger.info("Magazino Filato: exported to %s", path)
        messagebox.showinfo("Completed", f"Export completed successfully:\n{path}")
