"""Tkinter page for extracting Biglietti, customer workbook and Filato."""

from __future__ import annotations

import threading
import tkinter as tk
from pathlib import Path
from typing import TYPE_CHECKING
from tkinter import filedialog, messagebox, ttk

from .shared_orders_window import SharedOrdersWindowMixin
from .shared_order_actions import SharedOrdersActionsMixin

if TYPE_CHECKING:
    from .show_orders_tab import ShowOrdersTab

from .biglietti_exports import (
    load_articoli_marca_lookup,
    load_articoli_titolo_map,
    load_densita_query,
    load_prezzo_lookup,
    load_vmm22_ratio_from_magazino,
)
from utility.articoli_cache import load_articoli_cache, save_articoli_cache
from utility.column_selection import load_hidden
from utility.densita_cache import load_densita_cache, save_densita_cache
from utility.magazino_cache import load_magazino_cache
from utility.prezzi_cache import load_prezzi_cache
from utility.path_manager import save_source, source_path
from utility.email_compose import (
    EmailAutocomplete,
    EmailTemplate,
    extract_email_addresses,
    get_outlook_accounts,
    open_outlook_account_setup,
    open_outlook_email,
)
from utility.utils import keep_window_on_top, bind_escape_to_close
from calculate.raw_batch import is_assigned_raw
from utility.ui_thread import post_to_ui
from utility.utils import logger

# Filato x Tinturia here follows the same convention as Ordine Kamal/Ordine
# ELVY: a fixed filename, cleared and rewritten with only this run's rows
# every time (see pipelines.ordini_elvy.export_filato_full's docstring) --
# not the old per-order-named "{order file}_Filato.xlsx" snapshot.
# ELVY and MED rows go to the Show Orders workbook (and may produce a Filato file); Kamal's do not.
SHARED_ORDER_KINDS = ("elvy", "med")


def _split_pg_x_records(records):
    """Return (ready, pg_x) records for separate Word ticket files: ready = holds one of our raw batches."""
    ready, pg_x = [], []
    for record in records:
        (ready if is_assigned_raw(record.raw_batch, record.customer_code) else pg_x).append(record)
    return ready, pg_x


class BigliettiTab(SharedOrdersWindowMixin, SharedOrdersActionsMixin, ttk.Frame):
    """The "Biglietti" page (Excel + Word tickets per customer).

    One tab per customer -- ELVY, MED, EL KAMAL -- each with its inputs, ticket template,
    output folders, e-mail actions and its own Convert button.  Converting a customer
    produces that customer's Excel workbook and Word tickets (and, for ELVY / MED, the
    Filato file and the rows of the Show Orders workbook, which lives on the Shared Orders
    page).  The conversion itself is pipelines.create_conversion; this class gathers the
    state and shows the outcome.  It also owns the Show Orders windows
    (SharedOrdersWindowMixin / SharedOrdersActionsMixin).  Conversions run on a worker
    thread and report back through post_to_ui().
    """
    def __init__(self, parent: tk.Misc, prefs: dict, save_prefs, logger, on_shared_cache_changed=None, on_notification=None, source_bar_factory=None):
        """Create the Biglietti page: keep the preferences, the notification callbacks and the file/folder state, then build the widgets and restore the saved paths."""
        super().__init__(parent, padding=12)
        self._prefs = prefs
        self._save_prefs = save_prefs
        self._logger = logger
        self._on_shared_cache_changed = on_shared_cache_changed
        self._on_notification = on_notification
        self._source_bar_factory = source_bar_factory
        self.data_path: Path | None = None
        self.dispo_path: Path | None = None
        self.template_path: Path | None = None
        self.elvy_output_dir: Path | None = None
        self.med_output_dir: Path | None = None
        self.el_kamal_output_dir: Path | None = None
        self.filato_output_dir: Path | None = None
        self.shared_excel_path: Path | None = None
        self.articoli_path: Path | None = None
        self.densita_path: Path | None = None
        self.filato_enabled = tk.BooleanVar(value=False)
        # Kamal's Excel + Biglietti output hides the internal Rocche/KG
        # quantities by default; the user's last choice is persisted.
        self.kamal_hide_quantities = tk.BooleanVar(value=True)
        self._kamal_hide_quantities_snapshot = True
        self.email_templates: dict[str, EmailTemplate] = {
            "elvy": EmailTemplate(), "med": EmailTemplate(), "el_kamal": EmailTemplate(),
        }
        self._sender_email = ""
        self._last_client_files: dict[str, list[Path]] = {"elvy": [], "med": [], "el_kamal": []}
        self._client_page_book: ttk.Notebook | None = None
        self._convert_buttons: list[ttk.Button] = []
        # Widgets that mirror one value on the three customer pages.
        self._status_labels: list[ttk.Label] = []
        self._dir_labels: dict[str, list[ttk.Label]] = {}
        # The Shared Orders page is a page of its own (gui.tabs.show_orders_tab).
        self.shared_excel_label: ttk.Label | None = None
        self._show_orders_page = None
        self._goto_show_orders = None            # callback that selects the Shared Orders page
        self._build()
        self._restore()
        self.after(60000, self._run_pgx_report_schedule)

    def _build(self):
        """Build the page: a scrollable canvas holding the title, the input pickers
        (order data, Dispo, template, Articoli, Listini, Magazino ...), the output
        folders per customer, the options and the Convert / e-mail buttons.
        """
        # This page is taller than the available client area on smaller
        # screens. Keep the page itself scrollable so the lower controls are
        # reachable without forcing the whole application to a fixed size.
        self._canvas = tk.Canvas(self, highlightthickness=0, borderwidth=0)
        self._scrollbar = ttk.Scrollbar(self, orient="vertical", command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=self._scrollbar.set)
        self._canvas.pack(side="left", fill="both", expand=True)
        self._scrollbar.pack(side="right", fill="y")
        content = ttk.Frame(self._canvas, padding=0)
        self._canvas_window = self._canvas.create_window((0, 0), window=content, anchor="nw")
        content.bind("<Configure>", lambda _event: self._canvas.configure(scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>", lambda event: self._canvas.itemconfigure(self._canvas_window, width=event.width))
        self._canvas.bind_all("<MouseWheel>", self._on_mousewheel, add="+")
        content.columnconfigure(0, weight=1)
        # The Shared Create Excel controls live in the application's own
        # top-level "Shared Orders" tab. This customer page contains exactly
        # three pages: ELVY, MED and EL KAMAL.
        page_book = ttk.Notebook(content)
        page_book.pack(side="top", anchor="nw", fill="both", expand=True)
        self._client_page_book = page_book
        self._source_labels = {key: [] for key in ("data", "dispo", "template", "articoli", "densita")}
        for kind, label in (("ELVY", "ELVY"), ("MED", "MED"), ("EL_KAMAL", "EL KAMAL")):
            page = ttk.Frame(page_book, padding=(6, 4))
            page_book.add(page, text=label)
            self._build_client_page(page, kind, label)
        style = ttk.Style(self)
        style.configure("Bold.TButton", font=("Segoe UI", 10, "bold"))
        style.configure("PageTitle.TLabel", font=("Segoe UI", 17, "bold"), foreground="#16324F")
        style.configure("PageSubtitle.TLabel", font=("Segoe UI", 9), foreground="#5B6B7A")
        style.configure("Section.TLabelframe", padding=10)
        style.configure("Section.TLabelframe.Label", font=("Segoe UI", 10, "bold"), foreground="#16324F")
        style.configure("Hint.TLabel", font=("Segoe UI", 8), foreground="#64748B")


    def _on_mousewheel(self, event):
        widget = self.winfo_containing(event.x_root, event.y_root)
        if self.winfo_exists() and widget is not None and str(widget).startswith(str(self._w)):
            self._canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _build_client_page(self, page, kind: str, label: str) -> None:
        """Build one of the three customer pages.

        Input/template/source paths are application-wide values, but their
        upload controls are intentionally present on every customer page.
        The label widgets are mirrored so selecting a file in one page is
        immediately visible in the other two pages.
        """
        page.columnconfigure(0, weight=1)
        input_box = ttk.LabelFrame(page, text=" 1. Main input files (required) ", style="Section.TLabelframe")
        input_box.pack(fill="x", pady=(0, 10)); input_box.columnconfigure(1, weight=1)
        ttk.Button(input_box, text="📂 Select Order Data", command=self._pick_data, width=24).grid(row=0, column=0, sticky="w", pady=4)
        data_label = ttk.Label(input_box, text="No file selected", foreground="grey", anchor="w")
        data_label.grid(row=0, column=1, sticky="ew", padx=(10, 0), pady=4)
        ttk.Button(input_box, text="📂 Select Dispo-Bagno", command=self._pick_dispo, width=24).grid(row=1, column=0, sticky="w", pady=4)
        dispo_label = ttk.Label(input_box, text="No file selected (optional if embedded)", foreground="grey", anchor="w")
        dispo_label.grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=4)
        self._source_labels["data"].append(data_label); self._source_labels["dispo"].append(dispo_label)

        template_box = ttk.LabelFrame(page, text=" 2. Ticket template ", style="Section.TLabelframe")
        template_box.pack(fill="x", pady=(0, 10)); template_box.columnconfigure(1, weight=1)
        ttk.Button(template_box, text="📄 Select Forma Biglietti", command=self._pick_template, width=24).grid(row=0, column=0, sticky="w", pady=4)
        template_label = ttk.Label(template_box, text="Searching for Biglietti.docx...", foreground="grey", anchor="w")
        template_label.grid(row=0, column=1, sticky="ew", padx=(10, 0), pady=4)
        self._source_labels["template"].append(template_label)

        opt_box = ttk.LabelFrame(page, text=f" 3. {label} data files ", style="Section.TLabelframe")
        opt_box.pack(fill="x", pady=(0, 10)); opt_box.columnconfigure(1, weight=1)
        # Articles and Density are uploaded where the selected customer uses
        # them. The saved path is still shared globally with all customers.
        if self._source_bar_factory is not None:
            # Articoli, Densita, Magazino and Listini: side by side, state shown by a dot.
            self._source_bar_factory(opt_box, "biglietti").grid(row=0, column=0, columnspan=2, sticky="w", pady=2)
            # the path labels below are kept (hidden) because the rest of the page still updates them
            self._source_labels["articoli"].append(ttk.Label(opt_box))
            self._source_labels["densita"].append(ttk.Label(opt_box))
        else:
            ttk.Button(opt_box, text="📂 Articles (Titolo)", command=self._pick_articoli, width=24).grid(row=0, column=0, sticky="w", pady=4)
            articoli_label = ttk.Label(opt_box, text="Shared with Situation tab", foreground="grey", anchor="w")
            articoli_label.grid(row=0, column=1, sticky="ew", padx=(10, 0), pady=4)
            self._source_labels["articoli"].append(articoli_label)
            ttk.Button(opt_box, text="📂 Density Query", command=self._pick_densita, width=24).grid(row=1, column=0, sticky="w", pady=4)
            densita_label = ttk.Label(opt_box, text="Not selected — KG remains raw yarn weight", foreground="grey", anchor="w")
            densita_label.grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=4)
            self._source_labels["densita"].append(densita_label)

        export_box = ttk.LabelFrame(page, text=" 4. Client output folders and email actions ", style="Section.TLabelframe")
        export_box.pack(fill="x", pady=(0, 10)); export_box.columnconfigure(1, weight=1)
        ttk.Label(export_box, text="Selected folder", style="Hint.TLabel").grid(row=0, column=1, sticky="w", padx=(10, 0))
        output_kind = {"ELVY": "elvy", "MED": "med", "EL_KAMAL": "el_kamal"}[kind]
        self._build_folder_row(export_box, 1, output_kind, f"📁 {label} Output Folder", show_email_buttons=True)
        self._build_folder_row(export_box, 2, "filato", "📁 Filato x Tinturia Folder", with_checkbox=True)

        if kind == "EL_KAMAL":
            kamal_box = ttk.LabelFrame(page, text=" Kamal Excel + Biglietti ", style="Section.TLabelframe")
            kamal_box.pack(fill="x", pady=(0, 10))
            ttk.Checkbutton(
                kamal_box,
                text="Hide Rocche, KG and VMM22 in Kamal Excel + Biglietti (default)",
                variable=self.kamal_hide_quantities,
                command=lambda: self._save_prefs(kamal_hide_quantities=self.kamal_hide_quantities.get()),
            ).pack(anchor="w")

        action_box = ttk.LabelFrame(page, text=" 5. Convert ", style="Section.TLabelframe")
        action_box.pack(fill="x", pady=(8, 4))
        button_row = ttk.Frame(action_box)
        button_row.pack(anchor="w", pady=(0, 8))
        convert_button = ttk.Button(
            button_row, text=f"⚡ Convert {label} Excel + Biglietti",
            command=lambda customer=kind: self._on_client_convert(customer),
            width=38, style="Bold.TButton",
        )
        convert_button.pack(side="left")
        self._convert_buttons.append(convert_button)
        # Which columns the Excel sheets and the Word ticket of this customer contain.
        from gui.column_picker import columns_button
        columns_button(button_row, f"biglietti_{kind.lower()}", width=16).pack(side="left", padx=(8, 0))
        if kind == "EL_KAMAL":
            note = "Kamal uses its own output workbook and Biglietti files."
        elif kind == "ELVY":
            note = "ELVY uses Articles, Density, Magazino and Price sources when available."
        else:
            note = "MED uses Articles and Density plus the shared warehouse/price snapshots."
        ttk.Label(action_box, text=note, style="Hint.TLabel", wraplength=900).pack(anchor="w")
        status = ttk.Label(action_box, text="● Ready", font=("Segoe UI", 9, "bold"), foreground="#2E7D32", anchor="w")
        status.pack(fill="x", pady=(6, 0))
        self._status_labels.append(status)

    def _set_mirrored_label(self, key: str, text: str, foreground: str = "#111827") -> None:
        """Update every copy of a shared path/source label."""
        labels = getattr(self, "_source_labels", {}).get(key, [])
        for label in labels:
            try:
                label.config(text=text, foreground=foreground)
            except tk.TclError:
                pass

    def _build_folder_row(self, parent, row_idx, kind, btn_text, with_checkbox=False, show_email_buttons=False):
        """Build one "output folder" row (button + path label) for a customer, with the optional Filato checkbox and e-mail buttons."""
        btn_frame = ttk.Frame(parent)
        btn_frame.grid(row=row_idx, column=0, sticky="w", pady=4)
        ttk.Button(btn_frame, text=btn_text, command=lambda: self._pick_output_dir(kind), width=24).pack(side="left")
        if with_checkbox:
            ttk.Checkbutton(btn_frame, text="Generate Raw Yarn (Filato)", variable=self.filato_enabled).pack(side="left", padx=(10, 0))
        lab = ttk.Label(parent, text="No folder selected", foreground="grey", anchor="w")
        lab.grid(row=row_idx, column=1, sticky="ew", padx=(10, 0), pady=4)
        setattr(self, f"{kind}_dir_label", lab)
        self._dir_labels.setdefault(kind, []).append(lab)
        if show_email_buttons:
            client_name = {"elvy": "ELVY", "med": "MED", "el_kamal": "EL KAMAL"}.get(kind, kind.upper())
            email_frame = ttk.Frame(parent)
            email_frame.grid(row=row_idx, column=2, sticky="e", padx=(10, 0), pady=4)
            ttk.Button(
                email_frame, text=f"✉ {client_name} Template", width=18,
                command=lambda: self._open_email_template_editor(kind),
            ).pack(side="left", padx=(0, 4))
            ttk.Button(
                email_frame, text=f"📧 {client_name} Prepare Email", width=22,
                command=lambda: self._prepare_email(kind),
            ).pack(side="left")

    def _open_email_template_editor(self, kind: str) -> None:
        """TO/CC/SUBJECT/body editor for one client's email -- saved so
        "Prepare Email" can reuse it on every future Convert, not just this
        session."""
        template = self.email_templates.get(kind, EmailTemplate())
        window = tk.Toplevel(self)
        bind_escape_to_close(window)
        keep_window_on_top(window)
        window.title(f"Email Template — {kind.upper().replace('_', ' ')}")
        window.geometry("520x440")
        window.minsize(460, 380)

        form = ttk.Frame(window, padding=10)
        form.pack(fill="both", expand=True)
        form.columnconfigure(1, weight=1)

        to_var = tk.StringVar(value=template.to)
        cc_var = tk.StringVar(value=template.cc)
        subject_var = tk.StringVar(value=template.subject)
        email_values = self._saved_email_addresses()

        ttk.Label(form, text="To:").grid(row=0, column=0, sticky="w", pady=4)
        to_entry = EmailAutocomplete(form, values=email_values, textvariable=to_var)
        to_entry.grid(row=0, column=1, sticky="ew", pady=4)
        ttk.Label(form, text="Cc:").grid(row=1, column=0, sticky="w", pady=4)
        cc_entry = EmailAutocomplete(form, values=email_values, textvariable=cc_var)
        cc_entry.grid(row=1, column=1, sticky="ew", pady=4)
        ttk.Label(form, text="Subject:").grid(row=2, column=0, sticky="w", pady=4)
        ttk.Entry(form, textvariable=subject_var).grid(row=2, column=1, sticky="ew", pady=4)
        ttk.Label(form, text="Body:").grid(row=3, column=0, sticky="nw", pady=4)
        body_text = tk.Text(form, height=12, wrap="word")
        body_text.grid(row=4, column=0, columnspan=2, sticky="nsew", pady=(0, 4))
        body_text.insert("1.0", template.body)
        form.rowconfigure(4, weight=1)

        sender_text = self._sender_email or "Default Outlook account"
        sender_row = ttk.Frame(form)
        sender_row.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        sender_row.columnconfigure(0, weight=1)
        sender_label = ttk.Label(sender_row, text=f"Sender: {sender_text}", foreground="#555555")
        sender_label.grid(row=0, column=0, sticky="w")
        ttk.Button(
            sender_row, text="Change sender email", width=22,
            command=lambda: self._choose_sender_email(sender_label),
        ).grid(row=0, column=1, sticky="e")

        ttk.Label(
            form, text="Separate multiple recipients with a semicolon (a@x.com; b@y.com).",
            foreground="grey", font=("Segoe UI", 8),
        ).grid(row=6, column=0, columnspan=2, sticky="w")

        def save():
            self.email_templates[kind] = EmailTemplate(
                to=to_var.get().strip(), cc=cc_var.get().strip(),
                subject=subject_var.get().strip(), body=body_text.get("1.0", "end-1c"),
            )
            self._remember_email_addresses(to_var.get(), cc_var.get())
            self._save_prefs(biglietti_email_templates={
                k: t.to_dict() for k, t in self.email_templates.items()
            })
            window.destroy()

        buttons = ttk.Frame(form)
        buttons.grid(row=7, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(buttons, text="Cancel", command=window.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(buttons, text="Save", command=save).pack(side="right")

    def _prepare_email(self, kind: str) -> None:
        """Open an Outlook compose window for *kind*'s saved template, with
        that client's files from the most recent Convert run attached."""
        template = self.email_templates.get(kind)
        if template is None or template.is_blank():
            messagebox.showwarning(
                "Email Template Not Set",
                f"Set up the email template for {kind.upper().replace('_', ' ')} first "
                "(the ✉ Template button next to it).",
            )
            return
        files = [p for p in self._last_client_files.get(kind, []) if p and Path(p).is_file()]
        if not files:
            messagebox.showwarning(
                "No Files Yet",
                f"No {kind.upper().replace('_', ' ')} files from a Convert run yet in this "
                "session — run Convert first, then Prepare Email.",
            )
            return
        try:
            open_outlook_email(template, files, sender_email=self._sender_email)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Could Not Open Email", str(exc))

    def _saved_email_addresses(self) -> list[str]:
        values = self._prefs.get("email_addresses", [])
        return [str(value) for value in values if str(value).strip()] if isinstance(values, list) else []

    def _remember_email_addresses(self, *fields: str) -> None:
        merged = self._saved_email_addresses()
        for address in extract_email_addresses(*fields):
            if not any(address.casefold() == old.casefold() for old in merged):
                merged.append(address)
        self._save_prefs(email_addresses=merged[-200:])

    def _choose_sender_email(self, label=None) -> None:
        """Show a dialog to pick which connected Outlook account sends the e-mail,
        with a button to add another account.  The choice is stored in the preferences.
        """
        try:
            accounts = get_outlook_accounts()
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Outlook Accounts", str(exc))
            return
        if not accounts:
            messagebox.showwarning("Outlook Accounts", "No connected Outlook email accounts were found.")
            return
        window = tk.Toplevel(self)
        bind_escape_to_close(window)
        keep_window_on_top(window)
        window.title("Change sender email")
        window.transient(self.winfo_toplevel())
        window.grab_set()
        form = ttk.Frame(window, padding=12)
        form.pack(fill="both", expand=True)
        ttk.Label(form, text="Send this email from:").pack(anchor="w", pady=(0, 6))
        choices = [f"{address} — {name}" if name and name.casefold() != address.casefold() else address for address, name in accounts]
        current_idx = next((i for i, (address, _name) in enumerate(accounts) if address.casefold() == self._sender_email.casefold()), 0)
        selected = tk.StringVar(value=choices[current_idx])
        ttk.Combobox(form, textvariable=selected, values=choices, state="readonly", width=48).pack(fill="x")
        ttk.Label(
            form,
            text="Don't see an email you already added in Outlook itself? Outlook only reads its "
                 "account list once, when it starts -- fully quit Outlook (check the Windows system "
                 "tray, it can keep running there) and reopen it, then try again.",
            foreground="#555555", wraplength=420, justify="left",
        ).pack(anchor="w", pady=(6, 0))

        def add_account():
            """Open the "Add / connect email account" dialog: asks for the address and then
            launches Outlook's own sign-in, so the app never sees or stores the password.
            """
            try:
                add_window = tk.Toplevel(window)
                bind_escape_to_close(add_window)
                keep_window_on_top(add_window)
                add_window.title("Add / connect email account")
                add_window.transient(window)
                add_form = ttk.Frame(add_window, padding=12)
                add_form.pack(fill="both", expand=True)
                ttk.Label(
                    add_form,
                    text="Enter the email you want to add, then complete the sign-in in Outlook:",
                    wraplength=420,
                ).pack(anchor="w", pady=(0, 8))
                new_email = tk.StringVar()
                ttk.Entry(add_form, textvariable=new_email, width=48).pack(fill="x")
                ttk.Label(
                    add_form,
                    text="Outlook will ask for the password and verification. The app never reads or stores them.",
                    foreground="#555555", wraplength=420,
                ).pack(anchor="w", pady=(8, 10))

                def launch_setup():
                    """Check that an e-mail address was typed, then open Outlook's account setup and show the instructions to finish connecting it."""
                    if not new_email.get().strip() or "@" not in new_email.get():
                        messagebox.showwarning("Email required", "Enter a valid email address first.", parent=add_window)
                        return
                    open_outlook_account_setup()
                    add_window.destroy()
                    window.destroy()
                    messagebox.showinfo(
                        "Complete Outlook setup",
                        f"In the Outlook window, add and connect:\n\n{new_email.get().strip()}\n\n"
                        "When finished, open Change sender email again to select it.\n\n"
                        "Already added it in Outlook but still don't see it here? Outlook keeps "
                        "the account list loaded in memory from when it started, so just adding "
                        "the account isn't enough on its own -- fully quit Outlook (check the "
                        "Windows system tray, it can keep running there after the window is "
                        "closed) and reopen it, then try Change sender email again.",
                    )

                ttk.Button(add_form, text="Open Outlook account setup", command=launch_setup).pack(anchor="e")
            except Exception as exc:  # noqa: BLE001
                messagebox.showerror("Outlook Account Setup", str(exc))

        ttk.Button(
            form, text="＋ Add / connect new email account", command=add_account,
        ).pack(anchor="w", pady=(8, 0))

        def save_sender():
            self._sender_email = accounts[choices.index(selected.get())][0]
            self._save_prefs(sender_email=self._sender_email)
            if label is not None:
                label.config(text=f"Sender: {self._sender_email}")
            window.destroy()

        ttk.Button(form, text="Save", command=save_sender).pack(anchor="e", pady=(10, 0))

    def _restore(self):
        """Restore the saved state of the page at startup: the last order/Dispo files, the
        Biglietti.docx template (saved path, Desktop or next to the app), and the
        output folder of each customer -- each only when it still exists on disk.
        """
        for key, attr, source in [("biglietti_data_path", "data_path", "data_ordine"), ("biglietti_dispo_path", "dispo_path", "dispo_bagno")]:
            p = self._prefs.get(key) or (str(source_path(source)) if source_path(source) else "")
            if p and Path(p).is_file():
                setattr(self, attr, Path(p))
                self._set_mirrored_label("data" if key == "biglietti_data_path" else "dispo", p)
        template_value = self._prefs.get("biglietti_template_path", "")
        template_candidates = [
            Path(str(template_value)) if template_value else None,
            Path.home() / "OneDrive" / "Desktop" / "Biglietti.docx",
            Path.home() / "Desktop" / "Biglietti.docx",
            Path(__file__).resolve().parent / "Biglietti.docx",
        ]
        self.template_path = next(
            (candidate for candidate in template_candidates if candidate and candidate.is_file()),
            None,
        )
        if self.template_path:
            self._set_mirrored_label("template", str(self.template_path))
        else:
            self._set_mirrored_label("template", "Not selected — choose Biglietti.docx", "grey")
        for kind in ("elvy", "med", "el_kamal", "filato"):
            p = self._prefs.get(f"biglietti_{kind}_output_dir")
            if p and Path(p).is_dir():
                setattr(self, f"{kind}_output_dir", Path(p))
                self._set_dir_label(kind, p)
        shared = self._prefs.get("biglietti_shared_excel_path", "")
        if shared and Path(shared).is_file():
            self.shared_excel_path = Path(shared)
            self._refresh_show_orders_page()
        saved_templates = self._prefs.get("biglietti_email_templates", {})
        self._sender_email = str(self._prefs.get("sender_email", "") or "")
        self.kamal_hide_quantities.set(bool(self._prefs.get("kamal_hide_quantities", True)))
        for kind in ("elvy", "med", "el_kamal"):
            self.email_templates[kind] = EmailTemplate.from_dict(saved_templates.get(kind))
        try:
            articoli_cache = load_articoli_cache()
            if articoli_cache.get("source_path"):
                self._set_mirrored_label("articoli", f"Shared: {Path(articoli_cache['source_path']).name}")
        except Exception as _ignored:
            logger.debug("gui.tabs.biglietti_tab._restore: ignored %r", _ignored)
        cache = load_densita_cache()
        if cache.get("source_path") and Path(cache["source_path"]).is_file():
            self.densita_path = Path(cache["source_path"])
            self._set_mirrored_label("densita", cache["source_path"])
        cache = load_magazino_cache()
        if cache.get("source_path"):
            # VMM22 is a shared snapshot; the per-client hint remains valid.
            pass
        price_cache = load_prezzi_cache()
        if price_cache.get("source_path"):
            # Prices are shared through the Prices/Situation snapshot.
            pass

    def sync_shared_sources(self) -> None:
        """A shared file (Articoli, Densita, ...) was uploaded on another page: pick up its path now."""
        cache = load_densita_cache()
        source = cache.get("source_path")
        if source and Path(source).is_file():
            self.densita_path = Path(source)
            self._set_mirrored_label("densita", source)
        articoli = load_articoli_cache().get("source_path")
        if articoli and Path(articoli).is_file():
            self.articoli_path = Path(articoli)
            self._set_mirrored_label("articoli", f"Shared: {Path(articoli).name}")

    def _pick_file(self, title, filetypes=None):
        return filedialog.askopenfilename(title=title, filetypes=filetypes or [("Excel files", "*.xlsx;*.xlsm"), ("All files", "*.*")])

    def _pick_data(self):
        p = self._pick_file("Select Order Data File")
        if p:
            self.data_path = Path(p)
            self._set_mirrored_label("data", p)
            save_source("data_ordine", self.data_path)
            self._save_prefs(biglietti_data_path=p)

    def _pick_dispo(self):
        p = self._pick_file("Select Dispo-Bagno File", filetypes=[("CSV/Excel", "*.csv;*.xlsx;*.xlsm"), ("All files", "*.*")])
        if p:
            self.dispo_path = Path(p)
            self._set_mirrored_label("dispo", p)
            save_source("dispo_bagno", self.dispo_path)
            self._save_prefs(biglietti_dispo_path=p)

    def set_template_path(self, path: str | Path) -> None:
        """Set and persist the Word ticket template selected by another page."""
        candidate = Path(path)
        if not candidate.is_file():
            return
        self.template_path = candidate
        self._set_mirrored_label("template", str(candidate))
        self._save_prefs(biglietti_template_path=str(candidate))

    def _pick_template(self):
        path = filedialog.askopenfilename(
            title="Select Forma Biglietti (Word template)",
            filetypes=[("Word document", "*.docx"), ("All files", "*.*")],
        )
        if path:
            self.set_template_path(path)

    def _pick_output_dir(self, kind: str):
        p = filedialog.askdirectory(title=f"Select Output Folder ({kind.upper()})")
        if p:
            setattr(self, f"{kind}_output_dir", Path(p))
            self._set_dir_label(kind, p)
            self._save_prefs(**{f"biglietti_{kind}_output_dir": p})

    def _set_shared_excel(self, path: str | Path) -> None:
        """Remember the Show Orders workbook and show it on the Shared Orders page."""
        candidate = Path(path)
        self.shared_excel_path = candidate
        self._refresh_show_orders_page()
        self._save_prefs(biglietti_shared_excel_path=str(candidate))

    def _refresh_show_orders_page(self) -> None:
        """Repaint the Shared Orders page's path label (the page may not be built yet)."""
        if self._show_orders_page is not None:
            self._show_orders_page.refresh()

    def attach_show_orders_page(self, parent, goto_page) -> "ShowOrdersTab":
        """Build the Shared Orders page inside ``parent`` (a notebook placeholder) and remember
        ``goto_page``, the callback that selects it -- used to send the operator there when
        a conversion needs the workbook and none is chosen yet."""
        from .show_orders_tab import ShowOrdersTab
        self._goto_show_orders = goto_page
        self._show_orders_page = ShowOrdersTab(parent, self)
        self.shared_excel_label = self._show_orders_page.path_label
        self._show_orders_page.refresh()
        self._show_orders_page.pack(fill="both", expand=True)
        return self._show_orders_page

    def _open_show_orders_page(self) -> None:
        """Switch to the Shared Orders page (when it is attached)."""
        if self._goto_show_orders:
            self._goto_show_orders()

    _select_shared_page = _open_show_orders_page          # the name this page used before

    def _set_dir_label(self, kind: str, text: str) -> None:
        """Show a folder on every customer page that has a row for it."""
        for label in self._dir_labels.get(kind, []):
            label.config(text=text, foreground="#111827")

    def _set_convert_buttons_state(self, state: str) -> None:
        """Enable / disable every page's Convert button (one conversion runs at a time)."""
        for button in self._convert_buttons:
            try:
                button.config(state=state)
            except tk.TclError:
                pass

    def _ensure_show_orders_file(self, title: str) -> bool:
        """ELVY and MED add their rows to the Show Orders workbook, so one must be chosen
        (an existing file, or the place of a new one -- "Create New" only picks the place:
        the file itself is written by the first conversion).  When none is chosen, warn and
        send the operator to the Shared Orders page to choose it first."""
        if self.shared_excel_path:
            return True
        messagebox.showwarning(
            "Missing Show Orders file",
            f"{title} rows are added to the Show Orders workbook, and none is chosen yet.\n\n"
            "Select an existing Show Orders file (or create a new one) on the Shared Orders page "
            "-- it opens now -- then convert again.",
        )
        self._open_show_orders_page()
        return False

    def _ensure_folder(self, kind: str) -> bool:
        """True when the ``kind`` folder is set and exists; otherwise ask for it (False if skipped)."""
        current = getattr(self, f"{kind}_output_dir", None)
        if not current or not Path(current).is_dir():
            self._pick_output_dir(kind)
            current = getattr(self, f"{kind}_output_dir", None)
        return bool(current and Path(current).is_dir())

    def _on_client_convert(self, customer: str) -> None:
        """Convert only ``customer`` ("ELVY", "MED" or "EL_KAMAL") from its own page.

        Only that customer's rows are read and only its files are written.  ELVY and MED
        first need the Show Orders workbook (their rows are appended to Orders / PG-X): when
        none is chosen the operator gets a warning and the Shared Orders page opens.
        EL KAMAL does not use that workbook.
        """
        from pipelines.create_conversion import ConversionRequest, customer_records

        kind, title = customer.lower(), customer.replace("_", " ")
        if kind in SHARED_ORDER_KINDS and not self._ensure_show_orders_file(title):
            return
        if not self.data_path or not self.data_path.is_file():
            return messagebox.showwarning("Missing Input", "Please select the Order Data file first.")
        if not self.template_path or not self.template_path.is_file():
            return messagebox.showwarning("Missing Input", "Please select the Forma Biglietti (Biglietti.docx) template first.")
        from exporters.input_check import check_order_file
        problems = check_order_file(kind, self.data_path, self.dispo_path)
        if problems and not messagebox.askyesno(
            "Check the Order Data file",
            "The file looks incomplete:\n\n" + "\n".join(f"• {p}" for p in problems)
            + "\n\nConvert anyway?", icon="warning",
        ):
            return
        try:
            customer_records(kind, self.data_path, self.dispo_path)
        except ValueError as exc:
            return messagebox.showwarning(f"No {title} Rows", str(exc))
        except Exception as exc:  # noqa: BLE001
            return messagebox.showerror("Read Error", f"Could not read the Order Data file:\n{exc}")
        if not self._ensure_folder(kind):
            return
        filato_dir = None
        if kind in SHARED_ORDER_KINDS and self.filato_enabled.get():
            if not self._ensure_folder("filato"):
                return
            filato_dir = self.filato_output_dir
        # Snapshot the Tk state before entering the worker thread.
        request = ConversionRequest(
            kind=kind, data_path=self.data_path, dispo_path=self.dispo_path, template=self.template_path,
            output_dir=Path(getattr(self, f"{kind}_output_dir")), filato_dir=filato_dir,
            shared_excel=self.shared_excel_path if kind in SHARED_ORDER_KINDS else None,
            hide_kamal_quantities=self.kamal_hide_quantities.get(),
            hidden_columns=load_hidden(f"biglietti_{kind}"),
        )
        self._set_convert_buttons_state("disabled")
        self._set_status(f"Converting {title} orders and generating tickets in progress...")
        threading.Thread(target=self._worker_convert, args=(request,), daemon=True).start()

    def _pick_shared_excel(self):
        p = filedialog.askopenfilename(
            title="Select shared Create Excel",
            filetypes=[("Excel workbook", "*.xlsx;*.xlsm"), ("All files", "*.*")],
        )
        if p:
            self._set_shared_excel(p)

    def _create_shared_excel(self):
        folder = filedialog.askdirectory(title="Select folder for shared Create Excel and Biglietti")
        if folder:
            self._set_shared_excel(Path(folder) / "Create Orders.xlsx")

    def _pick_articoli(self):
        """Let the user pick Articoli.xlsx and read it twice: the Marca (brand) map used
        for price categories and the Titolo codes used on the tickets.  The file is
        remembered as the shared "articoli" source and a summary is shown.
        """
        p = self._pick_file("Select Articoli.xlsx")
        if not p:
            return
        import exporters.biglietti_exporter as biglietti_exporter
        try:
            marca_map, marca_errors = biglietti_exporter.load_articoli_marca_map(Path(p))
        except Exception as exc:
            self._logger.exception("Articoli (Marca) read failed")
            marca_map, marca_errors = {}, [str(exc)]
        try:
            import utility.situazione_db as situazione_db
            import parsers.situazione_loaders as situazione_loaders
            titolo_df, titolo_errors = situazione_loaders.load_codes(p)
        except Exception as exc:
            self._logger.exception("Articoli (TITOLO) read failed")
            titolo_df, titolo_errors = None, [str(exc)]
        if not marca_map and not titolo_df:
            errors = marca_errors + (titolo_errors or [])
            messagebox.showerror("Articles Error", "; ".join(errors) if errors else "Invalid file: no recognizable Articolo Filato column found.")
            return
        self.articoli_path = Path(p)
        save_source("articoli", self.articoli_path)
        parts = []
        if marca_map:
            save_articoli_cache(p)
            try:
                import pandas as pd
                from utility.source_manager import save as save_source_frame
                marca_df = pd.DataFrame({"articolo": list(marca_map), "marca": list(marca_map.values())})
                save_source_frame("articoli_marca", marca_df, p)
            except Exception as _ignored:
                logger.debug("gui.tabs.biglietti_tab._pick_articoli: ignored %r", _ignored)
            parts.append(f"{len(marca_map)} articles (Brand/Marca)")
        if titolo_df is not None and not titolo_df.empty:
            situazione_db.save_codes(titolo_df)
            parts.append(f"{len(titolo_df)} rows shared with Situation")
        self._set_mirrored_label("articoli", " + ".join(parts) + f" loaded from {Path(p).name}")
        if self._on_shared_cache_changed:
            self._on_shared_cache_changed()

    def _pick_densita(self):
        """Pick Densita' Query.xlsx, remember it and save its data as the shared density source."""
        p = self._pick_file("Select Densita' Query.xlsx")
        if p:
            self.densita_path = Path(p)
            self._set_mirrored_label("densita", p)
            save_densita_cache(p)
            try:
                from exporters.biglietti_exporter import load_densita_query
                from utility.source_manager import save as save_source_frame
                import pandas as pd
                density_map, _ = load_densita_query(Path(p))
                rows = [{"partita": partita, **values} for partita, values in density_map.items()]
                if rows:
                    save_source_frame("densita_lookup", pd.DataFrame(rows), p)
            except Exception as _ignored:
                logger.debug("gui.tabs.biglietti_tab._pick_densita: ignored %r", _ignored)
            if self._on_shared_cache_changed:
                self._on_shared_cache_changed()

    def _set_status(self, msg: str):
        """Show ``msg`` on every customer page's status line."""
        color = "#C62828" if "Error" in msg else ("#1565C0" if "progress" in msg or "Converting" in msg else "#2E7D32")
        prefix = "✖ " if "Error" in msg else ("⏳ " if "progress" in msg or "Converting" in msg else "✔ ")

        def apply():
            for label in self._status_labels:
                label.config(text=f"{prefix}{msg}", foreground=color)

        post_to_ui(self, apply)

    def _load_common_sources(self):
        """Load what every conversion needs: the Articoli codes map, the density map, the VMM22 ratios, the price lookup and the magazino summary.
        Returns (codes_map, densita_map, vmm_ratio_map, price_lookup, magazino_summary).
        """
        codes_map = load_articoli_marca_lookup() or load_articoli_titolo_map()
        densita_map, _errors = load_densita_query(self.densita_path if self.densita_path and self.densita_path.is_file() else None)
        vmm_ratio_map, _errors = load_vmm22_ratio_from_magazino(None)
        magazino_summary = None
        try:
            from utility.source_manager import load as load_source
            magazino_summary = load_source("magazino_summary")
        except Exception:
            magazino_summary = None
        if magazino_summary is None or magazino_summary.empty:
            magazino_path = load_magazino_cache().get("source_path")
            if magazino_path and Path(magazino_path).is_file():
                from calculate import magazino as magazino_logic
                magazino_df, _errors = magazino_logic.load_magazino(Path(magazino_path), articolo_prefix=None)
                magazino_summary = magazino_logic.summarize_by_partita(magazino_df)
        price_lookup, _price_source = load_prezzo_lookup()
        return codes_map, densita_map, vmm_ratio_map, price_lookup, magazino_summary

    def _worker_convert(self, request):
        """The conversion of one customer (runs on a worker thread).

        Loads the shared lookup data, hands everything to pipelines.create_conversion and
        reports what was created back to the UI thread.
        """
        from pipelines.create_conversion import CommonSources, convert_customer

        kind, title = request.kind, request.kind.upper().replace("_", " ")
        self._last_client_files[kind] = []
        try:
            result = convert_customer(request, CommonSources(*self._load_common_sources()))
            self._last_client_files[kind] = list(result.files)
            summary_text = "\n\n".join(result.items)
            self._set_status(f"Completed — {title} workbook and dyeing tickets generated successfully.")
            post_to_ui(self, lambda: messagebox.showinfo(
                f"{title} — Conversion Complete", f"Conversion completed successfully!\n\n{summary_text}"))
        except Exception as exc:  # noqa: BLE001
            self._logger.exception("Biglietti conversion failed (%s)", title)
            self._set_status(f"Error: {exc}")
            post_to_ui(self, lambda exc=exc: messagebox.showerror("Conversion Error", str(exc)))
        finally:
            post_to_ui(self, lambda: self._set_convert_buttons_state("normal"))
