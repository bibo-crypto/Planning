"""
kamal_tab.py
"Ordine Kamal" tab: upload one or more Kamal order-letter PDFs, match each
colour's Articolo via DFM (shared with Data Elvy) and optionally match raw
yarn stock (Magazino), then export an Excel workbook.
"""
import threading
from pathlib import Path

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Ordine Kamal's real work (PDF parsing, Excel export, raw-yarn matching)
# pulls in pandas + openpyxl + pdfplumber transitively -- profiling startup
# showed importing this tab's dependencies eagerly, at tab-construction
# time, was over 1 second of the ~1.6s spent building the whole app window
# (pandas alone is ~0.5s, pdfplumber ~0.18s, the rest is openpyxl and this
# tab's own module chain). None of that is needed just to draw the tab's
# widgets -- only once the user actually clicks Convert. Deferring these
# imports to first real use (utility.utils.lazy_call/LazyModule, same
# pattern as biglietti_tab.py and ordine_med_tab.py) means the window
# appears with its real work-time cost, not the cost of every library
# every tab *could* need.
from utility.utils import lazy_call, LazyModule

for _name, _module_path in (
    ("load_dfm_cache", "parsers.dfm_lookup"),
    ("load_dfm_entries_by_prefix", "parsers.dfm_lookup"),
    ("KamalExcelExporter", "exporters.kamal_excel_exporter"),
    ("KamalParser", "parsers.kamal_parser"),
    ("assign_ordine_kamal_machines", "pipelines.ordine_kamal"),
    ("assign_bagno_prepostato", "pipelines.ordine_kamal"),
    ("build_ordine_kamal_rows", "pipelines.ordine_kamal"),
    ("match_by_lotto", "pipelines.ordine_kamal"),
    ("export_filato_full", "pipelines.ordini_elvy"),
    ("export_ordini_full", "pipelines.ordini_elvy"),
    ("match_raw_yarn", "pipelines.ordini_elvy"),
):
    globals()[_name] = lazy_call(_module_path, _name)

magazino_logic = LazyModule("calculate.magazino")
lotti_logic = LazyModule("calculate.lotti")

# A fixed value straight from pipelines.ordine_kamal.KAMAL_ARTICLE_PREFIX --
# copied here instead of importing that module (which would immediately
# pull in the whole pandas/pdfplumber chain again) since it never changes.
KAMAL_ARTICLE_PREFIX = "C170"

from utility.magazino_cache import load_magazino_cache, save_magazino_cache
from utility.lotti_cache import load_lotti_cache, save_lotti_cache
from utility.utils import find_pdfs, logger, load_settings, save_settings
from typing import Callable
from utility.ui_thread import post_to_ui


class KamalTab(ttk.Frame):
    """Embeddable 'Ordine Kamal' tab."""

    def __init__(self, master, on_shared_cache_changed: Callable[[], None] | None = None, source_bar_factory=None):
        """Create the Ordine Kamal page: the state (selected PDFs, folders, output, options as Tk variables) and the widgets, then restore the saved paths."""
        super().__init__(master)
        self._pdf_paths: list[Path] = []
        self._pdf_folder_path: Path | None = None
        self._raw_yarn_path: Path | None = None
        self._lotti_path: Path | None = None
        self._output_path: Path | None = None
        self._kamal_erp_export_dir: Path | None = None
        self._kamal_filato_export_dir: Path | None = None
        self._kamal_update_erp_file = tk.BooleanVar(value=True)
        self._kamal_update_filato_file = tk.BooleanVar(value=True)
        # "First bagno" (Bagno Preposato) -- same idea as the Ordine Med tab;
        # one-shot, cleared after every conversion.
        self._kamal_bagno_enabled = tk.BooleanVar(value=False)
        self._kamal_bagno_start = tk.StringVar(value="")
        self._first_bagno_snapshot: str | None = None
        self._kamal_order_no_enabled = tk.BooleanVar(value=False)
        self._kamal_order_no = tk.StringVar(value="")
        self._order_no_snapshot: str | None = None
        self._shared_dfm_path = ""
        self._on_shared_cache_changed = on_shared_cache_changed
        self._source_bar_factory = source_bar_factory
        self._prefs = load_settings()

        self._build_ui()
        self._restore_saved_paths()
        # DFM sync is cheap (reads a small cached path, not the DFM Excel
        # itself) and has no competing per-tab preference to conflict with,
        # unlike Magazino/LOTTI above -- so it's safe to do proactively here,
        # fixing the gap where a returning session wouldn't reflect an
        # already-uploaded DFM restored from SQLite; a re-upload is only needed to update it.
        self.sync_shared_dfm()
        self.sync_shared_magazino()
        self.sync_shared_lotti()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        """Build the Ordine Kamal page: PDF / PDF-folder / output pickers, the DFM and
        raw-yarn status lines, the options (update ERP/filato files, first bagno,
        order number) and the Convert button with its status label.
        """
        self.columnconfigure(0, weight=1)
        sel_frame = ttk.LabelFrame(self, text="Input", padding=6)
        sel_frame.grid(row=0, column=0, sticky="ew", padx=4, pady=(4, 2))
        sel_frame.columnconfigure((0, 1, 2), weight=1)
        ttk.Button(sel_frame, text="📄 Select PDF(s)", command=self._on_select_pdfs, width=16).grid(row=0, column=0, padx=4, pady=4, sticky="ew")
        ttk.Button(sel_frame, text="📁 Select PDF Folder", command=self._on_select_pdf_folder, width=18).grid(row=0, column=1, padx=4, pady=4, sticky="ew")
        ttk.Button(sel_frame, text="💾 Output File", command=self._on_select_output, width=16).grid(row=0, column=2, padx=4, pady=4, sticky="ew")
        self._lbl_pdfs = ttk.Label(sel_frame, text="No PDFs selected", foreground="grey", anchor="w")
        self._lbl_pdfs.grid(row=1, column=0, sticky="ew", padx=4)
        self._lbl_output = ttk.Label(sel_frame, text="No output file selected", foreground="grey", anchor="w")
        self._lbl_output.grid(row=1, column=2, sticky="ew", padx=4)
        self._lbl_pdf_folder = ttk.Label(sel_frame, text="No PDF folder selected", foreground="grey", anchor="w")
        self._lbl_pdf_folder.grid(row=2, column=0, columnspan=2, sticky="ew", padx=4)

        self._lbl_dfm = ttk.Label(
            self,
            text="DFM: upload a reference on the Data Elvy tab — it is shared automatically.",
            foreground="grey", anchor="w", wraplength=720, justify="left",
        )
        self._lbl_dfm.grid(row=1, column=0, sticky="ew", padx=4, pady=(2, 0))
        if self._source_bar_factory is not None:
            self._lbl_dfm.grid_remove()

        lotti_frame = ttk.LabelFrame(self, text="Raw Yarn Matching", padding=6)
        lotti_frame.grid(row=2, column=0, sticky="ew", padx=4, pady=(4, 2))
        lotti_frame.columnconfigure(1, weight=1)
        ttk.Button(lotti_frame, text="📦 Select LOTTI File…", command=self._on_select_lotti, width=20).grid(row=0, column=0, padx=4, pady=3, sticky="w")
        self._lbl_lotti = ttk.Label(lotti_frame, text="No LOTTI file selected", foreground="grey", anchor="w")
        self._lbl_lotti.grid(row=0, column=1, sticky="ew", padx=4)
        ttk.Button(lotti_frame, text="📦 Select Magazino File…", command=self._on_select_raw_yarn, width=20).grid(row=1, column=0, padx=4, pady=3, sticky="w")
        self._lbl_raw_yarn = ttk.Label(lotti_frame, text="No Magazino file selected", foreground="grey", anchor="w")
        self._lbl_raw_yarn.grid(row=1, column=1, sticky="ew", padx=4)
        if self._source_bar_factory is not None:
            lotti_frame.grid_remove()          # DFM, Magazino and Lotto are uploaded with the source bar

        bagno_frame = ttk.LabelFrame(self, text="Bagno Preposato (KAMAL)", padding=6)
        bagno_frame.grid(row=3, column=0, sticky="ew", padx=4, pady=(3, 2))
        bagno_frame.columnconfigure(2, weight=1)
        ttk.Label(bagno_frame, text="First bagno:").grid(row=0, column=0, padx=(0, 5), pady=2, sticky="w")
        ttk.Entry(bagno_frame, textvariable=self._kamal_bagno_start, width=14).grid(
            row=0, column=1, padx=4, pady=2, sticky="w"
        )
        ttk.Checkbutton(
            bagno_frame, text="Use bagno sequence", variable=self._kamal_bagno_enabled,
        ).grid(row=0, column=2, padx=8, pady=2, sticky="w")
        ttk.Label(
            bagno_frame,
            text="Default: disabled. Example: T1200. One bath per colour (COLOREDFM, or Colore when blank) "
                 "-- the same group that sets the machine: first row blank, the other rows carry the bath.",
            foreground="grey", wraplength=620, justify="left",
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 0))

        order_frame = ttk.LabelFrame(self, text="Optional Order Number in Commento", padding=6)
        order_frame.grid(row=4, column=0, sticky="ew", padx=4, pady=(3, 2))
        order_frame.columnconfigure(2, weight=1)
        ttk.Label(order_frame, text="Order No.:").grid(row=0, column=0, padx=(0, 5), pady=2, sticky="w")
        ttk.Entry(order_frame, textvariable=self._kamal_order_no, width=14).grid(row=0, column=1, padx=4, pady=2, sticky="w")
        ttk.Checkbutton(
            order_frame, text="Add to Commento", variable=self._kamal_order_no_enabled,
        ).grid(row=0, column=2, padx=8, pady=2, sticky="w")
        ttk.Label(
            order_frame,
            text="Default: disabled. Example: 28 → PG-159640-ORD.Nr.28-2026-(LETTER 105).",
            foreground="grey", wraplength=620, justify="left",
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 0))

        erp_frame = ttk.LabelFrame(self, text="Also Extract ERP Files", padding=6)
        erp_frame.grid(row=5, column=0, sticky="ew", padx=4, pady=(3, 2))
        erp_frame.columnconfigure(1, weight=1)

        ttk.Button(
            erp_frame, text="📁 Select ERP Files Folder…", command=self._on_select_erp_folder, width=22
        ).grid(row=0, column=0, padx=(0, 6), pady=(2, 4), sticky="w")
        ttk.Checkbutton(
            erp_frame, text="Extract ERP order file", variable=self._kamal_update_erp_file
        ).grid(row=0, column=1, sticky="w", pady=(2, 4))
        self._lbl_erp_dir = ttk.Label(erp_frame, text="No folder selected", foreground="grey", anchor="w")
        self._lbl_erp_dir.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 4))

        ttk.Button(
            erp_frame, text="📁 Select Filato Folder…", command=self._on_select_filato_folder, width=22
        ).grid(row=2, column=0, padx=(0, 6), pady=(4, 2), sticky="w")
        ttk.Checkbutton(
            erp_frame, text="Extract Filato x Tinturia.xlsx", variable=self._kamal_update_filato_file
        ).grid(row=2, column=1, sticky="w", pady=(4, 2))
        self._lbl_filato_dir = ttk.Label(erp_frame, text="No folder selected", foreground="grey", anchor="w")
        self._lbl_filato_dir.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(0, 2))

        self._kamal_update_erp_file.trace_add(
            "write",
            lambda *_: self._save_prefs(kamal_update_erp_file=self._kamal_update_erp_file.get()),
        )
        self._kamal_update_filato_file.trace_add(
            "write",
            lambda *_: self._save_prefs(kamal_update_filato_file=self._kamal_update_filato_file.get()),
        )
        self._kamal_bagno_enabled.trace_add(
            "write", lambda *_: self._save_prefs(kamal_bagno_enabled=self._kamal_bagno_enabled.get())
        )
        self._kamal_bagno_start.trace_add(
            "write", lambda *_: self._save_prefs(kamal_bagno_start=self._kamal_bagno_start.get())
        )
        self._kamal_order_no_enabled.trace_add(
            "write", lambda *_: self._save_prefs(kamal_order_no_enabled=self._kamal_order_no_enabled.get())
        )
        self._kamal_order_no.trace_add(
            "write", lambda *_: self._save_prefs(kamal_order_no=self._kamal_order_no.get())
        )

        action_frame = ttk.Frame(self, padding=(6, 4))
        action_frame.grid(row=6, column=0, sticky="ew", padx=4, pady=2)
        self._btn_convert = ttk.Button(
            action_frame, text="▶  Convert", command=self._on_convert, style="Accent.TButton"
        )
        self._btn_convert.pack(side="left")
        from gui.column_picker import columns_button
        columns_button(action_frame, "ordine_kamal").pack(side="left", padx=(8, 0))
        self._lbl_status = ttk.Label(action_frame, text="", foreground="grey")
        self._lbl_status.pack(side="left", padx=12)
        if self._source_bar_factory is not None:
            from gui.source_bar import attach_to_top
            attach_to_top(self, self._source_bar_factory(self, "ordine_kamal"))

    # --------------------------------------------------------------- events
    def _on_select_pdfs(self):
        paths = filedialog.askopenfilenames(filetypes=[("PDF files", "*.pdf")])
        if not paths:
            return
        self._pdf_paths = [Path(p) for p in paths]
        self._pdf_folder_path = None
        self._lbl_pdfs.config(
            text=f"{len(self._pdf_paths)} file(s) selected", foreground="black"
        )
        self._lbl_pdf_folder.config(text="No PDF folder selected", foreground="grey")

    def _on_select_pdf_folder(self):
        path = filedialog.askdirectory(
            title="Select a folder containing Kamal order PDFs",
            initialdir=self._prefs.get("kamal_last_dir") or None,
        )
        if path:
            self._pdf_folder_path = Path(path)
            self._pdf_paths = []
            self._lbl_pdfs.config(text="No individual PDFs selected", foreground="grey")
            self._lbl_pdf_folder.config(text=str(self._pdf_folder_path), foreground="black")
            self._save_prefs(kamal_pdf_folder_path=str(self._pdf_folder_path), kamal_last_dir=str(self._pdf_folder_path))

    def _on_select_lotti(self):
        path = filedialog.askopenfilename(
            title="Select the LOTTI (raw yarn lot reference) Excel export",
            filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
            initialdir=self._prefs.get("kamal_last_dir") or None,
        )
        if path:
            self._lotti_path = Path(path)
            self._lbl_lotti.config(text=str(self._lotti_path), foreground="black")
            self._save_prefs(kamal_lotti_path=str(self._lotti_path), kamal_last_dir=str(Path(path).parent))
            save_lotti_cache(self._lotti_path)
            if self._on_shared_cache_changed:
                self._on_shared_cache_changed()

    def _on_select_raw_yarn(self):
        path = filedialog.askopenfilename(
            title="Select the Magazino (raw yarn) Excel export",
            filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
            initialdir=self._prefs.get("kamal_last_dir") or None,
        )
        if path:
            self._raw_yarn_path = Path(path)
            self._lbl_raw_yarn.config(text=str(self._raw_yarn_path), foreground="black")
            self._save_prefs(kamal_raw_yarn_path=str(self._raw_yarn_path), kamal_last_dir=str(Path(path).parent))
            save_magazino_cache(self._raw_yarn_path)
            if self._on_shared_cache_changed:
                self._on_shared_cache_changed()

    def _on_select_output(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")], initialfile="Ordine_Kamal.xlsx",
            initialdir=self._prefs.get("kamal_last_dir") or None,
        )
        if path:
            self._output_path = Path(path)
            self._lbl_output.config(text=str(self._output_path), foreground="black")
            self._save_prefs(kamal_output_path=str(self._output_path), kamal_last_dir=str(Path(path).parent))

    def _on_select_erp_folder(self):
        path = filedialog.askdirectory(
            title="Select ERP file folder",
            initialdir=self._prefs.get("kamal_erp_export_dir") or self._prefs.get("kamal_last_dir") or None,
        )
        if path:
            self._kamal_erp_export_dir = Path(path)
            self._lbl_erp_dir.config(text=str(self._kamal_erp_export_dir), foreground="black")
            self._save_prefs(kamal_erp_export_dir=str(self._kamal_erp_export_dir), kamal_last_dir=str(path))

    def _on_select_filato_folder(self):
        path = filedialog.askdirectory(
            title="Select Filato x Tinturia output folder",
            initialdir=self._prefs.get("kamal_filato_export_dir") or self._prefs.get("kamal_last_dir") or None,
        )
        if path:
            self._kamal_filato_export_dir = Path(path)
            self._lbl_filato_dir.config(text=str(self._kamal_filato_export_dir), foreground="black")
            self._save_prefs(kamal_filato_export_dir=str(self._kamal_filato_export_dir), kamal_last_dir=str(path))

    def _save_prefs(self, **kwargs: object) -> None:
        self._prefs.update(kwargs)
        save_settings(self._prefs)

    def _restore_saved_paths(self) -> None:
        """Restore the saved options (checkboxes, first bagno, order number) and the last
        PDF folder, raw-yarn file and other paths that still exist.
        """
        # Restore the ERP update checkbox together with the saved file path.
        # The variable trace persists user changes; this restores the value
        # on the next application launch.
        self._kamal_update_erp_file.set(self._prefs.get("kamal_update_erp_file", True))
        self._kamal_update_filato_file.set(self._prefs.get("kamal_update_filato_file", True))
        self._kamal_bagno_enabled.set(bool(self._prefs.get("kamal_bagno_enabled", False)))
        self._kamal_bagno_start.set(str(self._prefs.get("kamal_bagno_start", "") or ""))
        self._kamal_order_no_enabled.set(bool(self._prefs.get("kamal_order_no_enabled", False)))
        self._kamal_order_no.set(str(self._prefs.get("kamal_order_no", "") or ""))

        pdf_folder_str = self._prefs.get("kamal_pdf_folder_path")
        if pdf_folder_str and Path(pdf_folder_str).is_dir():
            self._pdf_folder_path = Path(pdf_folder_str)
            self._lbl_pdf_folder.config(text=pdf_folder_str, foreground="black")

        raw_yarn_str = self._prefs.get("kamal_raw_yarn_path")
        if raw_yarn_str and Path(raw_yarn_str).is_file():
            self._raw_yarn_path = Path(raw_yarn_str)
            self._lbl_raw_yarn.config(text=raw_yarn_str, foreground="black")

        lotti_str = self._prefs.get("kamal_lotti_path")
        if lotti_str and Path(lotti_str).is_file():
            self._lotti_path = Path(lotti_str)
            self._lbl_lotti.config(text=lotti_str, foreground="black")

        cache = load_lotti_cache()
        cache_path = cache.get("source_path", "")
        if not self._lotti_path and cache_path and Path(cache_path).is_file():
            self._lotti_path = Path(cache_path)
            self._lbl_lotti.config(text=str(self._lotti_path), foreground="black")

        output_str = self._prefs.get("kamal_output_path")
        if output_str and Path(output_str).parent.is_dir():
            self._output_path = Path(output_str)
            self._lbl_output.config(text=output_str, foreground="black")

        erp_dir_str = self._prefs.get("kamal_erp_export_dir")
        if erp_dir_str and Path(erp_dir_str).is_dir():
            self._kamal_erp_export_dir = Path(erp_dir_str)
            self._lbl_erp_dir.config(text=erp_dir_str, foreground="black")

        # kamal_filato_export_dir is new (Filato used to share the ERP
        # folder) -- fall back to the old shared folder on first run after
        # upgrading, so existing users keep working without reconfiguring.
        filato_dir_str = self._prefs.get("kamal_filato_export_dir") or erp_dir_str
        if filato_dir_str and Path(filato_dir_str).is_dir():
            self._kamal_filato_export_dir = Path(filato_dir_str)
            self._lbl_filato_dir.config(text=filato_dir_str, foreground="black")

    def sync_shared_dfm(self):
        """Reflect the DFM file uploaded on Data Elvy/Situazione, if any."""
        cache = load_dfm_cache()
        source_path = cache.get("source_path", "")
        if source_path and source_path != self._shared_dfm_path:
            self._shared_dfm_path = source_path
        if self._shared_dfm_path:
            self._lbl_dfm.config(
                text=f"✅ Using: {Path(self._shared_dfm_path).name}", foreground="black"
            )
        else:
            self._lbl_dfm.config(
                text="Upload a DFM file on the Data Elvy tab — it's shared automatically.",
                foreground="grey",
            )

    def sync_shared_magazino(self):
        """Reflect the shared Magazino selection from Magazino Filato or Purchase Orders."""
        cache = load_magazino_cache()
        source_path = cache.get("source_path", "")
        if not source_path or not Path(source_path).is_file():
            return
        if self._raw_yarn_path is not None and str(self._raw_yarn_path) == str(source_path):
            return
        self._raw_yarn_path = Path(source_path)
        self._lbl_raw_yarn.config(text=str(self._raw_yarn_path), foreground="black")
        self._save_prefs(kamal_raw_yarn_path=str(self._raw_yarn_path), kamal_last_dir=str(self._raw_yarn_path.parent))

    def sync_shared_lotti(self):
        """Reuse the last selected LOTTI file if it was uploaded elsewhere."""
        cache = load_lotti_cache()
        source_path = cache.get("source_path", "")
        if not source_path or not Path(source_path).is_file():
            return
        if self._lotti_path is not None and str(self._lotti_path) == str(source_path):
            return
        self._lotti_path = Path(source_path)
        self._lbl_lotti.config(text=str(self._lotti_path), foreground="black")
        self._save_prefs(kamal_lotti_path=str(self._lotti_path), kamal_last_dir=str(self._lotti_path.parent))

    def _on_convert(self):
        """Convert button handler: checks that PDFs, an output file and the shared DFM
        reference are available, snapshots the Tk variables (they must not be read
        from the worker thread), validates the first bagno, then runs the conversion
        on a worker thread.
        """
        pdf_paths = list(self._pdf_paths)
        if self._pdf_folder_path is not None:
            pdf_paths = find_pdfs(self._pdf_folder_path)
        if not pdf_paths:
            messagebox.showwarning("Missing input", "Select at least one Kamal order PDF first.")
            return
        if not self._output_path:
            messagebox.showwarning("Missing output", "Select an output file first.")
            return
        if not self._shared_dfm_path:
            messagebox.showwarning(
                "Missing DFM",
                "No DFM reference is loaded yet. Upload one on the Data Elvy tab first — "
                "it's needed to match each colour's Articolo.",
            )
            return

        # Snapshot the Tk variables here (they must not be read from the worker
        # thread) and reject a bad "First bagno" before doing any work.
        self._first_bagno_snapshot = None
        if self._kamal_bagno_enabled.get():
            from calculate.bagno import FIRST_BAGNO_FORMAT_ERROR, is_valid_first_bagno
            first_bagno = self._kamal_bagno_start.get().strip()
            if not first_bagno:
                messagebox.showwarning(
                    "First bagno", "Enter the First bagno (example: T1200) or untick \"Use bagno sequence\"."
                )
                return
            if not is_valid_first_bagno(first_bagno):
                messagebox.showwarning("First bagno", FIRST_BAGNO_FORMAT_ERROR)
                return
            self._first_bagno_snapshot = first_bagno

        self._order_no_snapshot = None
        if self._kamal_order_no_enabled.get():
            order_no = self._kamal_order_no.get().strip()
            if not order_no:
                messagebox.showwarning(
                    "Order number", "Enter the order number or untick \"Add to Commento\"."
                )
                return
            self._order_no_snapshot = order_no

        # The columns the planner switched off (read here, on the UI thread).
        from utility.column_selection import load_hidden
        self._hidden_columns_snapshot = load_hidden("ordine_kamal")

        self._btn_convert.config(state="disabled")
        self._lbl_status.config(text="Converting…", foreground="grey")
        thread = threading.Thread(target=self._run_conversion, args=(pdf_paths,), daemon=True)
        thread.start()

    def _set_status(self, text: str):
        """Thread-safe status label update — safe to call from the background conversion thread."""
        post_to_ui(self, lambda: self._lbl_status.config(text=text, foreground="grey"))

    def _run_conversion(self, pdf_paths: list[Path] | None = None):
        """The Kamal conversion (worker thread).

        Parses every PDF, loads the C170 entries of the shared DFM reference, builds the
        Ordine Kamal rows (colour looked up in DFM), assigns machines/bagno, matches
        raw yarn and lots, then writes the Kamal workbook and, when ticked, the ERP and
        filato files.  Problems are collected and shown when it finishes.
        """
        errors: list[str] = []
        all_rows = []
        raw_yarn_matches: list = []      # what the workbook's Filato sheet lists (for the ERP Filato file)
        pdf_paths = pdf_paths if pdf_paths is not None else list(self._pdf_paths)
        self._set_status("Reading PDF(s)…")
        try:
            for pdf_path in pdf_paths:
                all_rows.extend(KamalParser(pdf_path).parse())
        except Exception as exc:  # noqa: BLE001
            errors.append(f"Error parsing PDF(s): {exc}")

        self._set_status("Loading DFM reference (C170)…")
        dfm_c170_entries = load_dfm_entries_by_prefix(KAMAL_ARTICLE_PREFIX)
        if not dfm_c170_entries:
            errors.append(
                f"No {KAMAL_ARTICLE_PREFIX} entries found in the shared DFM reference — "
                "Articolo matching will be blank for every row."
            )

        magazino_summary = None
        # Titolo lookup for the Filato x Tinturia sheet -- always available from
        # the DFM entries, whichever way the stock itself was loaded.
        codes_map = {e["articolo"]: e.get("titolo", "") for e in dfm_c170_entries if e.get("titolo")}
        try:
            magazino_df, magazino_errors = magazino_logic.load_magazino_snapshot("G170")
        except Exception:
            magazino_df, magazino_errors = None, []
        if (
            magazino_df is not None and not magazino_df.empty
            and {"articolo", "partita", "mag_rocche", "mag_peso"}.issubset(magazino_df.columns)
        ):
            # SQLite already holds the per-Partita summary -- use it as is.
            magazino_summary = magazino_df
        elif self._raw_yarn_path is not None:
            self._set_status("Loading raw yarn stock (Magazino)…")
            try:
                magazino_df, magazino_errors = magazino_logic.load_magazino(
                    str(self._raw_yarn_path), articolo_prefix="G170"
                )
                if magazino_errors or magazino_df is None or magazino_df.empty:
                    errors.append(
                        f"Raw yarn file could not be read: "
                        f"{'; '.join(magazino_errors) if magazino_errors else 'empty after filtering'}"
                    )
                else:
                    magazino_summary = magazino_logic.summarize_by_partita(magazino_df)
            except Exception as exc:  # noqa: BLE001
                errors.append(f"Error loading raw yarn file: {exc}")

        lotti_summary = None
        try:
            lotti_df, lotti_errors = lotti_logic.load_lotti_snapshot(lotti_logic.RAW_ARTICOLO_PREFIXES)
        except Exception:
            lotti_df, lotti_errors = None, []
        if lotti_df is not None and not lotti_df.empty and {"partita", "lotto"}.issubset(lotti_df.columns):
            # Lotto matching is Kamal's primary rule: the SQLite snapshot must
            # feed it too, not only a freshly read Excel file.
            lotti_summary = lotti_logic.summarize_by_partita(lotti_df)
        elif self._lotti_path is not None:
            self._set_status("Loading LOTTI reference…")
            try:
                lotti_df, lotti_errors = lotti_logic.load_lotti(str(self._lotti_path), articolo_prefix=lotti_logic.RAW_ARTICOLO_PREFIXES)
                if lotti_errors or lotti_df is None or lotti_df.empty:
                    errors.append(
                        f"LOTTI file could not be read: "
                        f"{'; '.join(lotti_errors) if lotti_errors else 'empty after filtering'}"
                    )
                else:
                    lotti_summary = lotti_logic.summarize_by_partita(lotti_df)
            except Exception as exc:  # noqa: BLE001
                errors.append(f"Error loading LOTTI file: {exc}")

        self._set_status("Matching raw yarn and exporting…")
        if all_rows:
            try:
                exporter = KamalExcelExporter(
                    all_rows, self._output_path,
                    dfm_c170_entries=dfm_c170_entries,
                    magazino_summary=magazino_summary,
                    codes_map=codes_map,
                    lotti_summary=lotti_summary,
                    first_bagno=self._first_bagno_snapshot,
                    order_no=self._order_no_snapshot,
                    hidden_columns=getattr(self, "_hidden_columns_snapshot", None),
                )
                exporter.export()
                raw_yarn_matches = exporter.raw_yarn_matches
            except Exception as exc:  # noqa: BLE001
                errors.append(f"Error exporting: {exc}")

            if self._kamal_update_erp_file.get():
                if self._kamal_erp_export_dir is None:
                    errors.append("ERP file extraction was enabled but no ERP folder is selected.")
                else:
                    ordini_path = self._kamal_erp_export_dir / "EXCEL PER ORDINE VENDITA EGITTO.xlsx"
                    try:
                        ordini_rows = build_ordine_kamal_rows(
                            all_rows, dfm_c170_entries, order_no=self._order_no_snapshot
                        )
                        assign_ordine_kamal_machines(ordini_rows)
                        assign_bagno_prepostato(ordini_rows, self._first_bagno_snapshot)
                        if lotti_summary is not None and not lotti_summary.empty:
                            match_by_lotto(ordini_rows, lotti_summary)
                        if magazino_summary is not None and not magazino_summary.empty:
                            match_raw_yarn(ordini_rows, magazino_summary, codes_map, quantity_attr="peso_kg")
                        n = export_ordini_full(ordini_path, ordini_rows)
                        logger.info("Ordine Kamal: extracted ERP file %s (%d rows)", ordini_path.name, n)
                    except Exception as exc:  # noqa: BLE001
                        errors.append(f"Error extracting {ordini_path.name}: {exc}")

            if self._kamal_update_filato_file.get():
                if self._kamal_filato_export_dir is None:
                    errors.append("Filato x Tinturia extraction was enabled but no Filato folder is selected.")
                else:
                    filato_path = self._kamal_filato_export_dir / "Filato x Tinturia.xlsx"
                    try:
                        # From the matches themselves, not from the workbook's sheet: that sheet
                        # may have lost columns in the column picker, the ERP file never does.
                        n2 = export_filato_full(filato_path, raw_yarn_matches)
                        logger.info("Filato x Tinturia: extracted %s (%d rows)", filato_path.name, n2)
                    except Exception as exc:  # noqa: BLE001
                        errors.append(f"Error extracting {filato_path.name}: {exc}")

        post_to_ui(self, self._on_conversion_done, errors, len(all_rows))

    def _on_conversion_done(self, errors: list[str], row_count: int):
        """UI-thread end of the conversion: re-enable the button, clear the one-shot inputs (first bagno, order number) and show the result or the errors."""
        self._btn_convert.config(state="normal")
        # First bagno is a one-shot input: clear it after every conversion.
        self._kamal_bagno_start.set("")
        self._kamal_bagno_enabled.set(False)
        self._first_bagno_snapshot = None
        self._kamal_order_no.set("")
        self._kamal_order_no_enabled.set(False)
        self._order_no_snapshot = None
        if errors:
            self._lbl_status.config(text="Completed with errors", foreground="#b00020")
            messagebox.showerror("Errors", "\n".join(errors))
        else:
            self._lbl_status.config(text=f"✅ Done — {row_count} row(s)", foreground="green")
            logger.info("Ordine Kamal: exported %d row(s) to %s", row_count, self._output_path)
            messagebox.showinfo("Completed", f"Export completed successfully:\n{self._output_path}")
