"""Notebook tab implementations."""

