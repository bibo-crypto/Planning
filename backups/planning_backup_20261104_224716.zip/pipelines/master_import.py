"""master_import.py — one directory or one file, every data source.

Lets the user select either:
1. A data folder (directory) containing individual factory exports
   (Articoli.xlsx, Copertura.xlsx, Data Ordine.xlsx, Densita' Query.xlsx,
   DFM.xlsx, Dispo Bagno.xlsx, LISTINI.XLS, LOTTI.xlsx, Magazino.xlsx,
   Produzione.xlsx, Qualita.xlsx, Uscita.xlsx, WINCOINT.xlsx).
2. A single master workbook that bundles all sheets in one file.

Routes each recognized file/sheet through the exact loader/cache pipeline
its own tab uses, distributing data to Situazione, Magazino, Biglietti,
Prezzi, and Overview tabs.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import openpyxl

from utility.path_manager import save_source
from utility.file_cache import CACHE_DIR
from utility.ui_thread import post_to_ui
from utility.utils import logger

SHEET_CANDIDATES: dict[str, list[str]] = {
    "dfm": ["dfm"],
    "copertura": ["copertura"],
    "data_prod": ["produzione", "prod", "data prod", "dataprod"],
    "wincoint": ["wincoint"],
    "uscita": ["uscita"],
    "qualita": ["qualita", "qualità"],
    "codes": ["articoli"],
    "magazino": ["magazino", "magazzino"],
    "lotti": ["lotti", "lotto"],
    "listini": ["listini", "prezzi"],
    "biglietti_template": ["biglietti", "forma biglietti"],
}

DIRECTORY_FILE_CANDIDATES: dict[str, list[str]] = {
    "dfm": ["dfm"],
    "copertura": ["copertura"],
    "data_prod": ["produzione", "prod", "data prod", "data_prod", "dataprod"],
    "wincoint": ["wincoint"],
    "uscita": ["uscita"],
    "qualita": ["qualita", "qualità"],
    "codes": ["articoli", "codes"],
    "magazino": ["magazino", "magazzino"],
    "lotti": ["lotti", "lotto"],
    "listini": ["listini", "prezzi"],
    "biglietti_template": ["biglietti", "forma biglietti"],
    "densita": ["densita' query", "densita query", "densita", "densità query", "densità", "density query"],
    "data_ordine": ["data ordine", "data_ordine", "dataordine", "ordine data"],
    "dispo_bagno": ["dispo bagno", "dispo-bagno", "dispo_bagno", "doispo bagno", "doispo-bagno"],
}

LABELS: dict[str, str] = {
    "dfm": "DFM",
    "copertura": "Copertura",
    "data_prod": "Produzione",
    "wincoint": "WINCOINT",
    "uscita": "Uscita",
    "qualita": "Qualita",
    "codes": "Articoli",
    "magazino": "Magazino",
    "lotti": "LOTTI",
    "listini": "LISTINI",
    "biglietti_template": "Forma Biglietti",
    "densita": "Densita' Query",
    "data_ordine": "Data Ordine",
    "dispo_bagno": "Dispo Bagno",
}


def _norm(s: str) -> str:
    return "".join(ch for ch in str(s).lower() if ch.isalnum())


def _match_sheets(sheetnames: list[str]) -> dict[str, str]:
    """{key: actual_sheet_name} for whichever keys have a matching sheet."""
    found = {}
    normalized = {_norm(s): s for s in sheetnames}
    for key, candidates in SHEET_CANDIDATES.items():
        for cand in candidates:
            n = _norm(cand)
            if n in normalized:
                found[key] = normalized[n]
                break
    return found


def find_files_in_directory(dir_path: str | Path) -> dict[str, Path]:
    """Scan *dir_path* and map each known source key to its matching file
    Path. Real export filenames are rarely the bare candidate name (e.g.
    'Densita__Query.xlsx', 'DFM Agosto 2026.xlsx') so this matches by
    substring, not exact equality -- exact matches are preferred first
    (across every file) before falling back to substring matches, and a
    file already claimed by one key isn't offered to another."""
    dir_path = Path(dir_path)
    if not dir_path.is_dir():
        return {}

    valid_extensions = {".xlsx", ".xls", ".xlsm", ".csv", ".docx"}
    files = [p for p in dir_path.iterdir() if p.is_file() and p.suffix.lower() in valid_extensions]
    file_norms = [(f, _norm(f.stem)) for f in files]

    found: dict[str, Path] = {}
    claimed: set[Path] = set()

    def try_match(exact: bool) -> None:
        """One matching pass over the folder's files: for every expected source not found yet, take the first unclaimed file whose normalised name equals (exact) or contains (loose) one of its candidate names."""
        for key, candidates in DIRECTORY_FILE_CANDIDATES.items():
            if key in found:
                continue
            for candidate in candidates:
                cand_norm = _norm(candidate)
                for f, f_norm in file_norms:
                    if f in claimed:
                        continue
                    hit = (f_norm == cand_norm) if exact else (cand_norm in f_norm)
                    if hit:
                        found[key] = f
                        claimed.add(f)
                        break
                if key in found:
                    break

    try_match(exact=True)
    try_match(exact=False)

    # data_ordine / dispo_bagno filenames are inherently order-specific
    # (e.g. 'MED-D-505449-2026.xlsx') so keyword matching rarely finds
    # them -- fall back to peeking at content shape for whatever files
    # are still unclaimed.
    if "data_ordine" not in found or "dispo_bagno" not in found:
        _content_match_ordine_files(files, claimed, found)

    return found


def _content_match_ordine_files(files: list[Path], claimed: set[Path], found: dict[str, Path]) -> None:
    """Identify the Ordine input files by their CONTENT when file names are not enough.

    Opens each unclaimed file, compares its header rows with the known signatures
    (order data, Kamal sheet, Dispo) and records the match in found[...] / claimed.
    Unreadable files are skipped.
    """
    for f in files:
        if f in claimed:
            continue
        try:
            if f.suffix.lower() == ".csv":
                if "dispo_bagno" in found:
                    continue
                with open(f, encoding="utf-8-sig", newline="") as fh:
                    sample = fh.read(8192)
                if _has_header_signature(sample.splitlines(), {"dispo", "articolo"}):
                    found["dispo_bagno"] = f
                    claimed.add(f)
                continue

            wb = openpyxl.load_workbook(f, read_only=True)
            try:
                data_signature = {"descrizioneaggiuntivaordine", "cliente"}
                kamal_signature = {"codice", "clienti", "mc"}
                dispo_signature = {"dispo", "articolo"}
                for sheet_name in wb.sheetnames:
                    sheet = wb[sheet_name]
                    header_sets = [
                        {_norm(v) for v in values if v}
                        for values in sheet.iter_rows(values_only=True, max_row=12)
                    ]
                    if any(data_signature.issubset(headers) or kamal_signature.issubset(headers)
                           for headers in header_sets):
                        if "data_ordine" not in found:
                            found["data_ordine"] = f
                            claimed.add(f)
                        break
                    if "dispo_bagno" not in found and any(
                        dispo_signature.issubset(headers) for headers in header_sets
                    ):
                        found["dispo_bagno"] = f
                        claimed.add(f)
                        break
            finally:
                wb.close()
        except Exception:
            continue


def _has_header_signature(lines, required: set[str]) -> bool:
    """Return whether a delimited header line contains all required names."""
    for line in lines[:12]:
        values = line.replace(",", ";").split(";")
        if required.issubset({_norm(value) for value in values if value}):
            return True
    return False


def _extract_sheet_to_temp(master_path: str, sheet_name: str, persistent: bool = False) -> str:
    """Copy one sheet into its own standalone xlsx.

    A persistent extract is needed when other tabs must reopen a sheet after
    the master import has finished; a short-lived temp file would leave their
    shared cache pointing at a deleted path.
    """
    src_wb = openpyxl.load_workbook(master_path, data_only=True, read_only=True)
    try:
        src_ws = src_wb[sheet_name]
        out_wb = openpyxl.Workbook()
        out_ws = out_wb.active
        out_ws.title = (sheet_name or "Sheet1")[:31]
        for row in src_ws.iter_rows(values_only=True):
            out_ws.append(row)
    finally:
        src_wb.close()
    if persistent:
        extract_dir = CACHE_DIR / "master_import"
        extract_dir.mkdir(parents=True, exist_ok=True)
        tmp_path = str(extract_dir / f"{_norm(sheet_name)}.xlsx")
    else:
        fd, tmp_path = tempfile.mkstemp(suffix=".xlsx", prefix="master_import_")
        os.close(fd)
    out_wb.save(tmp_path)
    out_wb.close()
    return tmp_path


def _content_match_ordine_sheets(wb, sheetnames: list[str], already_matched: set[str]) -> dict[str, str]:
    """Same content-sniffing idea as ``_content_match_ordine_files``, but for
    sheets inside a single already-open master workbook instead of separate
    files -- Data Ordine / Dispo Bagno have no reliable sheet-name candidate
    (their real name is order-specific), so a name-only match never finds
    them here either.
    """
    found: dict[str, str] = {}
    data_signature = {"descrizioneaggiuntivaordine", "cliente"}
    kamal_signature = {"codice", "clienti", "mc"}
    dispo_signature = {"dispo", "articolo"}
    for sheet_name in sheetnames:
        if sheet_name in already_matched:
            continue
        try:
            sheet = wb[sheet_name]
            header_sets = [
                {_norm(v) for v in values if v}
                for values in sheet.iter_rows(values_only=True, max_row=12)
            ]
        except Exception:
            continue
        if "data_ordine" not in found and any(
            data_signature.issubset(headers) or kamal_signature.issubset(headers)
            for headers in header_sets
        ):
            found["data_ordine"] = sheet_name
            continue
        if "dispo_bagno" not in found and any(
            dispo_signature.issubset(headers) for headers in header_sets
        ):
            found["dispo_bagno"] = sheet_name
    return found


def import_master_file(master_path: str, situazione_tab, magazino_tab, biglietti_tab=None, prezzi_tab=None) -> tuple[list[str], list[str]]:
    """Import all data from a single multi-sheet Excel file."""
    master_path = str(master_path)
    wb = openpyxl.load_workbook(master_path, read_only=True)
    sheetnames = list(wb.sheetnames)

    matches = _match_sheets(sheetnames)
    # Data Ordine / Dispo Bagno never have a matchable sheet name (see
    # _content_match_ordine_sheets), so a single master workbook that
    # bundles them was previously never routing them anywhere and never
    # even reporting them as skipped -- sniff sheet content the same way
    # the directory-import path already does for loose files.
    if "data_ordine" not in matches or "dispo_bagno" not in matches:
        matches.update(_content_match_ordine_sheets(wb, sheetnames, set(matches.values())))
    wb.close()

    loaded: list[str] = []
    # Report every known source that wasn't found, not just the ones with a
    # sheet-name candidate -- densita is reported separately below (it's
    # matched by a two-sheet signature, not a single sheet name), so it's
    # excluded here to avoid double-reporting it before that block runs.
    skipped: list[str] = [LABELS[k] for k in LABELS if k not in matches and k != "densita"]

    for key, sheet_name in matches.items():
        tmp_path = None
        try:
            # Keep the extracted source available to every tab that reloads
            # from the shared cache after this import returns.
            tmp_path = _extract_sheet_to_temp(master_path, sheet_name, persistent=True)
            _route(key, tmp_path, tmp_path, situazione_tab, magazino_tab, biglietti_tab, prezzi_tab)
            loaded.append(LABELS[key])
        except Exception:
            skipped.append(LABELS[key])

    normalized = {_norm(s) for s in sheetnames}
    if _norm("Entry") in normalized and normalized.intersection({_norm("Densita"), _norm("Densità")}):
        try:
            _route("densita", master_path, master_path, situazione_tab, magazino_tab, biglietti_tab)
            loaded.append(LABELS["densita"])
        except Exception as exc:
            skipped.append(f"{LABELS['densita']} (Error: {exc})")
    else:
        skipped.append(LABELS["densita"])

    return loaded, skipped


def import_master_directory(
    dir_path: str | Path,
    situazione_tab,
    magazino_tab,
    biglietti_tab=None,
    prezzi_tab=None,
    skip_keys: set[str] | None = None,
    settimana_tab=None,
) -> tuple[list[str], list[str]]:
    """Scan *dir_path* for all recognized factory files and route each to its
    respective loaders, caches, and GUI tabs.
    Returns (loaded_items, skipped_items)."""
    dir_path = Path(dir_path)
    matched = find_files_in_directory(dir_path)

    loaded: list[str] = []
    skipped: list[str] = []

    skip_keys = skip_keys or set()
    for key in DIRECTORY_FILE_CANDIDATES:
        if key in skip_keys:
            continue
        if key not in matched:
            skipped.append(LABELS.get(key, key))
            continue

        file_path = matched[key]
        if file_path.stat().st_size == 0:
            skipped.append(f"{LABELS.get(key, key)} (Empty file: {file_path.name})")
            continue
        try:
            _route(
                key, str(file_path), str(file_path), situazione_tab, magazino_tab,
                biglietti_tab, prezzi_tab, settimana_tab,
            )
            loaded.append(f"{LABELS.get(key, key)} ({file_path.name})")
        except Exception as exc:
            skipped.append(f"{LABELS.get(key, key)} (Error: {exc})")

    return loaded, skipped


def _route(
    key: str,
    tmp_path: str,
    master_path: str,
    situazione_tab,
    magazino_tab,
    biglietti_tab=None,
    prezzi_tab=None,
    settimana_tab=None,
) -> None:
    """Route one file/source to its proper tab, database, and cache handlers."""
    if key in ("dfm", "copertura", "data_prod", "wincoint", "uscita", "qualita"):
        if situazione_tab is not None:
            situazione_tab._handle_upload(key, tmp_path, cache_path=master_path)
        if key in ("dfm", "data_prod") and settimana_tab is not None:
            settimana_tab._handle_upload(key, master_path)

    elif key == "codes":
        if situazione_tab is not None:
            situazione_tab._handle_codes_upload("codes", tmp_path, cache_path=master_path)
        else:
            import utility.situazione_db as situazione_db
            import parsers.situazione_loaders as situazione_loaders
            from utility.articoli_cache import save_articoli_cache
            df, _ = situazione_loaders.load_codes(tmp_path)
            if df is not None:
                situazione_db.save_codes(df)
            save_articoli_cache(master_path)
        if biglietti_tab is not None:
            biglietti_tab.articoli_path = Path(master_path)
            if hasattr(biglietti_tab, "_restore"):
                try:
                    biglietti_tab._restore()
                except Exception as _ignored:
                    logger.debug("pipelines.master_import._route: ignored %r", _ignored)

    elif key == "listini":
        if situazione_tab is not None:
            situazione_tab._handle_listini_upload("listini", tmp_path, cache_path=master_path)
        else:
            from utility.prezzi_cache import save_prezzi_cache
            save_prezzi_cache(master_path)
        if prezzi_tab is not None:
            try:
                if hasattr(prezzi_tab, "_load_path"):
                    post_to_ui(prezzi_tab, lambda: prezzi_tab._load_path(master_path, save_cache=False))
                elif hasattr(prezzi_tab, "load_file"):
                    post_to_ui(prezzi_tab, lambda: prezzi_tab.load_file(master_path))
            except Exception as _ignored:
                logger.debug("pipelines.master_import._route: ignored %r", _ignored)
        if biglietti_tab is not None and hasattr(biglietti_tab, "_restore"):
            try:
                biglietti_tab._restore()
            except Exception as _ignored:
                logger.debug("pipelines.master_import._route: ignored %r", _ignored)

    elif key == "magazino":
        if magazino_tab is not None:
            magazino_tab._on_upload_magazino(tmp_path, cache_path=master_path)
        if biglietti_tab is not None and hasattr(biglietti_tab, "_restore"):
            try:
                biglietti_tab._restore()
            except Exception as _ignored:
                logger.debug("pipelines.master_import._route: ignored %r", _ignored)

    elif key == "lotti":
        if magazino_tab is not None:
            magazino_tab._on_upload_lotti(tmp_path, cache_path=master_path)

    elif key == "biglietti_template":
        if biglietti_tab is not None and hasattr(biglietti_tab, "set_template_path"):
            biglietti_tab.set_template_path(tmp_path)

    elif key == "densita":
        from utility import source_hub
        rows, errors = source_hub.save_densita(master_path)
        if not rows:
            raise ValueError("; ".join(errors) or "No density rows were found.")
        if situazione_tab is not None and hasattr(situazione_tab, "refresh_prezzo_densita"):
            try:
                situazione_tab.refresh_prezzo_densita()
            except Exception as _ignored:
                logger.debug("pipelines.master_import._route: ignored %r", _ignored)
        # Densita is shared by Biglietti and Ordine MED. Persist the same
        # source path and update Ordine MED's visible selection directly.
        if biglietti_tab is not None:
            biglietti_tab.densita_path = Path(master_path)
            if hasattr(biglietti_tab, "densita_label"):
                post_to_ui(biglietti_tab, lambda: biglietti_tab.densita_label.config(text=str(master_path), foreground="#111827"))
            if hasattr(biglietti_tab, "_restore"):
                try:
                    biglietti_tab._restore()
                except Exception as _ignored:
                    logger.debug("pipelines.master_import._route: ignored %r", _ignored)
        ordine_med_tab = getattr(situazione_tab, "ordine_med_tab", None) if situazione_tab is not None else None
        if ordine_med_tab is not None:
            ordine_med_tab.densita_path = Path(master_path)
            if hasattr(ordine_med_tab, "_lbl_densita"):
                post_to_ui(ordine_med_tab, lambda: ordine_med_tab._lbl_densita.config(text=str(master_path), foreground="black"))

    elif key == "data_ordine":
        save_source("data_ordine", master_path)
        if biglietti_tab is not None:
            biglietti_tab.data_path = Path(master_path)
            if hasattr(biglietti_tab, "biglietti_data_path_label"):
                biglietti_tab.biglietti_data_path_label.config(text=str(master_path), foreground="#111827")
            if hasattr(biglietti_tab, "_save_prefs"):
                biglietti_tab._save_prefs(biglietti_data_path=str(master_path))

    elif key == "dispo_bagno":
        save_source("dispo_bagno", master_path)
        if biglietti_tab is not None:
            biglietti_tab.dispo_path = Path(master_path)
            if hasattr(biglietti_tab, "biglietti_dispo_path_label"):
                biglietti_tab.biglietti_dispo_path_label.config(text=str(master_path), foreground="#111827")
            if hasattr(biglietti_tab, "_save_prefs"):
                biglietti_tab._save_prefs(biglietti_dispo_path=str(master_path))
