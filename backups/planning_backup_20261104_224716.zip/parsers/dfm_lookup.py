"""
dfm_lookup.py — Loads the DFM.xlsx historical dye-job export (Elvy-specific)
and looks up a Purchase Order row's colour against it to retrieve Delta's
own colour code (COLOREDFM) and colour name (CLDESCR).

Background
----------
DFM.xlsx is a historical export of dye jobs. Article codes (ARTICOLODFM)
for the Elvy client always start with "C130...". Their raw (griege)
equivalent — "Articolo Delta" — is the same digits with "G" instead of
"C" (e.g. "C130027S" <-> "G130027S"). "Articolo Delta" itself is resolved
separately from a PDF row's Article No via the user-maintained mapping in
elvy_mapping.py; this module only handles the colour side.

Matching algorithm (verified against real DFM.xlsx + confirmed examples)
--------------------------------------------------------------------------
1. The PDF's Colore field (OrderRow.colour, e.g. "440") is NOT the same
   number as COLOREDFM or any fixed slice of it — matching against
   COLOREDFM directly is unreliable. What actually works is CLDESCR: it's
   almost always "EL-<colour><1-2 extra client digits><optional suffix>",
   e.g. "EL-44011-DOUBLEYARN" for colour "440". So colour is matched as a
   prefix of the digits after "EL-" in CLDESCR.

2. DESCRIZARTICOLOLI (e.g. "0070  100.00 2") ends with a twist digit that
   exactly matches Ne's denominator: Ne "100/2" -> twist "2" (double),
   "80/1" -> "1" (single), ".../3" -> "3" (triple). This is a reliable
   structural fact, unlike the colour digits.

3. Dye type / yarn keywords: CLDESCR sometimes carries extra qualifiers
   that must also match:
     - dye_type containing "react" (Reattivo/Reactive) -> CLDESCR must
       also contain "REATT" or "REACT".
     - yarn containing "tencel" -> CLDESCR must also contain "TENCEL".
     - yarn containing "kashmir"/"cashmere" -> CLDESCR must also contain
       "KASHMIR" (no confirmed example in the data yet, kept best-effort).
     - Vat is the default/unmarked case — no extra keyword required.

4. Search order:
     a. PRIMARY: rows whose ARTICOLODFM matches this row's Articolo Delta
        (G->C swapped) exactly, plus the colour/twist/keyword filters
        above. Most recent DATAINS wins among matches.
     b. FALLBACK: if (a) finds nothing — e.g. this exact article was
        never dyed in this colour before — broaden to ANY Elvy (C130*)
        article with the same colour/twist/keyword filters. This mirrors
        what happens at the factory: the same colour recipe is reused
        across a family of related articles, so the most recent match
        from a *different* article is still the right answer far more
        often than leaving the cell blank.
     c. If neither finds anything, leave both columns blank — never guess.

This is explicitly a best-effort heuristic on messy, free-text factory
data (confirmed ~85-95% consistent per criterion, not 100%) — it is
expected to be refined further as more real examples turn up.

Caching
-------
Parsing the full DFM export is a one-off upload action. The normalized
filtered rows are persisted in SQLite and restored from SQLite after restart,
so the original (large) DFM.xlsx is not required again unless the operator
explicitly uploads a newer source. A fresh upload replaces the corresponding
prefix snapshot.
"""

from __future__ import annotations

import re
import pandas as pd
from datetime import datetime
from pathlib import Path
from typing import Any

import openpyxl

from utility.utils import APP_DATA_DIR, clean_text, logger

CACHE_FILE = APP_DATA_DIR / "settings" / "dfm_color_cache.json"

# DFM is persisted in SQLite. An explicit upload replaces the corresponding
# snapshot; restart restores the normalized data from SQLite without requiring
# the original workbook path to remain available.
_ACTIVE_DFM_CACHE: dict[str, dict[str, Any]] = {}

# Only rows whose ARTICOLODFM starts with this prefix are relevant to Elvy.
ELVY_ARTICLE_PREFIX = "C130"

# Every customer prefix a DFM upload is saved for (Elvy first).
SUPPORTED_DFM_PREFIXES = (ELVY_ARTICLE_PREFIX, "C170", "C010", "C011")
_PAIRS_SNAPSHOT = "dfm:pairs"
_ACTIVE_DFM_PAIRS: set[tuple[str, str]] | None = None


def _cache_file_for(prefix: str) -> Path:
    """Elvy's C130 cache keeps its original filename (backward compatible);
    every other prefix (e.g. Kamal's C170) gets its own cache file."""
    if prefix == ELVY_ARTICLE_PREFIX:
        return CACHE_FILE
    return APP_DATA_DIR / "settings" / f"dfm_color_cache_{prefix}.json"

REQUIRED_COLUMNS = ("ARTICOLODFM", "COLOREDFM", "CLDESCR", "DESCRIZARTICOLOLI", "DATAINS")

# Keyword groups: if the PDF-side condition (checked against dye_type or
# yarn) is met, CLDESCR must contain at least one of the listed variants.
_REACTIVE_CLDESCR_HINTS = ("REATT", "REACT")
_TENCEL_CLDESCR_HINTS = ("TENCEL",)
_KASHMIR_CLDESCR_HINTS = ("KASHMIR", "KASCHMIR", "CASHMER")


def _parse_date(text: str) -> datetime | None:
    """Parse a DD/MM/YYYY date string. Returns None if unparseable."""
    text = clean_text(text)
    if not text:
        return None
    try:
        return datetime.strptime(text, "%d/%m/%Y")
    except ValueError:
        return None


def _twist_digit(descrizarticololi: str) -> str:
    """Extract the trailing twist digit ('1'/'2'/'3'/...) from a
    DESCRIZARTICOLOLI string like '0070  100.00 2'. Returns "" if absent."""
    parts = clean_text(descrizarticololi).split()
    return parts[-1] if parts and parts[-1].isdigit() else ""


def _titolo(descrizarticololi: str) -> str:
    """
    Parse the yarn Titolo ('100/2', '70/1', ...) out of a DESCRIZARTICOLOLI
    string like '0070  100.00 2' -- verified against a real Articoli.xlsx
    reference: '0054  070.00 1' -> Titolo '70/1', '0070  100.00 2' -> '100/2'.
    Returns "" if the format doesn't match.
    """
    parts = clean_text(descrizarticololi).split()
    if len(parts) < 3:
        return ""
    count_str, ply = parts[-2], parts[-1]
    if not ply.isdigit():
        return ""
    try:
        count = int(round(float(count_str)))
    except ValueError:
        return ""
    return f"{count}/{ply}"


def _ne_twist_digit(ne: str) -> str:
    """Extract the twist digit from an Ne value like '100/2'. Returns "" if absent."""
    ne = clean_text(ne)
    if "/" in ne:
        denom = ne.split("/")[-1].strip()
        if denom.isdigit():
            return denom
    return ""


# ---------------------------------------------------------------------------
# Building / caching the filtered reference
# ---------------------------------------------------------------------------

def _dfm_header_key(value) -> str:
    """Case/whitespace-insensitive header match -- an ERP export changing
    "ARTICOLODFM" to "Articolodfm " (or similar cosmetic drift) between
    versions must not break the whole lookup; a genuinely different/missing
    column should still raise the clear error below, not silently misread
    a column."""
    return re.sub(r"\s+", "", str(value or "")).upper()


class DfmReference:
    """What ONE read of a DFM workbook yields."""

    def __init__(self, entries: dict[str, list[dict[str, str]]], pairs: set[tuple[str, str]]):
        self.entries = entries      # prefix -> lookup rows (articolo, coloredfm, cldescr, twist, titolo, date)
        self.pairs = pairs          # every (ARTICOLODFM, COLOREDFM), any prefix, even without CLDESCR


def build_dfm_reference(xlsx_path: Path, prefixes: tuple[str, ...] = SUPPORTED_DFM_PREFIXES) -> DfmReference:
    """Read *xlsx_path* (a DFM.xlsx-style export) once.

    Per prefix: the rows whose ARTICOLODFM starts with it, reduced to the fields
    needed for matching. Plus the set of every (ARTICOLODFM, COLOREDFM) pair in
    the file -- including rows without CLDESCR and articles of other customers --
    which is what Ordine MED's "Check Articolo" needs: has this Articolo+Colore
    combination ever been dyed?
    """
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    ws = wb["DFM"] if "DFM" in wb.sheetnames else wb.active

    header_row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True))
    headers = [_dfm_header_key(h) for h in header_row]

    missing = [c for c in REQUIRED_COLUMNS if c not in headers]
    if missing:
        wb.close()
        raise ValueError(
            f"This file doesn't look like a DFM export — missing column(s): "
            f"{', '.join(missing)}"
        )
    col_idx = {name: headers.index(name) for name in REQUIRED_COLUMNS}

    entries: dict[str, list[dict[str, str]]] = {prefix: [] for prefix in prefixes}
    pairs: set[tuple[str, str]] = set()
    for row in ws.iter_rows(min_row=2, values_only=True):
        articolo = clean_text(row[col_idx["ARTICOLODFM"]])
        if not articolo:
            continue
        coloredfm = clean_text(row[col_idx["COLOREDFM"]])
        pairs.add((articolo.upper(), coloredfm))
        prefix = next((p for p in prefixes if articolo.startswith(p)), None)
        if prefix is None:
            continue
        cldescr = clean_text(row[col_idx["CLDESCR"]])
        if not coloredfm or not cldescr:
            continue
        date = _parse_date(row[col_idx["DATAINS"]])
        entries[prefix].append({
            "articolo": articolo,
            "coloredfm": coloredfm,
            "cldescr": cldescr,
            "twist": _twist_digit(row[col_idx["DESCRIZARTICOLOLI"]]),
            "titolo": _titolo(row[col_idx["DESCRIZARTICOLOLI"]]),
            "date": date.isoformat() if date else "",
        })

    wb.close()
    logger.info(
        "Built DFM reference from %s: %s; %d Articolo/Colore pair(s)",
        xlsx_path.name, ", ".join(f"{p}={len(rows)}" for p, rows in entries.items()), len(pairs),
    )
    return DfmReference(entries, pairs)


def build_dfm_lookup(xlsx_path: Path, prefix: str = ELVY_ARTICLE_PREFIX) -> list[dict[str, str]]:
    """Lookup rows for a single *prefix* (default "C130", Elvy); see build_dfm_reference."""
    return build_dfm_reference(xlsx_path, (prefix,)).entries[prefix]


def _dfm_snapshot_name(prefix: str) -> str:
    return f"dfm:{clean_text(prefix).upper()}"


def _entries_frame(entries: list[dict[str, str]]) -> pd.DataFrame:
    return pd.DataFrame(list(entries or []))


def save_dfm_workbook(
    source_path: Path,
    source_name: str | None = None,
    prefixes: tuple[str, ...] = SUPPORTED_DFM_PREFIXES,
) -> dict[str, int]:
    """Import one DFM workbook into SQLite for every supported customer prefix.

    The workbook is an update input only. Runtime consumers use the snapshots
    created here (per-prefix lookups + every Articolo/Colore pair), all from a
    single read of the file. Empty prefixes are saved as empty snapshots too,
    so an upload with no rows for a customer cannot resurrect an older snapshot.
    """
    source_path = Path(source_path)
    source_name = source_name or source_path.name
    reference = build_dfm_reference(source_path, prefixes)
    counts: dict[str, int] = {}
    for prefix in prefixes:
        entries = reference.entries.get(prefix, [])
        save_dfm_cache(entries, source_name, source_path, prefix=prefix, invalidate_others=False)
        counts[prefix] = len(entries)
    save_dfm_pairs(reference.pairs, source_path)
    # One explicit workbook upload is one logical source. Store its metadata
    # after all snapshots are committed.
    try:
        from utility import situazione_db as db
        db.save_upload(
            "dfm", source_name, sum(counts.values()), "ok",
            f"DFM imported: {counts}", file_path=str(source_path),
        )
    except Exception as exc:
        logger.warning("Could not persist DFM upload metadata: %s", exc)
    return counts


def save_dfm_pairs(pairs: set[tuple[str, str]], source_path: Path | None = None) -> bool:
    """Persist every Articolo/Colore pair of the uploaded DFM; True when it changed."""
    global _ACTIVE_DFM_PAIRS
    ordered = sorted(pairs)
    _ACTIVE_DFM_PAIRS = set(ordered)
    try:
        from utility import situazione_db as db
        db.init_db()
        frame = pd.DataFrame(ordered, columns=["articolo", "coloredfm"])
        return bool(db.save_frame_cache(_PAIRS_SNAPSHOT, frame, source_path=source_path))
    except Exception as exc:
        logger.warning("Could not persist DFM Articolo/Colore pairs: %s", exc)
        return True


def load_dfm_pairs() -> set[tuple[str, str]]:
    """Every (ARTICOLODFM, COLOREDFM) pair of the saved DFM, straight from SQLite.

    Ordine MED's "Check Articolo" uses this, so it works after a restart with no
    workbook on disk and counts rows the lookup snapshots leave out (no CLDESCR,
    other customers). A DFM saved before pairs existed falls back to the rows of
    all four lookup snapshots (a subset) until the DFM is uploaded again.
    """
    global _ACTIVE_DFM_PAIRS
    if _ACTIVE_DFM_PAIRS is not None:
        return _ACTIVE_DFM_PAIRS
    try:
        from utility import situazione_db as db
        db.init_db()
        frame = db.load_frame_cache(_PAIRS_SNAPSHOT)
        if frame is not None and not frame.empty:
            _ACTIVE_DFM_PAIRS = {
                (clean_text(a).upper(), clean_text(c))
                for a, c in zip(frame["articolo"], frame["coloredfm"]) if clean_text(a)
            }
            return _ACTIVE_DFM_PAIRS
    except Exception as exc:
        logger.warning("Could not restore DFM Articolo/Colore pairs: %s", exc)
    return {
        (clean_text(e.get("articolo")).upper(), clean_text(e.get("coloredfm")))
        for prefix in SUPPORTED_DFM_PREFIXES for e in load_dfm_entries_by_prefix(prefix)
        if clean_text(e.get("articolo"))
    }


def save_dfm_cache(
    entries: list[dict[str, str]],
    source_name: str,
    source_path: Path | None = None,
    prefix: str = ELVY_ARTICLE_PREFIX,
    invalidate_others: bool = True,
) -> bool:
    """Persist the normalized DFM lookup in SQLite and keep an in-memory copy.

    SQLite is the source of truth across application restarts. A fresh upload
    replaces the corresponding prefix snapshot, even when the file has the
    same path/name as yesterday's export. Returns True when the stored data
    changed. Saving the default prefix on its own drops the other prefixes (they
    came from the previous upload); save_dfm_workbook saves them all itself and
    passes invalidate_others=False.
    """
    global _ACTIVE_DFM_PAIRS
    payload: dict[str, Any] = {
        "source_file": source_name,
        "source_path": str(source_path) if source_path else "",
        "loaded_at": datetime.now().isoformat(timespec="seconds"),
        "entries": list(entries or []),
    }
    _ACTIVE_DFM_CACHE[prefix] = payload
    changed = True
    try:
        from utility import situazione_db as db
        db.init_db()
        # Saving the default prefix on its own is a fresh explicit DFM upload: the
        # other prefixes' snapshots and the Articolo/Colore pairs come from the
        # previous upload and are stale until the new workbook is read for them.
        if prefix == ELVY_ARTICLE_PREFIX and invalidate_others:
            conn = db.get_conn()
            stale = [_dfm_snapshot_name(p) for p in SUPPORTED_DFM_PREFIXES if p != prefix] + [_PAIRS_SNAPSHOT]
            for name in stale:
                conn.execute("DELETE FROM source_snapshot WHERE source_name=?", (name,))
                conn.execute("DELETE FROM source_snapshot_row WHERE source_name=?", (name,))
            conn.commit(); conn.close()
            for other in [key for key in _ACTIVE_DFM_CACHE if key != prefix]:
                del _ACTIVE_DFM_CACHE[other]
            _ACTIVE_DFM_PAIRS = None
        changed = bool(db.save_frame_cache(_dfm_snapshot_name(prefix), _entries_frame(entries), source_path=source_path))
    except Exception as exc:
        logger.warning("Could not persist DFM snapshot for %s: %s", prefix, exc)
    # Remove legacy JSON caches so there is one persistence authority.
    try:
        legacy = _cache_file_for(prefix)
        if legacy.exists():
            legacy.unlink()
    except OSError as exc:
        logger.warning("Could not remove legacy DFM cache (%s): %s", prefix, exc)
    return changed


def active_dfm_source() -> Path | None:
    """Return the persisted DFM path when it still exists; the data itself
    remains usable from SQLite even when the original workbook is gone."""
    source = clean_text(load_dfm_cache().get("source_path"))
    return Path(source) if source and Path(source).is_file() else None


def load_dfm_cache(prefix: str = ELVY_ARTICLE_PREFIX) -> dict[str, Any]:
    """Load DFM from memory first, then SQLite after application restart."""
    payload = _ACTIVE_DFM_CACHE.get(prefix)
    if payload is not None:
        return payload
    try:
        from utility import situazione_db as db
        db.init_db()
        frame = db.load_frame_cache(_dfm_snapshot_name(prefix))
        if frame is not None and not frame.empty:
            entries = frame.fillna("").to_dict(orient="records")
            uploads = db.get_upload("dfm") or {}
            payload = {
                "source_file": uploads.get("file_name", ""),
                "source_path": uploads.get("file_path", ""),
                "loaded_at": uploads.get("uploaded_at", ""),
                "entries": [{str(k): clean_text(v) for k, v in row.items()} for row in entries],
            }
            _ACTIVE_DFM_CACHE[prefix] = payload
            return payload
    except Exception as exc:
        logger.warning("Could not restore DFM snapshot for %s: %s", prefix, exc)
    return {"source_file": "", "source_path": "", "loaded_at": "", "entries": []}


# ---------------------------------------------------------------------------
# Lookup
# ---------------------------------------------------------------------------

# Real POs express Colour in several different raw formats:
#   "205"                  -> plain numeric code
#   "009.Red Water Color"  -> numeric code + descriptive name after a dot
#   "R.1372"               -> "R." (Reactive marker) + numeric code — this
#                             one does NOT require a literal "R" in CLDESCR;
#                             it just echoes dye_type, already checked
#                             separately via _required_cldescr_hints.
#   "G.203"                -> "G" client marker + numeric code
#   "MO_0030.CELESTE"      -> "MO" client marker + numeric code + name
#
# "G" and "MO" are NOT decorative — they mark colours belonging to a
# different client/family that happen to share DFM's colour numbering.
# CLDESCR encodes the same marker as "EL-G-<num>" / "EL-MO-<num>" (with a
# dash) vs plain "EL-<num>" — and these can be genuinely different colours
# for the very same numeric code (confirmed: article C130078S has both
# "EL-45311" (plain) and "EL-G-453" (G-marked) as two distinct COLOREDFM
# entries). So the marker must match exactly, not just be tolerated.
_COLOUR_PREFIX_RE = re.compile(r"^(?P<marker>R|G|MO)[._\-\s]+", re.IGNORECASE)
_COLOUR_CODE_RE = re.compile(r"(\d+)[.\s_\-]*(.*)$")

_CLDESCR_CODE_RE = re.compile(r"EL-(?:(?P<marker>MO|G)-?)?(?P<code>\d+)", re.IGNORECASE)


def _extract_colour_code(colour: str) -> tuple[str, str, str]:
    """
    Split a raw Colour field into (numeric_code, descriptive_name, marker).
    marker is "G" or "MO" when that client-prefix is present, "" otherwise
    (including for the "R." Reactive prefix, which carries no CLDESCR
    marker of its own). Returns ("", "", "") if no digits are found.
    """
    text = clean_text(colour)
    marker = ""
    # Reactive colours can carry the dye marker and the client marker
    # together, e.g. ``R.G.4257``. Consume all leading markers so the
    # meaningful client marker (G/MO) is retained for CLDESCR matching.
    while True:
        prefix_match = _COLOUR_PREFIX_RE.match(text)
        if not prefix_match:
            break
        found = prefix_match.group("marker").upper()
        if found in ("G", "MO"):
            marker = found
        text = text[prefix_match.end():]
    m = _COLOUR_CODE_RE.match(text)
    if not m:
        return "", "", ""
    return m.group(1), m.group(2).strip(" .-_"), marker


def _required_cldescr_hints(dye_type: str, yarn: str) -> list[str]:
    """
    Return groups of CLDESCR keyword alternatives that must each be
    satisfied (at least one variant per group) given this row's dye_type
    and yarn composition.
    """
    dye_type = clean_text(dye_type).lower()
    yarn = clean_text(yarn).lower()
    groups: list[tuple[str, ...]] = []

    if "react" in dye_type:
        groups.append(_REACTIVE_CLDESCR_HINTS)
    if "tencel" in yarn:
        groups.append(_TENCEL_CLDESCR_HINTS)
    if "kashmir" in yarn or "cashmere" in yarn or "kaschmir" in yarn:
        groups.append(_KASHMIR_CLDESCR_HINTS)
    return groups


def _matches_filters(
    entry: dict[str, str],
    colour_code: str,
    marker: str,
    twist: str,
    hint_groups: list[tuple[str, ...]],
    name_hint: str = "",
) -> bool:
    """True when a DFM entry's CLDESCR matches the wanted colour.
    The number in CLDESCR must be the colour code exactly, or the code plus a standard 2-digit client sub-code ("440" -> "44011"); the marker, twist and name-hint filters then narrow it further.
    """
    cldescr_upper = entry["cldescr"].upper()

    m = _CLDESCR_CODE_RE.match(cldescr_upper)
    if not m:
        return False
    code = m.group("code")
    # CLDESCR's number is either the colour code exactly, or the code plus
    # a standard 2-digit client sub-code suffix (e.g. "440" -> "44011").
    # Any OTHER extra length (e.g. "151" -> "151711") is a coincidental
    # prefix match against a genuinely different, longer colour number
    # (here, "1517") — not the same colour — so it must be rejected.
    if len(code) not in (len(colour_code), len(colour_code) + 2) or not code.startswith(colour_code):
        return False
    if (m.group("marker") or "") != marker:
        return False

    if twist and entry["twist"] and entry["twist"] != twist:
        return False

    for group in hint_groups:
        if not any(hint in cldescr_upper for hint in group):
            return False

    if name_hint and name_hint.upper() not in cldescr_upper:
        return False

    return True


def _best_match(candidates: list[dict[str, str]]) -> dict[str, str] | None:
    if not candidates:
        return None
    return max(candidates, key=lambda e: e["date"])


def _guess_new_colour(
    colour_code: str, colour_name: str, yarn: str
) -> tuple[str, str]:
    """
    Best-effort guess for a colour with NO dyeing history at all yet (not
    even via the broadened fallback search) — confirmed with the user that
    such codes are sometimes invented by hand for a first-time colour, and
    that a genuinely new code isn't necessarily in the DFM export we have.

    Only one case has a reliable enough mechanical pattern to predict:
    Kaschmir/Cashmere yarns consistently get a COLOREDFM starting with
    "37" followed by the colour digits exactly (confirmed ~99% consistent
    across the full Elvy history — e.g. colour "1100" -> "371100"). For
    anything else, there's no reliable pattern to invent a code from, so
    we only echo the colour's own descriptive name (if it has one) into
    CLDESCR and leave COLOREDFM blank for manual entry, per the user's
    explicit instruction.
    """
    yarn_lower = clean_text(yarn).lower()
    if colour_code and ("kaschmir" in yarn_lower or "kashmir" in yarn_lower or "cashmere" in yarn_lower):
        return f"37{colour_code}", f"EL-{colour_code}-KASCHMIR"

    if colour_name:
        return "", colour_name.upper()

    return "", ""


def lookup_dfm_color(
    articolo_delta: str,
    colour: str,
    ne: str,
    dye_type: str,
    yarn: str,
    entries: list[dict[str, str]],
) -> tuple[str, str]:
    """
    Look up (COLOREDFM, CLDESCR) for a Purchase Order row.

    articolo_delta : this row's resolved Delta raw code (e.g. "G130027S"),
                      from the Elvy Article No mapping — "" if unresolved.
    colour          : the PDF's Colore value. Handles the several raw
                      formats seen in practice — plain numbers ("440"),
                      a number + descriptive name ("009.Red Water Color",
                      "MO_0030.CELESTE"), or a letter-prefixed number
                      ("R.1372", "G.203") — see _extract_colour_code.
    ne              : the PDF's Ne value (e.g. "100/2") — its denominator
                      gives the required twist.
    dye_type, yarn  : used to require extra CLDESCR keywords (Reattivo/
                      Reactive, Tencel, Kashmir/Kaschmir) when applicable.

    Search order: same article code first, then any Elvy article as a
    fallback; within each, prefer a match whose CLDESCR also contains the
    colour's descriptive name (when it has one) before dropping that
    requirement. If nothing at all is found — this colour has never been
    dyed for Elvy before — falls back to _guess_new_colour as a last
    resort: a mechanical prediction for Kaschmir yarns, or just the
    colour's own descriptive name with the code left blank otherwise.
    """
    colour_code, colour_name, marker = _extract_colour_code(colour)
    if not colour_code:
        return "", ""
    twist = _ne_twist_digit(ne)
    hint_groups = _required_cldescr_hints(dye_type, yarn)

    articolo_c = ""
    articolo_delta = clean_text(articolo_delta)
    if articolo_delta.upper().startswith("G"):
        articolo_c = "C" + articolo_delta[1:]

    pools = [
        [e for e in entries if e["articolo"] == articolo_c] if articolo_c else [],
        entries,
    ]
    name_preferences = [colour_name, ""] if colour_name else [""]
    # Try requiring the dye/yarn keywords (e.g. "REATTIVO") first, but some
    # CLDESCR entries (fibre-special ones like Kaschmir in particular) don't
    # carry that tag even when it applies, so fall back to not requiring it.
    hint_levels = [hint_groups, []] if hint_groups else [[]]

    for pool in pools:
        if not pool:
            continue
        for hints in hint_levels:
            for name_hint in name_preferences:
                candidates = [
                    e for e in pool
                    if _matches_filters(e, colour_code, marker, twist, hints, name_hint)
                ]
                best = _best_match(candidates)
                if best:
                    return best["coloredfm"], best["cldescr"]

    return _guess_new_colour(colour_code, colour_name, yarn)


_ARABIC_LETTERS_RE = re.compile(r"[\u0600-\u06FF]")
# A Pantone-style reference such as "13-0608 TCX" or "(17-1212 TCX)".
_PANTONE_RE = re.compile(r"\(?\s*\d{2}\s*-\s*\d{4}\s*(?:TCX|TPX|TPG|C)?\s*\)?")


def colour_name_key(name: str) -> str:
    """Comparable form of a colour *name*, so that every spelling of the same
    colour meets in one key.

    DFM writes the same colour as "KA-MENT 4" or "KA-MENT 4 - 13-0608 TCX",
    while the order PDF carries "MENT 4", sometimes with a stray Arabic letter
    stuck to it ("صMENT 4").  Dropped before comparing: Arabic letters, the
    "KA" customer tag, the Pantone reference and all punctuation/spacing.
    "KA-MENT 4 - 13-0608 TCX", "KA-MENT 4", "MENT 4" and "صMENT 4" -> "MENT4".
    """
    text = clean_text(name).upper()
    text = text.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
    text = _ARABIC_LETTERS_RE.sub(" ", text)
    text = _PANTONE_RE.sub(" ", text)
    text = re.sub(r"[^0-9A-Z]+", " ", text)
    tokens = text.split()
    if tokens and tokens[0] == "KA":
        tokens = tokens[1:]
    elif tokens and tokens[-1] == "KA":      # an RTL cell can put the tag last
        tokens = tokens[:-1]
    return "".join(tokens)


def lookup_dfm_color_by_name(
    colour_name: str,
    entries: list[dict[str, str]],
    articolo: str = "",
) -> tuple[str, str]:
    """(COLOREDFM, CLDESCR) of the DFM entry carrying this colour *name*, or
    ("", "") when DFM has none.

    Names are compared through colour_name_key(), so the PDF's short name finds
    the DFM entry whichever of its spellings DFM uses.  Several entries can
    share one name (other articles, other dates): the one for *articolo*
    (when given) wins, then the most recent, then the fullest description.
    """
    key = colour_name_key(colour_name)
    if not key:
        return "", ""
    articolo = clean_text(articolo)
    candidates = [
        e for e in entries
        if clean_text(e.get("coloredfm")) and colour_name_key(e.get("cldescr", "")) == key
    ]
    if not candidates:
        return "", ""
    best = max(
        candidates,
        key=lambda e: (
            bool(articolo) and e.get("articolo") == articolo,
            e.get("date", ""),
            len(clean_text(e.get("cldescr"))),
        ),
    )
    return clean_text(best["coloredfm"]), clean_text(best["cldescr"])


def raw_to_finished_articolo(articolo_delta) -> str | None:
    """G170xxxx (raw yarn Articolo Delta) -> C170xxxx (finished Articolo) --
    the same C<->G swap used throughout (DFM, Listini/Prezzi, raw yarn
    matching). Returns None when articolo_delta isn't G-prefixed."""
    a = clean_text(articolo_delta).upper()
    if a.startswith("G") and len(a) > 1:
        return "C" + a[1:]
    return None


def is_first_time_dyeing(
    articolo_delta: str, coloredfm: str, entries: list[dict[str, str]]
) -> bool:
    """
    True when this exact Articolo Delta + COLOREDFM pair has no prior entry
    at all in the DFM reference -- i.e. this article has genuinely never
    been dyed in this colour before, so it's worth flagging for a manual
    double-check ("prima volta tint.") rather than trusting the automatic
    match, which may have come from lookup_dfm_color()'s broadened fallback
    (a different, related article) or its last-resort guess.

    A blank COLOREDFM (no DFM match found at all, not even via fallback or
    the Kaschmir guess) also counts as first-time -- there's clearly no
    history for it either way. An unresolved Articolo Delta means there's
    nothing reliable to check against, so it's treated as first-time too
    rather than silently passing.
    """
    coloredfm = clean_text(coloredfm)
    articolo_c = raw_to_finished_articolo(articolo_delta)
    if not coloredfm or not articolo_c:
        return True
    return not any(
        e["articolo"] == articolo_c and e["coloredfm"] == coloredfm
        for e in entries
    )


def load_dfm_entries_by_prefix(prefix: str) -> list[dict[str, str]]:
    """Return persisted DFM entries for a customer prefix.

    The SQLite snapshot is sufficient; the original workbook is only needed
    when the operator explicitly uploads a new DFM.
    """
    cached = load_dfm_cache(prefix=prefix)
    if cached.get("entries"):
        return cached["entries"]
    # During the current explicit upload, another prefix can be derived lazily
    # from the same workbook. After restart, the SQLite snapshot is used and no
    # workbook is required.
    source_path = clean_text(load_dfm_cache().get("source_path"))
    if source_path and Path(source_path).is_file():
        try:
            entries = build_dfm_lookup(Path(source_path), prefix=prefix)
            if entries:
                save_dfm_cache(entries, Path(source_path).name, Path(source_path), prefix=prefix)
                return entries
        except Exception as exc:
            logger.warning("Could not derive DFM entries for prefix %s: %s", prefix, exc)
    return []


def find_articolo_by_titolo(entries: list[dict[str, str]], titolo: str) -> str:
    """
    Look up an Articolo whose Titolo matches *titolo* exactly (e.g. '80/2')
    within the given entries. Returns "" if titolo is blank or no match is
    found. If more than one distinct Articolo shares this Titolo, the first
    one encountered is returned -- ambiguous by nature, since Titolo alone
    doesn't uniquely identify an Articolo in general.
    """
    titolo = clean_text(titolo)
    if not titolo:
        return ""
    for e in entries:
        if e.get("titolo") == titolo:
            return e["articolo"]
    return ""
