import unittest
from pathlib import Path
from datetime import date
import tempfile
import pandas as pd
from unittest.mock import patch

from calculate.abbina_calculator import _smallest_fitting_machine
from calculate.abbina_suggestions import titles_compatible
from exporters.biglietti_exporter import _machine_for_count, _filato_rows
from exporters.biglietti_exporter import _get, _read_sheet_rows
from pipelines.master_import import find_files_in_directory
import pipelines.master_import as master_import
from calculate.situazione import compute_delivery_date, compute_delivery_dates
from calculate.lotti import load_lotti
from gui.tabs.overview_tab import _format_display_dates
from gui.tabs.overview_tab import _write_typed_excel_table
import openpyxl
import utility.path_manager as path_manager
from calculate.reports import compute_on_time_delivery
from calculate.prezzi import detect_price_anomalies
from pipelines.ordine_med import OrdineMedRow, assign_bagno_prepostato


class PlanningRegressionTests(unittest.TestCase):
    def test_med_bagno_sequence_keeps_only_split_rows(self):
        def row(colour, abbin, machine):
            return OrdineMedRow(
                riga=1, code_org="C010032S", titolo="30/1", descr_col="Blue",
                articolo="C010032S", colore=colour, rocc=24, abbin=abbin,
                consegna_input=None, pt_grg="", pt_med="", polmoni="",
                cliente_note="", nota_grg="", nota_col="", kg_note="",
                fabb="", prezz_note="", gruppo_macchina=machine,
            )

        records = [
            row("351", 0, 3306),
            row("304", 1, 3302),
            row("304", 1, 3302),
            row("305", 0, 3310),
        ]
        assign_bagno_prepostato(records, "T1200")
        self.assertEqual(
            [r.bagno_reale for r in records],
            ["T1200", "T1201", "T1201", "T1202"],
        )
        self.assertEqual([r.bagno_prepostato for r in records], ["", "", "T1201", ""])

    def test_med_bagno_sequence_is_disabled_or_blank_for_non_groups(self):
        records = []
        for index in range(2):
            records.append(OrdineMedRow(
                riga=index + 1, code_org="C010032S", titolo="30/1", descr_col="Blue",
                articolo="C010032S", colore="304", rocc=24, abbin=0,
                consegna_input=None, pt_grg="", pt_med="", polmoni="",
                cliente_note="", nota_grg="", nota_col="", kg_note="",
                fabb="", prezz_note="", gruppo_macchina=3302,
            ))
        assign_bagno_prepostato(records, None)
        self.assertEqual([r.bagno_prepostato for r in records], ["", ""])

    def test_med_bagno_sequence_rejects_invalid_start(self):
        with self.assertRaises(ValueError):
            assign_bagno_prepostato([], "1200")

    def test_med_bagno_number_counts_each_zero_row_before_abbin_groups(self):
        def row(index, abbin):
            return OrdineMedRow(
                riga=index, code_org="C010032S", titolo="30/1", descr_col="Blue",
                articolo="C010032S", colore=str(index), rocc=24, abbin=abbin,
                consegna_input=None, pt_grg="", pt_med="", polmoni="",
                cliente_note="", nota_grg="", nota_col="", kg_note="",
                fabb="", prezz_note="", gruppo_macchina=3302,
            )

        records = [row(i, 0) for i in range(1, 20)]
        records.extend([row(20, 1), row(21, 1), row(22, 2), row(23, 2), row(24, 3), row(25, 3)])
        assign_bagno_prepostato(records, "S1200")
        self.assertEqual([r.bagno_prepostato for r in records], [""] * 19 + ["", "S1219", "", "S1220", "", "S1221"])

    def test_empty_machine_group_has_no_capacity(self):
        self.assertEqual(_smallest_fitting_machine(0), 0)
        self.assertEqual(_smallest_fitting_machine(-1), 0)

    def test_copertura_codes_map_to_correct_machine_numbers_and_capacities(self):
        from calculate.constants import MACHINE_CAPACITY_BY_NUMBER
        from calculate.situazione import machine_label, machine_number_from_label

        expected = {
            3: (3309, 672),
            4: (3300, 672),
            5: (3308, 192),
            6: (3304, 384),
            7: (3307, 72),
            8: (3303, 128),
            9: (3306, 32),
            10: (3302, 56),
            11: (3301, 6),
            12: (3310, 24),
        }

        for number, (code, capacity) in expected.items():
            self.assertEqual(machine_number_from_label(str(code)), number)
            self.assertEqual(MACHINE_CAPACITY_BY_NUMBER[number], capacity)
            self.assertEqual(machine_label(number), f"M{number} ({capacity} rocche)")

    def test_machine_schedule_keeps_codice_for_per_machine_treeview(self):
        from calculate.situazione import build_machine_schedule

        situation = pd.DataFrame([{
            "bagno": "B-1", "cliente": "Cliente", "articolo": "A1",
            "titolo": "30/1", "codice": "00123", "colore": "Blu",
            "partita": "P-100", "rocche": 24, "ordine": "O-1", "riga": 1,
        }])
        copertura = pd.DataFrame([{"bagno": "B-1", "machine": "3309"}])

        schedule = build_machine_schedule(
            situation, copertura, today=date(2026, 10, 5)
        )

        self.assertEqual(schedule.loc[0, "codice"], "00123")
        self.assertEqual(schedule.loc[0, "colore"], "Blu")

    def test_machine_schedule_uses_elvy_delivery_date_and_three_day_buffer(self):
        from calculate.situazione import build_machine_schedule

        situation = pd.DataFrame([
            {
                "bagno": "B-1", "cliente": "3009", "articolo": "C130001S",
                "consegna": "2026-10-10", "delivery_date": "2026-10-15",
            },
            {
                "bagno": "B-2", "cliente": "3004", "articolo": "C010001S",
                "consegna": "2026-10-18", "delivery_date": "2026-10-12",
            },
        ])
        copertura = pd.DataFrame([
            {"bagno": "B-1", "machine": "3309"},
            {"bagno": "B-2", "machine": "3309"},
        ])

        schedule = build_machine_schedule(
            situation, copertura, today=date(2026, 10, 5)
        )

        elvy = schedule.loc[schedule["cliente"] == "3009"].iloc[0]
        other = schedule.loc[schedule["cliente"] == "3004"].iloc[0]
        self.assertEqual(elvy["delivery_target"], "2026-10-15")
        self.assertEqual(other["delivery_target"], "2026-10-18")
        self.assertEqual(elvy["dye_date"], "2026-10-05")
        self.assertEqual(elvy["delivery_difference"], 7)
        self.assertEqual(other["delivery_difference"], 10)

    def test_situazione_densita_uses_raw_batch_from_pg_comment(self):
        from gui.tabs.situazione_tab import SituazioneTab

        tab = object.__new__(SituazioneTab)
        tab._on_notification = None
        frame = pd.DataFrame([{
            "partita": "COLORED-BATCH",
            "comment": "PG-158694-PM-X",
            "articolo": "",
            "codice": "",
            "prezzo": "",
            "mc": "",
        }])

        with tempfile.TemporaryDirectory() as temp_dir:
            source = Path(temp_dir) / "densita.xlsx"
            source.touch()
            with patch(
                "gui.tabs.situazione_refresh.load_densita_cache",
                return_value={"source_path": str(source)},
            ), patch(
                "exporters.biglietti_exporter.load_prezzo_lookup",
                return_value=({}, ""),
            ), patch(
                "exporters.biglietti_exporter.load_densita_query",
                return_value=({158694: {"densita": 378}}, []),
            ):
                result, _pending = tab._recompute_prezzo_densita_for_frame(frame)

        self.assertEqual(result.loc[0, "densita"], 378)

    def test_situazione_price_uses_category_for_new_article_and_zero_padded_color(self):
        from calculate.prezzi import build_price_lookup
        from gui.tabs.situazione_tab import SituazioneTab

        tab = object.__new__(SituazioneTab)
        tab._on_notification = None
        frame = pd.DataFrame([{
            "articolo": "C010006S",
            "codice": "141",
            "colore": "Cielo",
            "partita": "158877",
            "prezzo": "",
            "mc": 672,
            "comment": "",
        }])
        price_lookup = build_price_lookup(pd.DataFrame([
            {"CLARTICOLO": "C010003S", "CLCOLORE": "000141", "LIVELLOLPZ": 66,
             "PREZZOLPZ": 5.39, "CATEGORY": "MED-Cottone"},
            {"CLARTICOLO": "C010005S", "CLCOLORE": "000141", "LIVELLOLPZ": 66,
             "PREZZOLPZ": 5.39, "CATEGORY": "MED-Cottone"},
        ]))

        with patch(
            "exporters.biglietti_exporter.load_prezzo_lookup",
            return_value=(price_lookup, "LISTINI.xlsx"),
        ):
            result, _pending = tab._recompute_prezzo_densita_for_frame(frame)

        self.assertEqual(result.loc[0, "prezzo_lisini"], 5.39)

    def test_machine_lookup_rejects_empty_counts(self):
        self.assertEqual(_machine_for_count(None), "")
        self.assertEqual(_machine_for_count(0), "")
        self.assertEqual(_machine_for_count(-2), "")

    def test_special_titles_are_case_and_space_insensitive(self):
        self.assertTrue(titles_compatible(" 30/1 ", "30/1"))
        self.assertFalse(titles_compatible("30/1", "31/1"))

    def test_elvy_reactive_client_colour_keeps_g_marker(self):
        from parsers.dfm_lookup import _extract_colour_code

        self.assertEqual(_extract_colour_code("R.G.4257"), ("4257", "", "G"))

    def test_elvy_reactive_client_colour_matches_dfm(self):
        from parsers.dfm_lookup import lookup_dfm_color

        entries = [{
            "articolo": "C130026S",
            "coloredfm": "364257",
            "cldescr": "EL-G-425711-DOUBLE REATTIVO",
            "twist": "2",
            "titolo": "80/2",
            "date": "2026-09-09",
        }]
        self.assertEqual(
            lookup_dfm_color(
                "G130026S", "R.G.4257", "80/2", "Reactive", "100% Cotton", entries
            ),
            ("364257", "EL-G-425711-DOUBLE REATTIVO"),
        )

    def test_build_dfm_lookup_tolerates_header_case_and_whitespace_drift(self):
        # An ERP export changing "ARTICOLODFM" to " Articolodfm" (case or
        # stray whitespace) between versions must not break the lookup --
        # only a genuinely missing/renamed column should raise an error.
        from parsers.dfm_lookup import build_dfm_lookup
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "DFM.xlsx"
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.append([" Articolodfm", "coloredfm", "CLDESCR ", "descrizarticololi", "DataIns"])
            ws.append(["C130027S", "364257", "EL-44011-DOUBLEYARN", "0070  100.00 2", "01/01/2026"])
            wb.save(path)

            entries = build_dfm_lookup(path, prefix="C130")
            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0]["articolo"], "C130027S")
            self.assertEqual(entries[0]["coloredfm"], "364257")

    def test_build_dfm_lookup_still_errors_on_genuinely_missing_column(self):
        from parsers.dfm_lookup import build_dfm_lookup
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "DFM.xlsx"
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.append(["ARTICOLODFM", "COLOREDFM", "CLDESCR", "DESCRIZARTICOLOLI"])  # DATAINS missing
            ws.append(["C130027S", "364257", "EL-44011-DOUBLEYARN", "0070  100.00 2"])
            wb.save(path)

            with self.assertRaises(ValueError):
                build_dfm_lookup(path, prefix="C130")

    def test_pdf_parser_keeps_multiline_article_description_fields(self):
        from parsers.pdf_parser import PDFParser, ColumnSlot, _group_into_lines

        def word(text, x0, top, width=12):
            return {"text": text, "x0": x0, "x1": x0 + width, "top": top, "bottom": top + 8}

        lines = _group_into_lines([
            word("10", 10, 100),
            word("800", 70, 100),
            word("R.G.4257", 360, 100, 50),
            word("100%", 70, 120, 28),
            word("Cotton", 105, 120, 38),
            word("Pima", 148, 120, 25),
            word("Blend", 178, 120, 30),
            word("Nm", 214, 120, 16),
            word("135/2", 235, 120, 34),
            word("Ne", 275, 120, 14),
            word("80/2", 294, 120, 28),
            word("Reactive", 328, 120, 45),
            word("Griege", 70, 140, 38),
            word("Lot", 114, 140, 18),
            word(":", 136, 140, 5),
            word("99_LOT", 146, 140, 42),
            word("El.09092026", 192, 140, 60),
        ], 4)
        slots = {
            "pos": ColumnSlot("pos", 0, 35),
            "article_area": ColumnSlot("article_area", 35, 350),
            "colour": ColumnSlot("colour", 350, 410),
        }
        rows, _, _ = PDFParser._lines_to_rows(
            PDFParser.__new__(PDFParser), lines, slots, "1479", "9/9/2026", ""
        )

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].article_no, "800")
        self.assertEqual(rows[0].yarn, "100% Cotton Pima Blend")
        self.assertEqual(rows[0].nm, "135/2")
        self.assertEqual(rows[0].ne, "80/2")
        self.assertEqual(rows[0].dye_type, "Reactive")
        self.assertEqual(rows[0].lot, "99_LOT El.09092026")
        self.assertEqual(rows[0].colour, "R.G.4257")

    def test_pdf_parser_recovers_fields_on_first_row_continuation(self):
        from parsers.pdf_parser import PDFParser, ColumnSlot, _group_into_lines

        def word(text, x0, top, width=12):
            return {"text": text, "x0": x0, "x1": x0 + width, "top": top, "bottom": top + 8}

        lines = _group_into_lines([
            word("10", 10, 100),
            word("672.00", 490, 100, 35),
            word("618.24", 610, 100, 35),
            word("800", 70, 108),
            word("R.G.4257", 360, 108, 50),
            word("100%", 70, 120, 28),
            word("Cotton", 105, 120, 38),
            word("Pima", 148, 120, 25),
            word("Blend", 178, 120, 30),
            word("Nm", 214, 120, 16),
            word("135/2", 235, 120, 34),
            word("Ne", 275, 120, 14),
            word("80/2", 294, 120, 28),
            word("Reactive", 328, 120, 45),
            word("Griege", 70, 140, 38),
            word("Lot", 114, 140, 18),
            word(":", 136, 140, 5),
            word("99_LOT", 146, 140, 42),
            word("El.09092026", 192, 140, 60),
        ], 4)
        slots = {
            "pos": ColumnSlot("pos", 0, 35),
            "article_area": ColumnSlot("article_area", 35, 350),
            "colour": ColumnSlot("colour", 350, 410),
            "qty_cones": ColumnSlot("qty_cones", 480, 550),
            "qty_kg": ColumnSlot("qty_kg", 590, 660),
        }
        rows, _, _ = PDFParser._lines_to_rows(
            PDFParser.__new__(PDFParser), lines, slots, "1479", "9/9/2026", ""
        )

        self.assertEqual(rows[0].article_no, "800")
        self.assertEqual(rows[0].colour, "R.G.4257")
        self.assertEqual(rows[0].quantity_cones, 672.0)
        self.assertEqual(rows[0].quantity_kg, 618.24)

    def test_data_start_includes_words_within_first_row_y_tolerance(self):
        from parsers.pdf_parser import PDFParser

        words = [
            {"text": "Pos.", "x0": 10, "x1": 20, "top": 100, "bottom": 106},
            {"text": "10", "x0": 10, "x1": 18, "top": 120.7, "bottom": 127},
            {"text": "800", "x0": 40, "x1": 52, "top": 120.4, "bottom": 127},
        ]
        start = PDFParser._find_data_start(words, words[0])

        self.assertEqual(start, 120.4)

    def test_shared_path_round_trip(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "Produzione.xlsx"
            path.write_bytes(b"placeholder")
            path_manager.save_source("data_prod", path)
            self.assertEqual(
                path_manager.load_source("produzione")["source_path"], str(path)
            )

    def test_elvy_delivery_rules_skip_friday(self):
        row = {"cliente": "3009", "data": "2026-09-11", "mc": 192, "comment": ""}
        self.assertEqual(compute_delivery_date(row), "2026-09-19")
        row["mc"] = 24
        self.assertEqual(compute_delivery_date(row), "2026-09-26")

    def test_elvy_lab_adds_one_week_and_pgx_waits_for_yarn(self):
        row = {"cliente": "ELVY", "data": "2026-09-07", "mc": 192, "new_comment": "Lab"}
        self.assertEqual(compute_delivery_date(row), "2026-09-21")
        row.update({"comment": "PG-X-123", "new_comment": "Filato"})
        self.assertEqual(compute_delivery_date(row), "Pending for yarn")
        row["raw_yarn_match"] = "G130 / 44"
        row["yarn_arrival_date"] = "2026-09-08"
        self.assertEqual(compute_delivery_date(row), "2026-09-15")

    def test_raw_yarn_split_match_requires_partitas_from_same_lotto(self):
        from calculate.situazione import compute_raw_yarn_matches

        shortage = pd.DataFrame([{
            "articolo": "C010032S", "comment": "PG-X", "rocche": 10,
        }])
        stock = pd.DataFrame([
            {"articolo": "G010032S", "partita": "P1", "mag_rocche": 6},
            {"articolo": "G010032S", "partita": "P2", "mag_rocche": 6},
        ])

        different_lotti = pd.DataFrame([
            {"partita": "P1", "lotto": "L1"},
            {"partita": "P2", "lotto": "L2"},
        ])
        self.assertEqual(
            compute_raw_yarn_matches(shortage, stock, different_lotti).loc[0], ""
        )

        same_lotto = different_lotti.assign(lotto="L1")
        self.assertEqual(
            compute_raw_yarn_matches(shortage, stock, same_lotto).loc[0],
            "G010032S / P1 + P2",
        )

    def test_delivery_dates_leave_non_elvy_blank(self):
        frame = pd.DataFrame([{"cliente": "3004", "data": "2026-09-07", "mc": 24}])
        result = compute_delivery_dates(frame)
        self.assertEqual(result.loc[0, "delivery_date"], "")

    def test_elvy_within_three_days_ticket_excludes_past_and_later_dates(self):
        from gui.tabs.overview_tab import _delivery_due_within_days

        dates = pd.Series([
            "2026-10-02", "2026-10-03", "2026-10-04", "2026-10-06",
            "2026-10-07", "",
        ])

        mask = _delivery_due_within_days(dates, 3, today=date(2026, 10, 3))

        self.assertEqual(mask.tolist(), [False, True, True, True, False, False])

    def test_master_import_recognizes_lotto_serial_filename(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "ARKMAG-CON-LOTTO_20260829.xlsx"
            path.write_bytes(b"placeholder")
            self.assertEqual(find_files_in_directory(temp_dir)["lotti"], path)

    def test_master_file_finds_data_ordine_sheet_by_content(self):
        # Data Ordine / Dispo Bagno sheets inside a single bundled master
        # workbook have order-specific names (e.g. "MED-D-505449-2026"),
        # never a matchable candidate like "copertura" -- they must be
        # found by sniffing header content instead, the same way loose
        # files in a folder already are.
        with tempfile.TemporaryDirectory() as temp_dir:
            master_path = Path(temp_dir) / "Master.xlsx"
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Copertura"
            ws.append(["N. Bagno", "Machine", "Batch Start"])
            order_ws = wb.create_sheet("MED-D-505449-2026")
            order_ws.append(["Cliente", "DescrizioneAggiuntivaOrdine", "Altro"])
            order_ws.append(["ACME", "Some note", "x"])
            wb.save(master_path)

            matches = master_import._match_sheets(["Copertura", "MED-D-505449-2026"])
            self.assertNotIn("data_ordine", matches)  # not findable by name

            wb2 = openpyxl.load_workbook(master_path, read_only=True)
            try:
                sniffed = master_import._content_match_ordine_sheets(
                    wb2, wb2.sheetnames, set(matches.values())
                )
            finally:
                wb2.close()
            self.assertEqual(sniffed.get("data_ordine"), "MED-D-505449-2026")

    def test_lotti_loader_reads_all_workbook_sheets(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "LOTTI.xlsx"
            workbook = openpyxl.Workbook()
            worksheet = workbook.active
            worksheet.append(["MAGAZZINO", "ARTICOLO", "PARTITA", "ORDINE", "QESI", "LOTTO"])
            worksheet.append([900910, "G130-1", "P-1", 0, 10, "L-1"])
            workbook.create_sheet("Seconda")
            workbook.save(path)

            frame, errors = load_lotti(path)

            self.assertEqual(errors, [])
            self.assertEqual(frame.loc[0, "lotto"], "L-1")

    def test_overview_import_skips_order_only_sources(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            folder = Path(temp_dir)
            (folder / "Data Ordine.xlsx").write_bytes(b"placeholder")
            (folder / "Dispo Bagno.xlsx").write_bytes(b"placeholder")

            with patch.object(master_import, "_route") as route:
                loaded, skipped = master_import.import_master_directory(
                    folder,
                    situazione_tab=None,
                    magazino_tab=None,
                    skip_keys={"data_ordine", "dispo_bagno"},
                )

            route.assert_not_called()
            self.assertNotIn("Data Ordine", loaded + skipped)
            self.assertNotIn("Dispo Bagno", loaded + skipped)

    def test_master_directory_routes_biglietti_template(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            template = Path(temp_dir) / "Biglietti.docx"
            template.write_bytes(b"template")

            class Biglietti:
                def __init__(self):
                    self.path = None

                def set_template_path(self, path):
                    self.path = path

            target = Biglietti()
            master_import.import_master_directory(
                temp_dir, situazione_tab=None, magazino_tab=None,
                biglietti_tab=target,
            )

            self.assertEqual(target.path, str(template))

    def test_master_file_reports_unfound_sources_as_skipped(self):
        # Regression guard for the previous silent-drop bug: import_master_file
        # used to build its skipped-list from SHEET_CANDIDATES only, so a
        # source with no sheet-name candidate at all (Data Ordine, Dispo
        # Bagno) simply vanished from both loaded and skipped instead of
        # being reported as missing.
        with tempfile.TemporaryDirectory() as temp_dir:
            master_path = Path(temp_dir) / "Master.xlsx"
            wb = openpyxl.Workbook()
            wb.active.title = "Sheet1"
            wb.save(master_path)
            loaded, skipped = master_import.import_master_file(
                str(master_path), situazione_tab=None, magazino_tab=None
            )
            self.assertIn("Data Ordine", skipped)
            self.assertIn("Dispo Bagno", skipped)

    def test_master_file_keeps_shared_magazino_and_lotti_extracts(self):
        class SharedTab:
            def __init__(self):
                self.magazino_paths = []
                self.lotti_paths = []

            def _on_upload_magazino(self, path, cache_path=None):
                self.magazino_paths.append((path, cache_path))

            def _on_upload_lotti(self, path, cache_path=None):
                self.lotti_paths.append((path, cache_path))

        with tempfile.TemporaryDirectory() as temp_dir:
            master_path = Path(temp_dir) / "Master.xlsx"
            workbook = openpyxl.Workbook()
            workbook.active.title = "Magazino"
            workbook["Magazino"].append(["Articolo", "Partita", "Peso"])
            workbook.create_sheet("LOTTI").append(["Partita", "Lotto"])
            workbook.save(master_path)

            shared_tab = SharedTab()
            master_import.import_master_file(
                str(master_path), situazione_tab=None, magazino_tab=shared_tab
            )

            self.assertTrue(shared_tab.magazino_paths)
            self.assertTrue(shared_tab.lotti_paths)
            for path, cache_path in shared_tab.magazino_paths + shared_tab.lotti_paths:
                self.assertEqual(path, cache_path)
                self.assertTrue(Path(path).is_file())

    def test_order_headers_can_start_later_and_use_aliases(self):
        class Sheet:
            def iter_rows(self, values_only=True):
                return iter([
                    ["Export generated", None, None],
                    ["ARTICOLO", "Q.TA", "DATA CONSEGNA"],
                    ["C130", 4, "2026-09-06"],
                ])

        rows = _read_sheet_rows(Sheet())
        self.assertEqual(_get(rows[0], "Articolo"), "C130")
        self.assertEqual(_get(rows[0], "Ordinata"), 4)
        self.assertEqual(_get(rows[0], "Consegna"), "2026-09-06")

    def test_report_dates_display_day_first(self):
        frame = pd.DataFrame([{"delivery_date": "2026-09-06", "data": "2026-12-31"}, {"delivery_date": "Pending for yarn", "data": ""}])
        result = _format_display_dates(frame, ["data", "delivery_date"])
        self.assertEqual(result.loc[0, "delivery_date"], "06/09/2026")
        self.assertEqual(result.loc[0, "data"], "31/12/2026")
        self.assertEqual(result.loc[1, "delivery_date"], "Pending for yarn")

    def test_overview_shared_refresh_helper_is_available(self):
        from gui.tabs.overview_tab import OverviewTab
        self.assertTrue(hasattr(OverviewTab, "_refresh_shared_tabs"))

    def test_overview_price_color_ticket_uses_situazione_anomalies(self):
        from gui.tabs.overview_tab import _price_color_anomalies

        situazione = pd.DataFrame([{
            "articolo": "A1",
            "colore": "Blu",
            "codice": "001",
            "partita": "P-100",
            "prezzo": 12.0,
            "prezzo_lisini": 10.0,
            "ordine": "O-20",
            "riga": 3,
        }])

        color_errors = _price_color_anomalies(situazione)

        self.assertEqual(len(color_errors), 1)
        self.assertEqual(color_errors.loc[0, "articolo"], "A1")
        self.assertEqual(color_errors.loc[0, "partita_colore"], "P-100")
        self.assertEqual(color_errors.loc[0, "ordine"], "O-20")
        self.assertEqual(color_errors.loc[0, "riga"], 3)
        self.assertNotIn("key", color_errors.columns)

    def test_situazione_raw_yarn_notifications_resolve_when_match_disappears(self):
        from gui.tabs.situazione_refresh import SituationRefreshMixin
        from utility import notifications

        key_prefix = "situazione-raw-yarn-available:"
        with tempfile.TemporaryDirectory() as temp_dir:
            with patch.object(notifications, "_PATH", Path(temp_dir) / "notifications.json"):
                notifications.add(f"{key_prefix}P1", "Available", "match", "Situazione Generale")
                notifications.add(f"{key_prefix}P2", "Available", "match", "Situazione Generale")

                tab = object.__new__(SituationRefreshMixin)
                tab.current_df = pd.DataFrame([{
                    "partita": "P1", "raw_yarn_match": "G010032S / R1",
                }])
                tab._on_notification = lambda *args: None

                tab._notify_raw_yarn_available()

                self.assertEqual(
                    {item["key"] for item in notifications.list_open()},
                    {f"{key_prefix}P1"},
                )

    def test_canonical_ui_tab_imports(self):
        from gui.tabs.biglietti_tab import BigliettiTab
        from gui.tabs.kamal_tab import KamalTab
        from gui.tabs.magazino_filato_tab import MagazinoFilatoTab
        from gui.tabs.situazione_settimana_tab import SettimanaTab
        from gui.tabs.situazione_tab import SituazioneTab

        self.assertTrue(all((BigliettiTab, KamalTab, MagazinoFilatoTab, SettimanaTab, SituazioneTab)))

    def test_canonical_logic_imports(self):
        # The old root-level *_logic.py compatibility shims (prezzi_logic,
        # lotti_logic, situazione_settimana_logic, magazino_logic) were
        # removed once every caller was migrated to import from calculate.*
        # directly (see ARCHITECTURE.md). This just confirms the canonical
        # modules still expose the expected callables.
        from calculate.lotti import summarize_by_partita
        from calculate.prezzi import build_price_lookup, load_prezzi
        from calculate.magazino import summarize_by_partita as magazino_summary
        from calculate.situazione_settimana import summarize as weekly_summary

        self.assertTrue(callable(build_price_lookup))
        self.assertTrue(callable(summarize_by_partita))
        self.assertTrue(callable(magazino_summary))
        self.assertTrue(callable(weekly_summary))
        self.assertTrue(callable(load_prezzi))

    def test_price_lookup_cache_reuses_same_source(self):
        import exporters.biglietti_exporter as biglietti_exporter
        self.assertTrue(hasattr(biglietti_exporter, "_PREZZO_LOOKUP_CACHE"))

    def test_articoli_marca_map_is_disk_cached(self):
        # load_articoli_marca_map used to have its own bespoke in-memory-
        # only cache (_ARTICOLI_MARCA_CACHE); it's now on the same shared,
        # persistent (survives an app restart) disk_cache every other
        # heavy Excel loader uses -- verify a second call for the exact
        # same file returns the identical dict object (the in-memory hit
        # path), not just an equal one, and that a real cache file lands
        # on disk for it (the persistence half of the same guarantee).
        from exporters.biglietti_exporter import load_articoli_marca_map
        from utility import disk_cache
        import openpyxl

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "Articoli.xlsx"
            wb = openpyxl.Workbook()
            ws1 = wb.active
            ws1.title = "Sheet1"
            ws2 = wb.create_sheet("Sheet2")
            ws2.append(["Articolo Filato", "Marca"])
            ws2.append(["G010032S", "100/2 - COTTON 100%"])
            wb.save(path)

            disk_cache.invalidate("articoli_marca")
            first, errors = load_articoli_marca_map(path)
            self.assertEqual(errors, [])
            self.assertEqual(first["G010032S"], "100/2 - COTTON 100%")

            second, _errors = load_articoli_marca_map(path)
            # In-memory cache hit: equal content, but a PRIVATE copy -- a caller
            # that edits what it got back must not edit the cache for everybody.
            self.assertEqual(first, second)
            self.assertIsNot(first, second)
            first["EDITED"] = "x"
            third, _errors = load_articoli_marca_map(path)
            self.assertNotIn("EDITED", third)

            key = disk_cache.file_cache_key(path)
            self.assertTrue(disk_cache._cache_path("articoli_marca", key).is_file())

    def test_disk_cache_directory_failure_falls_back_to_loader(self):
        from utility import disk_cache

        with tempfile.TemporaryDirectory() as temp_dir:
            source = Path(temp_dir) / "source.xlsx"
            source.touch()
            with patch(
                "utility.disk_cache._cache_path",
                side_effect=PermissionError("cache directory is read-only"),
            ):
                result = disk_cache.cached_load("unwritable-test", source, lambda: "loaded")

        self.assertEqual(result, "loaded")

    def test_filato_rows_uses_order_total_rocche_and_scaled_magazino_peso(self):
        # Rocche always comes from the order itself now -- stock was
        # already verified earlier, on the Ordine page, before the order
        # went into the system. Peso is the warehouse's per-cone weight
        # rate scaled to how many cones THIS order needs (4), not the
        # warehouse's own stock quantity (12).
        from types import SimpleNamespace
        record = SimpleNamespace(raw_batch="158694", article="C1300275", title="100/2", quantity_cones=4)
        raw_rows = [{"articolo": "G1300275", "peso": 245.32, "تحضير خام": "تحضير خام"}]
        magazino = pd.DataFrame([{
            "articolo": "G130027S", "partita": "158694.0", "mag_rocche": 12,
            "mag_peso": 240.0,
        }])
        result = _filato_rows([record], raw_rows, magazino)
        self.assertEqual(result[0]["Rocche"], 4)
        self.assertEqual(result[0]["Peso"], 80.0)  # (240.0 / 12) * 4

    def test_filato_rows_falls_back_to_raw_sheet_peso_without_magazino(self):
        from types import SimpleNamespace
        record = SimpleNamespace(raw_batch="158694", article="C1300275", title="100/2", quantity_cones=4)
        raw_rows = [{"articolo": "G1300275", "peso": 245.32, "تحضير خام": "تحضير خام"}]
        result = _filato_rows([record], raw_rows, magazino_summary=None)
        self.assertEqual(result[0]["Rocche"], 4)
        self.assertEqual(result[0]["Peso"], 245.32)

    def test_biglietti_filato_uses_fixed_filename_and_shared_writer(self):
        # Create (EXCEL+Biglietti)'s Filato output must follow the same
        # convention as Ordine Kamal/Ordine ELVY: a fixed "Filato x
        # Tinturia.xlsx" name, written via export_filato_full (clear +
        # rewrite each run), not a per-order-named snapshot file.
        from types import SimpleNamespace
        from pipelines.ordini_elvy import RawYarnMatch, export_filato_full, read_filato_tinturia_sheet

        record = SimpleNamespace(raw_batch="158694", article="C1300275", title="100/2", quantity_cones=4)
        raw_rows = [{"articolo": "G1300275", "peso": 245.32, "تحضير خام": "تحضير خام"}]
        magazino = pd.DataFrame([{
            "articolo": "G130027S", "partita": "158694.0", "mag_rocche": 12, "mag_peso": 245.32,
        }])
        filato_rows = _filato_rows([record], raw_rows, magazino)
        matches = [
            RawYarnMatch(
                articolo=r["Articolo"], titolo=r["Titolo"], partita=r["Partita"],
                rocce=r["Rocche"], peso=r["Peso"], label=r["تحضير خام"],
            )
            for r in filato_rows
        ]
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir) / "Filato x Tinturia.xlsx"
            n = export_filato_full(target, matches)
            self.assertEqual(n, 1)
            self.assertTrue(target.is_file())
            rows = read_filato_tinturia_sheet(target)
            self.assertEqual(rows[0].rocce, 4)  # order total, not Magazino's stock count (12)

    def test_elvy_and_el_kamal_workbooks_embed_filato_sheet_like_med(self):
        # Every client's own extract-excel gets a "Filato x Tinturia" tab,
        # not just MED's -- regression guard for the ELVY/EL KAMAL asymmetry
        # where include_filato was left False while MED already had it True.
        from exporters.biglietti_exporter import OrderRecord, export_workbook

        record = OrderRecord(
            customer_code="3009", customer_name="ELVY WEAVING", article="C130027S",
            description="", additional_raw="", color_code="5305", color_name="EL-281311",
            order_no="7777", order_row="1", colored_batch="322813", raw_batch="158694",
            quantity_cones=32, raw_weight=30, dispo="D-00505450-001", bagno="S940",
            title="100/2",
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            for customer in ("ELVY", "EL_KAMAL"):
                path = Path(temp_dir) / f"{customer}.xlsx"
                export_workbook(path, [record], [], include_filato=True, customer=customer)
                wb = openpyxl.load_workbook(path)
                try:
                    self.assertIn("Filato x Tinturia", wb.sheetnames, customer)
                finally:
                    wb.close()

    def test_filato_extract_replaces_previous_order_content(self):
        # A shared "Filato x Tinturia.xlsx" (e.g. Ordine Kamal and Ordine
        # ELVY both pointed at the same folder) must only ever reflect the
        # MOST RECENT extraction -- an older order's raw yarn shouldn't
        # linger next to a newer order's, since it may already be pulled
        # and irrelevant.
        from pipelines.ordini_elvy import export_filato_full, read_filato_tinturia_sheet, RawYarnMatch
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir) / "filato.xlsx"
            older_order = [RawYarnMatch(articolo="G130027S", titolo="100/2", partita="158694", rocce=10, peso=100.0)]
            export_filato_full(target, older_order)

            newer_order = [RawYarnMatch(articolo="G999999S", titolo="60/1", partita="222111", rocce=5, peso=50.0)]
            export_filato_full(target, newer_order)

            rows = read_filato_tinturia_sheet(target)
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0].partita, "222111")  # only the newer order's row remains

    def test_update_pg_x_row_edits_fields_without_moving_it(self):
        from exporters.biglietti_exporter import OrderRecord, append_create_excel, update_pg_x_row, load_create_excel_records
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "shared.xlsx"
            record = OrderRecord(
                customer_code="3009", customer_name="ELVY", article="C130027S", description="", additional_raw="",
                color_code="5305", color_name="EL-281311", order_no="7777", order_row="1",
                colored_batch="157890", raw_batch="PG-X", quantity_cones=32, raw_weight=30,
                dispo="D-00505450-001", bagno="S940",
            )
            append_create_excel(path, [record], "ELVY")

            updated = update_pg_x_row(path, "157890", {"Bagno": "S999", "Rocche": 40, "M/C": "5"})
            self.assertEqual(updated, 1)

            pg_x_rows = load_create_excel_records(path, sheet_name="PG-X")
            orders_rows = load_create_excel_records(path, sheet_name="Orders")
            self.assertEqual(len(pg_x_rows), 1)  # still in PG-X -- Partita GG was never filled in
            self.assertEqual(len(orders_rows), 0)
            self.assertEqual(pg_x_rows[0].bagno, "S999")
            self.assertEqual(pg_x_rows[0].quantity_cones, 40)

    def test_uploading_pgx_batch_assigns_only_selected_row_without_moving_to_orders(self):
        from exporters.biglietti_exporter import (
            OrderRecord, append_create_excel, load_create_excel_records,
            move_pg_x_to_orders,
            pg_x_batch_stock_status, save_pg_x_partita,
        )

        def record(partita_col):
            return OrderRecord(
                customer_code="3009", customer_name="ELVY", article="C130027S",
                description="", additional_raw="", color_code="5305",
                color_name="EL-281311", order_no="7777", order_row="1",
                colored_batch=partita_col, raw_batch="PG-X", quantity_cones=32,
                raw_weight=30, dispo="D-00505450-001", bagno="S940",
            )

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "shared.xlsx"
            append_create_excel(path, [record("157890"), record("157891")], "ELVY")
            available_stock = pd.DataFrame([
                {"articolo": "G130027S", "partita": "158694", "mag_rocche": 32},
            ])
            self.assertEqual(
                pg_x_batch_stock_status(["C130027S"], "158694", available_stock),
                "available",
            )

            result = save_pg_x_partita(
                path, "157890", "158694", magazino_summary=available_stock,
                move_to_orders=False,
            )
            self.assertEqual(result["updated"], 1)
            self.assertEqual(
                load_create_excel_records(path, sheet_name="Orders"),
                [],
            )
            remaining_pgx = load_create_excel_records(path, sheet_name="PG-X")
            self.assertEqual([row.colored_batch for row in remaining_pgx], ["157890", "157891"])
            self.assertEqual(remaining_pgx[0].raw_batch, "158694")

            self.assertEqual(move_pg_x_to_orders(path, "157890"), 1)
            self.assertEqual(
                [row.colored_batch for row in load_create_excel_records(path, sheet_name="Orders")],
                ["157890"],
            )
            self.assertEqual(
                [row.colored_batch for row in load_create_excel_records(path, sheet_name="PG-X")],
                ["157891"],
            )

            missing_stock = pd.DataFrame(columns=["articolo", "partita", "mag_rocche"])
            self.assertEqual(
                pg_x_batch_stock_status(["C130027S"], "999999", missing_stock),
                "missing",
            )
            with self.assertRaisesRegex(ValueError, "does not belong to article"):
                save_pg_x_partita(
                    path, "157891", "999999", magazino_summary=missing_stock,
                )
            save_pg_x_partita(
                path, "157891", "999999", magazino_summary=missing_stock,
                allow_missing_magazino_batch=True,
                move_to_orders=False,
            )
            self.assertEqual(
                [row.raw_batch for row in load_create_excel_records(path, sheet_name="PG-X")],
                ["999999"],
            )

    def test_upload_stock_warning_cannot_override_a_different_raw_article(self):
        from exporters.biglietti_exporter import (
            OrderRecord, append_create_excel, pg_x_batch_stock_status,
            save_pg_x_partita,
        )

        record = OrderRecord(
            customer_code="3009", customer_name="ELVY", article="C130027S",
            description="", additional_raw="", color_code="5305",
            color_name="EL-281311", order_no="7777", order_row="1",
            colored_batch="157890", raw_batch="PG-X", quantity_cones=32,
            raw_weight=30, dispo="D-00505450-001", bagno="S940",
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "shared.xlsx"
            append_create_excel(path, [record], "ELVY")
            wrong_article_stock = pd.DataFrame([
                {"articolo": "G999999S", "partita": "158694", "mag_rocche": 32},
            ])
            self.assertEqual(
                pg_x_batch_stock_status(["C130027S"], "158694", wrong_article_stock),
                "mismatch",
            )
            with self.assertRaisesRegex(ValueError, "does not belong to article"):
                save_pg_x_partita(
                    path, "157890", "158694",
                    magazino_summary=wrong_article_stock,
                    allow_missing_magazino_batch=True,
                )

    def test_pgx_upload_removes_only_successful_rows_from_source_file(self):
        from exporters.biglietti_exporter import remove_uploaded_pgx_rows

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "raw-batches.xlsx"
            workbook = openpyxl.Workbook()
            worksheet = workbook.active
            worksheet.append(["Partita Col", "Partita GG"])
            worksheet.append(["157890", "158694"])
            worksheet.append(["157891", "wrong article"])
            worksheet.append(["157892", "not in magazino"])
            workbook.save(path)
            workbook.close()

            self.assertEqual(remove_uploaded_pgx_rows(path, [2, 4]), 2)

            workbook = openpyxl.load_workbook(path, data_only=True)
            try:
                self.assertEqual(
                    list(workbook.active.values),
                    [
                        ("Partita Col", "Partita GG"),
                        ("157891", "wrong article"),
                    ],
                )
            finally:
                workbook.close()

    def test_show_orders_deduplicates_partita_col_across_orders_and_pg_x(self):
        from exporters.biglietti_exporter import CREATE_EXCEL_HEADERS, deduplicate_create_excel

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "shared.xlsx"
            wb = openpyxl.Workbook()
            orders = wb.active
            orders.title = "Orders"
            orders.append(CREATE_EXCEL_HEADERS)
            orders.append(["", "ELVY", "", "", "", "", "", "", "", "", "", 157890, "", "", "", 158694])
            orders.append(["", "ELVY", "", "", "", "", "", "", "", "", "", "157890.0", "", "", "", 158694])
            pg_x = wb.create_sheet("PG-X")
            pg_x.append(CREATE_EXCEL_HEADERS)
            pg_x.append(["", "ELVY", "", "", "", "", "", "", "", "", "", 157890, "", "", "", ""])
            pg_x.append(["", "ELVY", "", "", "", "", "", "", "", "", "", 157891, "", "", "", ""])
            pg_x.append(["", "ELVY", "", "", "", "", "", "", "", "", "", 157891, "", "", "", ""])
            wb.save(path)
            wb.close()

            self.assertEqual(deduplicate_create_excel(path), 3)

            wb = openpyxl.load_workbook(path, data_only=True)
            self.assertEqual(wb["Orders"].max_row - 1, 1)
            self.assertEqual(wb["PG-X"].max_row - 1, 1)
            self.assertEqual(wb["Orders"].cell(2, 12).value, 157890)
            self.assertEqual(wb["PG-X"].cell(2, 12).value, 157891)
            wb.close()

    def test_append_create_excel_cleans_existing_duplicates_and_skips_existing_partita_col(self):
        from exporters.biglietti_exporter import (
            CREATE_EXCEL_HEADERS, OrderRecord, append_create_excel,
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "shared.xlsx"
            wb = openpyxl.Workbook()
            orders = wb.active
            orders.title = "Orders"
            orders.append(CREATE_EXCEL_HEADERS)
            orders.append(["", "ELVY", "", "", "", "", "", "", "", "", "", 157890, "", "", "", 158694])
            orders.append(["", "ELVY", "", "", "", "", "", "", "", "", "", "157890.0", "", "", "", 158694])
            pg_x = wb.create_sheet("PG-X")
            pg_x.append(CREATE_EXCEL_HEADERS)
            pg_x.append(["", "ELVY", "", "", "", "", "", "", "", "", "", 157891, "", "", "", ""])
            wb.save(path)
            wb.close()

            duplicate = OrderRecord(
                customer_code="3009", customer_name="ELVY", article="C130027S", description="", additional_raw="",
                color_code="5305", color_name="EL-281311", order_no="7777", order_row="1",
                colored_batch="157891", raw_batch="PG-X", quantity_cones=32, raw_weight=30,
                dispo="D-00505450-001", bagno="S940",
            )
            result = append_create_excel(path, [duplicate], "ELVY")

            self.assertEqual(result["added"], 0)
            self.assertEqual(result["skipped"], 1)
            wb = openpyxl.load_workbook(path, data_only=True)
            self.assertEqual(wb["Orders"].max_row - 1, 1)
            self.assertEqual(wb["PG-X"].max_row - 1, 1)
            wb.close()

    def test_update_order_row_clearing_partita_gg_moves_row_back_to_pg_x(self):
        from exporters.biglietti_exporter import OrderRecord, append_create_excel, update_order_row, load_create_excel_records
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "shared.xlsx"
            record = OrderRecord(
                customer_code="3009", customer_name="ELVY", article="C130027S", description="", additional_raw="",
                color_code="5305", color_name="EL-281311", order_no="7777", order_row="1",
                colored_batch="157890", raw_batch="158694", quantity_cones=32, raw_weight=30,
                dispo="D-00505450-001", bagno="S940",
            )
            append_create_excel(path, [record], "ELVY")
            self.assertEqual(len(load_create_excel_records(path, sheet_name="Orders")), 1)

            result = update_order_row(path, "157890", {"Partita GG": ""})
            self.assertTrue(result["moved_to_pgx"])
            self.assertEqual(len(load_create_excel_records(path, sheet_name="Orders")), 0)
            self.assertEqual(len(load_create_excel_records(path, sheet_name="PG-X")), 1)

    def test_update_order_row_rejects_articolo_change_that_no_longer_matches_stock(self):
        # Regression guard for "make sure it checks if I change the Articolo
        # on the same page" -- changing Articolo must re-validate against
        # Magazino for the row's existing Partita GG, not just trust it.
        from exporters.biglietti_exporter import OrderRecord, append_create_excel, update_order_row
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "shared.xlsx"
            record = OrderRecord(
                customer_code="3009", customer_name="ELVY", article="C130027S", description="", additional_raw="",
                color_code="5305", color_name="EL-281311", order_no="7777", order_row="1",
                colored_batch="157890", raw_batch="158694", quantity_cones=32, raw_weight=30,
                dispo="D-00505450-001", bagno="S940",
            )
            append_create_excel(path, [record], "ELVY")

            magazino = pd.DataFrame([{"articolo": "G130027S", "partita": "158694", "mag_rocche": 32, "mag_peso": 300.0}])
            with self.assertRaises(ValueError):
                # Change Articolo to something whose raw article (G999999S)
                # was never stocked under Partita 158694.
                update_order_row(path, "157890", {"Articolo": "C999999S"}, magazino_summary=magazino)

            # Allowed explicitly when the user confirms the mismatch.
            result = update_order_row(
                path, "157890", {"Articolo": "C999999S"},
                magazino_summary=magazino, allow_article_mismatch=True,
            )
            self.assertEqual(result["updated"], 1)

    def test_update_order_row_partial_update_does_not_accidentally_clear_partita_gg(self):
        # A caller that only sends {"Articolo": ...} (no "Partita GG" key
        # at all) must not have that read as "Partita GG cleared" -- that
        # would wrongly move an untouched row into PG-X.
        from exporters.biglietti_exporter import OrderRecord, append_create_excel, update_order_row, load_create_excel_records
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "shared.xlsx"
            record = OrderRecord(
                customer_code="3009", customer_name="ELVY", article="C130027S", description="", additional_raw="",
                color_code="5305", color_name="EL-281311", order_no="7777", order_row="1",
                colored_batch="157890", raw_batch="158694", quantity_cones=32, raw_weight=30,
                dispo="D-00505450-001", bagno="S940",
            )
            append_create_excel(path, [record], "ELVY")

            result = update_order_row(path, "157890", {"Bagno": "S999"})
            self.assertFalse(result["moved_to_pgx"])
            self.assertEqual(len(load_create_excel_records(path, sheet_name="Orders")), 1)
            self.assertEqual(len(load_create_excel_records(path, sheet_name="PG-X")), 0)

    def test_ordini_full_replaces_previous_order_content(self):
        from pipelines.ordini_elvy import export_ordini_full, OrdiniElvyRow
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir) / "ordini.xlsx"
            export_ordini_full(target, [OrdiniElvyRow(articolo_delta="C100", coloredfm=5, quantity_cones=10)])
            export_ordini_full(target, [OrdiniElvyRow(articolo_delta="C200", coloredfm=7, quantity_cones=20)])

            wb = openpyxl.load_workbook(target)
            ws = wb["ORDINE VENDITA EGITTO"]
            values = [ws.cell(row=r, column=c).value for r in range(2, ws.max_row + 1) for c in range(1, ws.max_column + 1)]
            wb.close()
            self.assertNotIn("C100", values)  # the older order's row is gone
            self.assertIn("C200", values)

    def test_abbin_zero_normalizes_to_none_and_never_groups(self):
        from pipelines.ordine_med import OrdineMedRow, _normalize_abbin, compute_mc_and_gruppo

        self.assertIsNone(_normalize_abbin(0))
        self.assertIsNone(_normalize_abbin("0"))
        self.assertIsNone(_normalize_abbin(0.0))
        self.assertIsNone(_normalize_abbin(None))
        self.assertIsNone(_normalize_abbin(""))
        self.assertEqual(_normalize_abbin(5), 5)
        self.assertEqual(_normalize_abbin("7"), "7")

        def record(rocc, abbin):
            return OrdineMedRow(
                riga=1, code_org="", titolo="", descr_col="", articolo="C100",
                colore="", rocc=rocc, abbin=_normalize_abbin(abbin), consegna_input="", pt_grg="",
                pt_med="", polmoni="", cliente_note="", nota_grg="", nota_col="",
                kg_note="", fabb="", prezz_note="",
            )

        # Two rows that both had raw ABBIN 0 must NOT be grouped together --
        # each keeps its own Rocche as its M/C, same as a genuinely blank ABBIN.
        zero_a, zero_b = record(10, 0), record(20, 0)
        # Two rows that share a real, non-zero ABBIN must still be grouped
        # and dyed together, combining their Rocche.
        paired_a, paired_b = record(6, 5), record(6, 5)
        compute_mc_and_gruppo([zero_a, zero_b, paired_a, paired_b])

        self.assertEqual(zero_a.mc, 10)
        self.assertEqual(zero_b.mc, 20)
        self.assertEqual(paired_a.mc, 12)
        self.assertEqual(paired_b.mc, 12)

    def test_med_erp_export_replaces_previous_content(self):
        from pipelines.ordine_med import OrdineMedRow, export_erp_order_workbook

        def record(article):
            return OrdineMedRow(
                riga=1, code_org="", titolo="", descr_col="", articolo=article,
                colore="", rocc=1, abbin="", consegna_input="", pt_grg="",
                pt_med="", polmoni="", cliente_note="", nota_grg="", nota_col="",
                kg_note="", fabb="", prezz_note="",
            )

        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir) / "EXCEL PER ORDINE VENDITA EGITTO.xlsx"
            export_erp_order_workbook(target, [record("C100")])
            export_erp_order_workbook(target, [record("C200")])

            wb = openpyxl.load_workbook(target, data_only=True)
            ws = wb["Dati sistema (B-N)"]
            values = [cell.value for row in ws.iter_rows(min_row=2) for cell in row]
            wb.close()
            self.assertNotIn("C100", values)
            self.assertIn("C200", values)

    def test_filato_reader_handles_short_excel_rows(self):
        from pipelines.ordini_elvy import read_filato_tinturia_sheet
        with tempfile.TemporaryDirectory() as temp_dir:
            source = Path(temp_dir) / "short.xlsx"
            workbook = openpyxl.Workbook()
            sheet = workbook.active
            sheet.title = "Filato x Tinturia"
            sheet.append(["Articolo", "Titolo", "Partita", "Rocche", "Peso", "تحضير خام"])
            sheet.append(["G130027S", "100/2", "158694", 1108])
            workbook.save(source)
            workbook.close()

            rows = read_filato_tinturia_sheet(source)
            self.assertEqual(rows[0].rocce, 1108)
            self.assertEqual(rows[0].peso, 0)

    def test_med_check_articolo_normalizes_article_prefix_and_colour(self):
        from pipelines.ordine_med import OrdineMedRow, compute_check_articolo
        record = OrdineMedRow(
            riga=1, code_org="C130027S", titolo="", descr_col="", articolo="C130027S",
            colore="324229.0", rocc=1, abbin="", consegna_input=None, pt_grg="",
            pt_med="", polmoni="", cliente_note="", nota_grg="", nota_col="",
            kg_note="", fabb=None, prezz_note=None,
        )
        compute_check_articolo([record], {("G130027S", "324229")})
        self.assertEqual(record.check_articolo, "")

    def test_med_price_lookup_matches_color_description_when_codes_differ(self):
        from calculate.prezzi import build_price_lookup
        from pipelines.ordine_med import OrdineMedRow, compute_prezzo, compute_prezzo_plus2

        record = OrdineMedRow(
            riga=1, code_org="C010034S", titolo="", descr_col="FLEUR", articolo="C010034S",
            colore="806", rocc=1, abbin="", consegna_input=None, pt_grg="",
            pt_med="", polmoni="", cliente_note="", nota_grg="", nota_col="",
            kg_note="", fabb=None, prezz_note=None, mc=56,
        )
        ambiguous_record = OrdineMedRow(
            riga=2, code_org="C010878S", titolo="", descr_col="@PERLANA", articolo="C010878S",
            colore="7777", rocc=1, abbin="", consegna_input=None, pt_grg="",
            pt_med="", polmoni="", cliente_note="", nota_grg="", nota_col="",
            kg_note="", fabb=None, prezz_note=None, mc=56,
        )
        price_lookup = build_price_lookup(pd.DataFrame([
            {
                "CLARTICOLO": "C010034S", "CLCOLORE": "000806", "CLDESCR": "FLEUR",
                "LIVELLOLPZ": 59, "PREZZOLPZ": 4.47,
            },
            {
                "CLARTICOLO": "C010878S", "CLCOLORE": "001115", "CLDESCR": "@PERLANA",
                "LIVELLOLPZ": 60, "PREZZOLPZ": 4.59,
            },
            {
                "CLARTICOLO": "C010878S", "CLCOLORE": "091115", "CLDESCR": "@PERLANA",
                "LIVELLOLPZ": 61, "PREZZOLPZ": 4.72,
            },
        ]))

        records = [record, ambiguous_record]
        compute_prezzo(records, price_lookup)
        compute_prezzo_plus2(records)

        self.assertEqual(record.livello, 59)
        self.assertEqual(record.prezzo, 4.47)
        self.assertEqual(record.prezzo_plus2, 6.47)
        self.assertEqual(ambiguous_record.livello, "")
        self.assertEqual(ambiguous_record.prezzo, "")

        from pipelines.ordine_med import export_ordine_med_workbook
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir) / "Ordine_MED.xlsx"
            export_ordine_med_workbook(output, records, [])
            workbook = openpyxl.load_workbook(output, data_only=True)
            worksheet = workbook["Ordine da creare"]
            exported_headers = {
                cell.value: worksheet.cell(row=2, column=cell.column).value
                for cell in worksheet[1]
            }
            workbook.close()

        self.assertEqual(exported_headers["LIVELLO"], 59)
        self.assertEqual(exported_headers["PREZZO"], 4.47)
        self.assertEqual(exported_headers["PREZZO + 2$"], 6.47)

    def test_excel_export_keeps_yarn_waiting_comment(self):
        workbook = openpyxl.Workbook()
        worksheet = workbook.active
        _write_typed_excel_table(
            worksheet,
            pd.DataFrame([
                {"Delivery Date": "2026-09-08"},
                {"Delivery Date": "Pending for yarn"},
            ]),
        )
        self.assertEqual(worksheet.cell(row=2, column=1).value, "08/09/2026")
        self.assertEqual(worksheet.cell(row=2, column=1).data_type, "s")
        self.assertEqual(worksheet.cell(row=3, column=1).value, "Pending for yarn")

    def test_on_time_delivery_scores_and_ranks_clients(self):
        states = {
            "P1": {"cliente": "ELVY", "partita": "P1", "consegna": "2026-09-01", "data_uscita": "2026-08-30"},
            "P2": {"cliente": "ELVY", "partita": "P2", "consegna": "2026-09-01", "data_uscita": "2026-09-05"},
            "P3": {"cliente": "MED", "partita": "P3", "consegna": "2026-09-01", "data_uscita": "2026-09-10"},
            "P4": {"cliente": "MED", "partita": "P4", "consegna": "2026-09-01", "data_uscita": ""},  # still open
        }
        summary = compute_on_time_delivery(states)
        med = summary[summary["cliente"] == "MED"].iloc[0]
        elvy = summary[summary["cliente"] == "ELVY"].iloc[0]
        self.assertEqual(med["shipped"], 1)  # P4 has no Data Uscita yet -- excluded
        self.assertEqual(med["on_time_pct"], 0.0)
        self.assertEqual(med["avg_delay_days"], 9.0)
        self.assertEqual(elvy["shipped"], 2)
        self.assertEqual(elvy["on_time_pct"], 50.0)
        # Worst on-time % sorts first.
        self.assertEqual(summary.iloc[0]["cliente"], "MED")

    def test_price_anomaly_flags_large_jump_not_small_one(self):
        df = pd.DataFrame([
            {"CLARTICOLO": "G130", "CLCOLORE": "10", "CLDESCR": "Blue",
             "PREZZOLPZ": 10.00, "_START_DATE": "2026-01-01"},
            {"CLARTICOLO": "G130", "CLCOLORE": "10", "CLDESCR": "Blue",
             "PREZZOLPZ": 15.00, "_START_DATE": "2026-06-01"},  # +50%, flagged
            {"CLARTICOLO": "G170", "CLCOLORE": "20", "CLDESCR": "Red",
             "PREZZOLPZ": 10.00, "_START_DATE": "2026-01-01"},
            {"CLARTICOLO": "G170", "CLCOLORE": "20", "CLDESCR": "Red",
             "PREZZOLPZ": 10.30, "_START_DATE": "2026-06-01"},  # +3%, not flagged
        ])
        anomalies = detect_price_anomalies(df, min_pct_change=10.0)
        self.assertEqual(len(anomalies), 1)
        row = anomalies.iloc[0]
        self.assertEqual(row["CLARTICOLO"], "G130")
        self.assertEqual(row["pct_change"], 50.0)

    def test_compute_delay_days_rules(self):
        from calculate.situazione import compute_delay_days

        # 1. Missing data_qualita -> must be blank
        row_no_qualita = {
            "cliente": "MED", "consegna": "2026-09-10", "data_qualita": "",
            "data_uscita": "2026-09-15",
        }
        self.assertEqual(compute_delay_days(row_no_qualita), "")

        # 2. Missing data_uscita -> must be blank
        row_no_uscita = {
            "cliente": "MED", "consegna": "2026-09-10", "data_qualita": "2026-09-08",
            "data_uscita": "",
        }
        self.assertEqual(compute_delay_days(row_no_uscita), "")

        # 3. Non-Elvy customer: late delivery (5 days late -> "5")
        row_med_late = {
            "cliente": "MED", "consegna": "2026-09-10", "data_qualita": "2026-09-08",
            "data_uscita": "2026-09-15",
        }
        self.assertEqual(compute_delay_days(row_med_late), "5")

        # 4. Non-Elvy customer: early delivery (3 days early -> "-3")
        row_med_early = {
            "cliente": "MED", "consegna": "2026-09-10", "data_qualita": "2026-09-05",
            "data_uscita": "2026-09-07",
        }
        self.assertEqual(compute_delay_days(row_med_early), "-3")

        # 5. Non-Elvy customer: on-time delivery (0 days -> "0")
        row_med_ontime = {
            "cliente": "MED", "consegna": "2026-09-10", "data_qualita": "2026-09-08",
            "data_uscita": "2026-09-10",
        }
        self.assertEqual(compute_delay_days(row_med_ontime), "0")

        # 6. ELVY customer: compares against Delivery Date (late 4 days -> "4")
        row_elvy_late = {
            "cliente": "ELVY", "consegna": "2026-09-01", "delivery_date": "2026-09-10",
            "data_qualita": "2026-09-08", "data_uscita": "2026-09-14",
        }
        self.assertEqual(compute_delay_days(row_elvy_late), "4")

        # 7. ELVY customer: early delivery (early 2 days -> "-2")
        row_elvy_early = {
            "cliente": "3009", "consegna": "2026-09-01", "delivery_date": "2026-09-10",
            "data_qualita": "2026-09-06", "data_uscita": "2026-09-08",
        }
        self.assertEqual(compute_delay_days(row_elvy_early), "-2")

    def test_lazy_module_delegates_to_real_module(self):
        from utility.utils import LazyModule, lazy_call
        import pipelines.ordine_med as real_ordine_med

        proxy = LazyModule("pipelines.ordine_med")
        self.assertTrue(callable(proxy.load_ordine))
        self.assertIs(proxy.load_ordine, real_ordine_med.load_ordine)

        wrapped = lazy_call("pipelines.ordine_med", "load_ordine")
        self.assertTrue(callable(wrapped))

    def test_kamal_tab_lazy_names_resolve_to_real_targets(self):
        # Regression guard for the startup-performance fix: kamal_tab.py's
        # heavy names (pandas/openpyxl/pdfplumber-backed) must still
        # actually delegate to the real functions/classes/constants when
        # called, not just avoid crashing at import time.
        import gui.tabs.kamal_tab as kt
        import pipelines.ordine_kamal as real_ordine_kamal
        import calculate.lotti as real_lotti

        self.assertEqual(kt.KAMAL_ARTICLE_PREFIX, real_ordine_kamal.KAMAL_ARTICLE_PREFIX)
        self.assertTrue(callable(kt.load_dfm_cache))
        self.assertIsInstance(kt.load_dfm_cache(), dict)
        self.assertEqual(kt.lotti_logic.RAW_ARTICOLO_PREFIXES, real_lotti.RAW_ARTICOLO_PREFIXES)
        self.assertTrue(callable(kt.build_ordine_kamal_rows))
        self.assertTrue(callable(kt.export_ordini_full))

    def test_days_in_qc_formats_as_clean_integer_no_trailing_zero(self):
        # compute_situation() derives days_in_qc from a float64 column
        # (dt.days on a Timedelta series with some NaT rows upcasts to
        # float) -- naively fillna("").astype(str) on that turns a real
        # value like 3 into the string "3.0" instead of "3".
        import pandas as pd
        col = pd.Series([3.0, float("nan"), 7.0])
        formatted = col.apply(lambda v: str(int(v)) if pd.notna(v) else "")
        self.assertEqual(formatted.tolist(), ["3", "", "7"])

    def test_delivery_date_highlight_flags_dates_under_threshold(self):
        from exporters.biglietti_exporter import _style_sheet
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["Articolo", "Delivery Date"])
        ws.append(["G130", date(2026, 9, 10)])
        ws.append(["G140", "Pending for yarn"])
        _style_sheet(ws, days_until_highlight_columns={"Delivery Date": 4})

        rules = list(ws.conditional_formatting)
        formulas = [rule.sqref for rule in rules]
        self.assertTrue(any(str(f) == "B2:B3" for f in formulas), formulas)
        matching = [r for r in rules if str(r.sqref) == "B2:B3"]
        self.assertEqual(len(matching), 1)
        formula_text = list(matching[0].rules[0].formula)[0]
        self.assertIn("ISNUMBER(B2)", formula_text)
        self.assertIn("TODAY()", formula_text)
        self.assertIn("<4", formula_text)

    def test_delivery_date_highlight_absent_when_column_missing(self):
        # MED/EL_KAMAL sheets don't have a "Delivery Date" column -- passing
        # the threshold unconditionally must simply no-op for them.
        from exporters.biglietti_exporter import _style_sheet
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["Articolo", "Consegna"])
        ws.append(["G130", date(2026, 9, 10)])
        _style_sheet(ws, days_until_highlight_columns={"Delivery Date": 4})
        self.assertEqual(len(list(ws.conditional_formatting)), 0)

    def test_email_template_round_trips_through_dict(self):
        from utility.email_compose import EmailTemplate
        original = EmailTemplate(to="a@x.com; b@y.com", cc="c@z.com", subject="Order ready", body="Please find attached.")
        restored = EmailTemplate.from_dict(original.to_dict())
        self.assertEqual(restored, original)
        self.assertFalse(restored.is_blank())

    def test_email_template_blank_detection(self):
        from utility.email_compose import EmailTemplate

        self.assertTrue(EmailTemplate().is_blank())
        self.assertTrue(EmailTemplate.from_dict(None).is_blank())
        self.assertTrue(EmailTemplate.from_dict({}).is_blank())
        self.assertFalse(EmailTemplate(subject="hi").is_blank())

    def test_elvy_invoice_conversion_loads_its_mapping_helpers(self):
        from types import SimpleNamespace
        from gui.gui import ConverterApp

        app = SimpleNamespace(
            after=lambda *_args: None,
            _on_einv_conversion_done=lambda *_args: None,
        )
        with patch("parsers.elvy_mapping.load_elvy_mapping", return_value={}):
            ConverterApp._run_einv_conversion(app, [], Path("."), False)

    def test_open_outlook_email_raises_clear_error_without_outlook(self):
        # On this (non-Windows / no-Outlook) test environment, win32com
        # simply isn't importable -- confirm that surfaces as a clean,
        # user-facing RuntimeError rather than an unhandled ImportError.
        from utility.email_compose import EmailTemplate, open_outlook_email
        try:
            import win32com.client  # noqa: F401
            self.skipTest("win32com is available in this environment")
        except ImportError:
            pass
        with self.assertRaises(RuntimeError):
            open_outlook_email(EmailTemplate(to="a@x.com", subject="hi"), [])

    def test_open_outlook_email_prefers_already_running_instance(self):
        # Regression guard for the "Welcome to Outlook" setup-wizard bug:
        # GetActiveObject (attach to Outlook that's already open and signed
        # in) must be tried before Dispatch (which can spin up a fresh,
        # unconfigured instance and land on the account-setup wizard).
        import sys
        import types
        from unittest.mock import MagicMock

        fake_mail = MagicMock()
        fake_outlook = MagicMock()
        fake_outlook.CreateItem.return_value = fake_mail

        fake_client = types.ModuleType("win32com.client")
        fake_client.GetActiveObject = MagicMock(return_value=fake_outlook)
        fake_client.Dispatch = MagicMock(side_effect=AssertionError("Dispatch should not be called when GetActiveObject succeeds"))
        fake_win32com = types.ModuleType("win32com")
        fake_win32com.client = fake_client

        with patch.dict(sys.modules, {"win32com": fake_win32com, "win32com.client": fake_client}):
            from utility.email_compose import EmailTemplate, open_outlook_email
            template = EmailTemplate(to="a@x.com", cc="b@x.com", subject="Order Ready", body="See attached.")
            open_outlook_email(template, [])

        fake_client.GetActiveObject.assert_called_once_with("Outlook.Application")
        fake_outlook.CreateItem.assert_called_once_with(0)
        self.assertEqual(fake_mail.To, "a@x.com")
        self.assertEqual(fake_mail.Subject, "Order Ready")
        fake_mail.Display.assert_called_once()

    def test_open_outlook_email_falls_back_to_dispatch_when_not_running(self):
        import sys
        import types
        from unittest.mock import MagicMock

        fake_mail = MagicMock()
        fake_outlook = MagicMock()
        fake_outlook.CreateItem.return_value = fake_mail

        fake_client = types.ModuleType("win32com.client")
        fake_client.GetActiveObject = MagicMock(side_effect=Exception("no running instance"))
        fake_client.Dispatch = MagicMock(return_value=fake_outlook)
        fake_win32com = types.ModuleType("win32com")
        fake_win32com.client = fake_client

        with patch.dict(sys.modules, {"win32com": fake_win32com, "win32com.client": fake_client}):
            from utility.email_compose import EmailTemplate, open_outlook_email
            open_outlook_email(EmailTemplate(to="a@x.com", subject="hi"), [])

        fake_client.Dispatch.assert_called_once_with("Outlook.Application")
        fake_mail.Display.assert_called_once()

    def test_no_deferred_lambda_captures_dead_except_variable(self):
        # Regression guard for a recurring bug class: `except E as exc:`
        # followed by `self.after(0, lambda: ...str(exc)...)` looks fine,
        # but Python deletes `exc` the moment the except block exits, and
        # `self.after` runs the lambda *after* that -- it raises NameError
        # right when showing the user the real error message. The fix is
        # always `lambda exc=exc: ...` (binds the value at definition time).
        # This scans every module (not just the ones fixed before) so the
        # same mistake can't quietly reappear elsewhere.
        import ast
        import glob

        violations = []
        for path in sorted(glob.glob("**/*.py", recursive=True)):
            if "/.git/" in path or path.startswith("tests/") or path.startswith("tests\\"):
                continue
            try:
                tree = ast.parse(Path(path).read_text(encoding="utf-8"))
            except SyntaxError:
                continue
            for node in ast.walk(tree):
                if not isinstance(node, ast.ExceptHandler) or not node.name:
                    continue
                exc_name = node.name
                for sub in ast.walk(node):
                    if not isinstance(sub, ast.Lambda):
                        continue
                    bound_args = {a.arg for a in sub.args.args + sub.args.kwonlyargs}
                    if exc_name in bound_args:
                        continue  # e.g. lambda exc=exc: ... -- safe, value captured at definition time
                    for name_node in ast.walk(sub.body):
                        if isinstance(name_node, ast.Name) and name_node.id == exc_name:
                            violations.append(f"{path}:{sub.lineno}: lambda captures '{exc_name}' from its enclosing except block without binding it as a default argument")
                            break

        self.assertEqual(violations, [])

    def test_is_newer_version_compares_correctly(self):
        from utility.updater import is_newer_version
        self.assertTrue(is_newer_version("1.2.0", "1.1.9"))
        self.assertTrue(is_newer_version("v2.0.0", "1.9.9"))  # leading "v" tolerated
        self.assertFalse(is_newer_version("1.1.0", "1.2.0"))
        self.assertFalse(is_newer_version("1.2.0", "1.2.0"))  # equal -- not "newer"

    def test_safe_extract_blocks_zip_slip(self):
        import zipfile
        from utility.updater import _safe_extract
        with tempfile.TemporaryDirectory() as temp_dir:
            zip_path = Path(temp_dir) / "evil.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("../../evil.txt", "should never land outside destination")
            destination = Path(temp_dir) / "dest"
            destination.mkdir()
            with self.assertRaises(Exception):
                _safe_extract(zip_path, destination)
            self.assertFalse((Path(temp_dir) / "evil.txt").exists())

    def test_install_update_requires_frozen_app(self):
        from utility.updater import install_update
        with tempfile.TemporaryDirectory() as temp_dir:
            zip_path = Path(temp_dir) / "update.zip"
            zip_path.write_bytes(b"not a real zip, but frozen-check happens first")
            with self.assertRaises(RuntimeError):
                install_update(zip_path, Path(temp_dir) / "install", "2.0.0")

    def test_install_update_generates_backup_and_rollback_script(self):
        # Regression guard for "what happens if the update fails": the
        # generated PowerShell must back up the current install before
        # overwriting it, and roll back to that backup both if the new
        # build crashes immediately on launch and if the file copy never
        # succeeds -- not just replace files and hope for the best.
        import sys
        import zipfile
        from unittest.mock import patch
        import utility.updater as updater

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_dir = Path(temp_dir)
            zip_path = temp_dir / "update.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("Planning/Planning.exe", "fake exe bytes")
            install_dir = temp_dir / "install"
            install_dir.mkdir()

            captured = {}

            def fake_popen(args, **kwargs):
                captured["script"] = Path(args[-1]).read_text(encoding="utf-8")
                captured["creationflags"] = kwargs.get("creationflags", 0)
                return object()

            with patch.object(sys, "frozen", True, create=True), patch("subprocess.Popen", side_effect=fake_popen):
                updater.install_update(zip_path, install_dir, "2.0.0")

            script = captured["script"]
            self.assertIn("$backup", script)
            self.assertIn("Restore-Backup", script)
            self.assertIn("Copy-Item -LiteralPath $_.FullName -Destination $backup", script)  # backs up BEFORE overwriting
            self.assertIn("Get-Process -Name 'Planning'", script)  # verifies the new build actually starts running
            self.assertIn("sawRunning", script)  # tolerates AV closing/relaunching under a different PID
            self.assertIn("rolling back to the previous version", script)
            # The rollback path must run for every real failure mode: a
            # crash-on-launch, a copy that never succeeded, and -- as an
            # outer safety net -- literally anything else that throws
            # (e.g. Restore-Backup itself failing under $ErrorActionPreference
            # = 'Stop' must not skip relaunching something entirely).
            self.assertEqual(script.count("Restore-Backup"), 4)  # 1 definition + 3 call sites

    def test_install_update_relaunches_de_elevated(self):
        # Regression guard for the real-world symptom this was built to
        # catch: after the elevation fix made updates actually succeed
        # (see test_install_update_elevates_when_install_dir_unwritable),
        # the app stopped reopening on its own afterwards -- a plain
        # Start-Process for Planning.exe, called from a script that may
        # itself be running elevated, launches Planning.exe elevated too,
        # and Windows' focus-stealing prevention can leave that window
        # never visibly coming to the front. Every relaunch (success and
        # every rollback path) must go through the Shell.Application-based
        # de-elevated launch, and the one legitimate raw Start-Process left
        # (Start-PlanningNormally's own fallback if COM is unavailable) must
        # not recurse into itself.
        import sys
        import zipfile
        from unittest.mock import patch
        import utility.updater as updater

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_dir = Path(temp_dir)
            zip_path = temp_dir / "update.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("Planning/Planning.exe", "fake exe bytes")
            install_dir = temp_dir / "install"
            install_dir.mkdir()

            captured = {}

            def fake_popen(args, **kwargs):
                captured["script"] = Path(args[-1]).read_text(encoding="utf-8")
                return object()

            with patch.object(sys, "frozen", True, create=True), patch("subprocess.Popen", side_effect=fake_popen):
                updater.install_update(zip_path, install_dir, "2.0.0")

            script = captured["script"]
            self.assertIn("function Start-Planning", script)
            self.assertNotIn("Start-PlanningNormally", script)
            # De-elevated launch through the non-elevated explorer shell comes first...
            self.assertIn('New-Object -ComObject "Shell.Application"', script)
            self.assertIn("ShellExecute($exePath", script)
            # ...and every relaunch site (success + 3 rollback/failure paths) goes
            # through the wrapper: 1 definition + 4 call sites.
            self.assertEqual(script.count("Start-Planning"), 5)
            # Raw Start-Process / cmd start for $exePath live only inside the wrapper's fallbacks.
            wrapper_start = script.index("function Start-Planning")
            wrapper_end = script.index("\ntry {", wrapper_start)  # next top-level statement after the function
            for needle in ("Start-Process -FilePath $exePath", "Start-Process -FilePath 'cmd.exe'"):
                if needle in script:
                    self.assertGreater(script.index(needle), wrapper_start)
                    self.assertLess(script.index(needle), wrapper_end)

    def test_install_update_detaches_helper_from_any_job_object(self):
        # Regression guard: if Planning.exe runs inside a Windows Job Object
        # (some launchers/security software do this), closing the parent
        # can silently kill an undetached child the instant the parent
        # exits -- the update helper would never get to run at all, and
        # the person is left thinking the update just silently failed.
        # CREATE_BREAKAWAY_FROM_JOB (+ CREATE_NEW_PROCESS_GROUP) makes sure
        # it survives regardless.
        import subprocess
        import sys
        import zipfile
        from unittest.mock import patch
        import utility.updater as updater

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_dir = Path(temp_dir)
            zip_path = temp_dir / "update.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("Planning/Planning.exe", "fake exe bytes")
            install_dir = temp_dir / "install"
            install_dir.mkdir()

            captured = {}

            def fake_popen(args, **kwargs):
                captured["creationflags"] = kwargs.get("creationflags", 0)
                return object()

            fake_flags = type("F", (), {
                "CREATE_NO_WINDOW": 0x08000000,
                "CREATE_NEW_PROCESS_GROUP": 0x00000200,
                "CREATE_BREAKAWAY_FROM_JOB": 0x01000000,
            })
            with patch.object(sys, "frozen", True, create=True), \
                 patch("subprocess.Popen", side_effect=fake_popen), \
                 patch.object(subprocess, "CREATE_NO_WINDOW", fake_flags.CREATE_NO_WINDOW, create=True), \
                 patch.object(subprocess, "CREATE_NEW_PROCESS_GROUP", fake_flags.CREATE_NEW_PROCESS_GROUP, create=True), \
                 patch.object(subprocess, "CREATE_BREAKAWAY_FROM_JOB", fake_flags.CREATE_BREAKAWAY_FROM_JOB, create=True):
                updater.install_update(zip_path, install_dir, "2.0.0")

            flags = captured["creationflags"]
            self.assertTrue(flags & fake_flags.CREATE_BREAKAWAY_FROM_JOB)
            self.assertTrue(flags & fake_flags.CREATE_NEW_PROCESS_GROUP)

    def test_needs_elevation_detects_unwritable_install_dir(self):
        # Regression guard for the real-world failure this was built to
        # catch: Planning installed under C:\Program Files needs
        # Administrator rights to write to, which the (non-admin) running
        # process does not have -- every Copy-Item in the update script,
        # including the rollback's own copy-back, failed with Access
        # Denied and the app never relaunched at all.
        import os
        import stat
        from utility.updater import _needs_elevation

        with tempfile.TemporaryDirectory() as temp_dir:
            writable_dir = Path(temp_dir) / "writable"
            writable_dir.mkdir()
            self.assertFalse(_needs_elevation(writable_dir))

            if os.name != "nt" and os.geteuid() != 0:  # root and Windows ACLs both bypass this chmod-based probe
                readonly_dir = Path(temp_dir) / "readonly"
                readonly_dir.mkdir()
                readonly_dir.chmod(stat.S_IREAD | stat.S_IEXEC)
                try:
                    self.assertTrue(_needs_elevation(readonly_dir))
                finally:
                    readonly_dir.chmod(stat.S_IRWXU)  # let TemporaryDirectory clean up

    def test_install_update_elevates_when_install_dir_unwritable(self):
        import sys
        import zipfile
        from unittest.mock import patch
        import utility.updater as updater

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_dir = Path(temp_dir)
            zip_path = temp_dir / "update.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("Planning/Planning.exe", "fake exe bytes")
            install_dir = temp_dir / "install"
            install_dir.mkdir()

            popen_called = []
            shell_execute_calls = []

            class FakeShell32:
                def ShellExecuteW(self, *args):
                    shell_execute_calls.append(args)
                    return 42  # >32 means "launched successfully" per the Windows API

            with patch.object(sys, "frozen", True, create=True), \
                 patch("subprocess.Popen", side_effect=lambda *a, **k: popen_called.append(1) or object()), \
                 patch.object(updater, "_needs_elevation", return_value=True), \
                 patch.dict("sys.modules", {"ctypes": type(sys)("ctypes")}):
                sys.modules["ctypes"].windll = type(sys)("windll")
                sys.modules["ctypes"].windll.shell32 = FakeShell32()
                updater.install_update(zip_path, install_dir, "2.0.0")

            self.assertEqual(popen_called, [])  # must NOT use the non-elevated path
            self.assertEqual(len(shell_execute_calls), 1)
            self.assertEqual(shell_execute_calls[0][1], "runas")

    def test_download_installer_rejects_truncated_download(self):
        # A network hiccup mid-download must be caught here, with a clear
        # message -- not silently produce a corrupt ZIP that only fails
        # much later, deep inside the PowerShell install script, as
        # "not a valid application for this OS platform".
        from unittest.mock import patch, MagicMock
        from utility.updater import download_installer, ReleaseInfo

        release = ReleaseInfo(
            version="2.0.0", tag_name="v2.0.0", title="v2.0.0", notes="", page_url="",
            installer_url="https://example.com/Planning.zip", installer_name="Planning.zip",
        )
        fake_response = MagicMock()
        fake_response.headers = {"Content-Length": "1000"}
        fake_response.read.side_effect = [b"short", b""]  # far less than 1000 bytes, then EOF
        fake_response.__enter__ = lambda self: fake_response
        fake_response.__exit__ = lambda self, *a: False

        with patch("utility.updater.urlopen", return_value=fake_response):
            with self.assertRaises(RuntimeError) as ctx:
                download_installer(release)
        self.assertIn("incomplete", str(ctx.exception).lower())

    def test_download_installer_rejects_corrupt_zip(self):
        from unittest.mock import patch, MagicMock
        from utility.updater import download_installer, ReleaseInfo

        release = ReleaseInfo(
            version="2.0.0", tag_name="v2.0.0", title="v2.0.0", notes="", page_url="",
            installer_url="https://example.com/Planning.zip", installer_name="Planning.zip",
        )
        fake_response = MagicMock()
        fake_response.headers = {}
        fake_response.read.side_effect = [b"this is not a zip file at all", b""]
        fake_response.__enter__ = lambda self: fake_response
        fake_response.__exit__ = lambda self, *a: False

        with patch("utility.updater.urlopen", return_value=fake_response):
            with self.assertRaises(RuntimeError) as ctx:
                download_installer(release)
        self.assertIn("corrupt", str(ctx.exception).lower())


# ----------------------------------------------- Prezzo Ord. without a Listini price

class PriceMissingFromListiniTests(unittest.TestCase):
    """A Prezzo Ord. with no Prezzo Listini must be listed in "errori prezzi
    colori" and shown red in Situazione Generale, like any other price error."""

    @staticmethod
    def _frame():
        return pd.DataFrame([
            # priced in Wincoint, no Listini price  -> ERROR (the reported bug)
            {"cliente": "A", "articolo": "ART1", "codice": "790001", "colore": "KA-OPTICAL", "prezzo": "5,50", "prezzo_lisini": ""},
            # priced and matching                    -> fine
            {"cliente": "A", "articolo": "ART1", "codice": "790002", "colore": "KA-BEG 7", "prezzo": "6.00", "prezzo_lisini": "6.00"},
            # priced but different                   -> ERROR (already worked)
            {"cliente": "A", "articolo": "ART1", "codice": "790003", "colore": "KA-GRY 9", "prezzo": "7.00", "prezzo_lisini": "6.00"},
            # Wincoint left it blank, Listini has it -> fine
            {"cliente": "A", "articolo": "ART1", "codice": "790004", "colore": "KA-SMO 6", "prezzo": "", "prezzo_lisini": "6.00"},
            # neither side has a price               -> fine
            {"cliente": "A", "articolo": "ART1", "codice": "790005", "colore": "KA-ORG 7", "prezzo": "", "prezzo_lisini": ""},
            # price 0 and no Listini                 -> fine (same as the notifications)
            {"cliente": "A", "articolo": "ART1", "codice": "790006", "colore": "KA-GRY 7", "prezzo": "0", "prezzo_lisini": ""},
            # the 0.01 placeholder                   -> ERROR
            {"cliente": "A", "articolo": "ART1", "codice": "790007", "colore": "KA-FUNGI", "prezzo": "0.01", "prezzo_lisini": "6.00"},
            # blank row with a stray price           -> ignored
            {"cliente": "A", "articolo": "", "codice": "790008", "colore": "X", "prezzo": "9", "prezzo_lisini": ""},
        ])

    def test_price_missing_from_listini_is_listed(self):
        from calculate.situazione import find_price_anomalies
        found = {a["codice"]: a["issue"] for a in find_price_anomalies(self._frame())}
        self.assertEqual(set(found), {"790001", "790003", "790007"})
        self.assertIn("senza Prezzo Listini", found["790001"])
        self.assertIn("diverso", found["790003"])
        self.assertIn("sospetto", found["790007"])

    def test_nothing_is_missing_while_listini_is_not_loaded_at_all(self):
        """A fully blank Prezzo Listini column = Listini not uploaded yet, not
        "every colour is unpriced": it must not flood the list or turn the table red."""
        from calculate.situazione import find_price_anomalies, listini_loaded
        frame = self._frame()
        frame["prezzo_lisini"] = ""
        self.assertFalse(listini_loaded(frame))
        self.assertEqual([a["codice"] for a in find_price_anomalies(frame)], ["790007"])  # only the placeholder

    def test_price_issue_rules_and_parsing(self):
        from calculate.situazione import parse_price, price_issue
        self.assertEqual(parse_price("$ 5,5"), 5.5)
        self.assertEqual(parse_price(" "), None)
        self.assertEqual(parse_price("abc"), None)
        self.assertIsNone(price_issue("5.50", "5.505"))            # within a cent
        self.assertIsNone(price_issue("", "5"))
        self.assertIsNotNone(price_issue("5", ""))
        self.assertIsNone(price_issue("5", "", listini_available=False))
        self.assertIsNotNone(price_issue("0.01", "", listini_available=False))

    def test_situazione_tree_marks_the_same_rows_red(self):
        """The Treeview highlight and the error list use one rule."""
        import tkinter as tk
        from calculate.situazione import find_price_anomalies
        from gui.tabs.situazione_tab import SituazioneTab
        try:
            root = tk.Tk()
        except tk.TclError:
            self.skipTest("no display")
        self.addCleanup(root.destroy)
        tab = SituazioneTab(root)
        tab._db_restore_scheduled = tab._sources_restore_started = True      # no background restore under test
        frame = self._frame()
        tab.current_df = frame
        tab._render_tree(frame)
        for _ in range(20):
            root.update()
        red = {tab.tree.set(i, "codice") for i in tab.tree.get_children() if "price_error" in tab.tree.item(i, "tags")}
        self.assertEqual(red, {a["codice"] for a in find_price_anomalies(frame)})
