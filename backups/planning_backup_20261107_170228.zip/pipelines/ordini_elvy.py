"""
ordini_elvy.py — Derives the "Ordini ELVY" sheet from parsed Purchase Order
rows (see pdf_parser.OrderRow), for the Elvy raw-yarn dyeing workflow.

Column mapping (fixed values confirmed with the user; header labels and
types match EXCEL_PER_ORDINE_VENDITA_EGITTO.xlsx, the real ERP import
template, so this sheet can be pasted straight into it)
--------------------------------------------------------------------------
CLIENTE              — always 3009 (number).
ARTICOLO             — the row's raw code (already G-prefixed via the Elvy
                        mapping) converted to "C" — it's entering dyeing.
COLORE                — copied from the row's DFM colour lookup (number).
Q.TA                 — copied as-is (number).
CONSEGNA             — today + 14 days (real date).
COMMENTO             — "PG-X-PO-<POD No>-<year>", year from the row's Po Date.
LAVORANTE            — always 900901 (number).
LAV. SUCC            — always 900161 (number).
DATA RICONSEGNA      — CONSEGNA - 1 day (real date).
MAG. GREGGIO         — always 900923 (number).
SIGLA DISPOSIZIONE   — always "D".
BAGNO PREPOSTO       — blank unless the operator typed a "First bagno" (e.g.
                        T1200); then it follows calculate.bagno: one bath per
                        run of consecutive same-colour rows (the same group
                        Abbina / GRUPPO MACCHINA is worked out from), first
                        row blank, following rows carry the bath number.
GRUPPO MACCHINA      — the physical machine number for the row's Abbina
                        cone count (see abbina_calculator.MACHINE_CODES),
                        as a number.
"""

from __future__ import annotations
from utility.excel_io import safe_save_workbook

import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING

from calculate.abbina_calculator import MACHINE_CODES
from calculate.bagno import sequence_bagno
from parsers.pdf_parser import OrderRow
from utility.master_data import finished_articolo_for, raw_articolo_for
from utility.utils import clean_text

if TYPE_CHECKING:
    import pandas as pd

CLIENTE_CODE = 3009
LAVORANTE_CODE = 900901
LAVORANTE_SUCCESSIVO_CODE = 900161
STOCK_MAG_CODE = 900923
SIGLA_DISPO_CODE = "D"
CONSEGNA_LEAD_DAYS = 14

RE_ABBINA_CONES = re.compile(r"Machine\s+(\d+)\s*Cones?", re.IGNORECASE)
RE_YEAR = re.compile(r"(\d{4})")


@dataclass
class OrdiniElvyRow:
    """One derived row for the "Ordini ELVY" sheet."""
    cliente: int = CLIENTE_CODE
    articolo_delta: str = ""
    coloredfm: int | None = None
    quantity_cones: float | None = None
    data_consegna: datetime | None = None
    commento: str = ""
    lavorante: int = LAVORANTE_CODE
    lavorante_successivo: int = LAVORANTE_SUCCESSIVO_CODE
    data_riconsegna: datetime | None = None
    stock_mag: int = STOCK_MAG_CODE
    sigla_dispo: str = SIGLA_DISPO_CODE
    bagno_proposto: str = ""
    macchina: int | None = None
    reference_to: str = ""
    # Not an ERP column: the customer's raw-yarn lot written after "Lot :" in the PDF ("" when none).
    lot: str = ""
    # Not an ERP column: identifies the machine batch (consecutive same-colour
    # run) this row belongs to -- the input of the First Bagno sequence.
    bagno_group: tuple | None = None


def _to_c_code(articolo_delta: str) -> str:
    """Convert a G-prefixed raw code to its C-prefixed dyeing-entry form."""
    articolo_delta = clean_text(articolo_delta)
    if articolo_delta.upper().startswith("G"):
        return "C" + articolo_delta[1:]
    return ""


def _extract_year(po_date: str) -> str:
    """Pull the 4-digit year out of a Po Date string like '19/4/2026'."""
    m = RE_YEAR.search(clean_text(po_date))
    return m.group(1) if m else ""


def _to_int(value: str) -> int | None:
    value = clean_text(value)
    try:
        return int(value)
    except ValueError:
        return None


def _machine_code_for_abbina(abbina: str) -> int | None:
    """Look up the MACCHINA code from an Abbina value like 'Machine 72 Cones'."""
    m = RE_ABBINA_CONES.search(clean_text(abbina))
    if not m:
        return None
    return MACHINE_CODES.get(int(m.group(1)))


def _elvy_bagno_group_keys(rows: list[OrderRow]) -> list[tuple]:
    """One key per row: consecutive rows of the same PO, Colour and Abbina form
    one machine batch.  Mirrors AbbinaCalculator (same-colour runs, per PDF) --
    a different PO never joins a run, and an Abbina typed on the PDF that
    differs inside a run still splits it, so the key can never disagree with
    GRUPPO MACCHINA."""
    keys: list[tuple] = []
    run = -1
    previous: tuple | None = None
    for r in rows:
        signature = (clean_text(r.pod_no), r.colour, clean_text(r.abbina), getattr(r, "abbina_batch", 0))
        if signature != previous:
            run += 1
            previous = signature
        keys.append(("elvy", run))
    return keys


def build_ordini_elvy_rows(rows: list[OrderRow], first_bagno: str | None = None) -> list[OrdiniElvyRow]:
    """Build one OrdiniElvyRow per OrderRow, using today's date as the basis
    for CONSEGNA / DATA RICONSEGNA.

    first_bagno: optional "First bagno" (e.g. "T1200").  When given, BAGNO
    PREPOSTO is filled per calculate.bagno; raises ValueError if malformed.
    """
    # Dates are written as real Excel dates -- midnight, no time of day.
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    data_consegna_dt = today + timedelta(days=CONSEGNA_LEAD_DAYS)
    data_riconsegna_dt = data_consegna_dt - timedelta(days=1)

    bagno_values = sequence_bagno(_elvy_bagno_group_keys(rows), first_bagno)

    out: list[OrdiniElvyRow] = []
    for r, bagno in zip(rows, bagno_values):
        year = _extract_year(r.po_date)
        lot = clean_text(r.lot)
        # "PG-X(<lot>)" when the PDF names the customer's lot, plain "PG-X" otherwise; the
        # rest of the comment (PO number and year) is the same either way.
        waiting = f"PG-X({lot})" if lot else "PG-X"
        commento = f"{waiting}-PO-{clean_text(r.pod_no)}-{year}" if year else f"{waiting}-PO-{clean_text(r.pod_no)}"
        reference_to = clean_text(r.reference_to)
        if reference_to:
            commento = f"{commento}-ref.{reference_to}"

        out.append(OrdiniElvyRow(
            articolo_delta=_to_c_code(r.articolo_delta),
            coloredfm=_to_int(r.coloredfm),
            quantity_cones=r.quantity_cones,
            data_consegna=data_consegna_dt,
            commento=commento,
            data_riconsegna=data_riconsegna_dt,
            bagno_proposto=bagno,
            macchina=_machine_code_for_abbina(r.abbina),
            reference_to=reference_to,
            lot=lot,
        ))
    # Keep the group key on the row too, for callers that want to inspect it.
    for row, key in zip(out, _elvy_bagno_group_keys(rows)):
        row.bagno_group = key
    return out


# ---------------------------------------------------------------------------
# Updating an existing external ERP file in place
# ---------------------------------------------------------------------------

# Header text (normalized: stripped, case-insensitive) -> OrdiniElvyRow
# attribute. Matches EXCEL_PER_ORDINE_VENDITA_EGITTO.xlsx's own headers, so
# the target file's column ORDER doesn't have to match ours exactly — only
# the header text does.
_HEADER_TO_ATTR = {
    "cliente": "cliente",
    "articolo": "articolo_delta",
    "colore": "coloredfm",
    "q.ta": "quantity_cones",
    "consegna": "data_consegna",
    "commento": "commento",
    "lavorante": "lavorante",
    "lav. succ": "lavorante_successivo",
    "data riconsegna": "data_riconsegna",
    "mag. greggio": "stock_mag",
    "sigla disposizione": "sigla_dispo",
    "bagno preposto": "bagno_proposto",
    "gruppo macchina": "macchina",
    "reference to": "reference_to",
}


def update_existing_ordini_file(target_path: Path, ordini_rows: list[OrdiniElvyRow]) -> int:
    """
    Open the existing ERP import file at *target_path*, clear every data
    row (everything from row 2 down — the header row is left untouched),
    write *ordini_rows* starting at row 2 matched to that file's own
    header text, save, and close.

    Returns the number of rows written. Raises if the file can't be
    opened (e.g. it's currently open in Excel) or has no recognizable
    header row.
    """
    import openpyxl  # local import: this module doesn't need openpyxl otherwise

    wb = openpyxl.load_workbook(target_path)
    ws = None
    col_attr: dict[int, str] = {}
    # ERP templates may contain several sheets and the active sheet is not
    # guaranteed to be the import sheet. Find the sheet by its headers.
    for candidate in wb.worksheets:
        candidate_attrs: dict[int, str] = {}
        header_cells = next(candidate.iter_rows(min_row=1, max_row=1))
        for cell in header_cells:
            if cell.value is None:
                continue
            key = " ".join(str(cell.value).strip().lower().split())
            attr = _HEADER_TO_ATTR.get(key)
            if attr:
                candidate_attrs[cell.column] = attr
        if candidate_attrs:
            ws = candidate
            col_attr = candidate_attrs
            break

    if ws is None or not col_attr:
        wb.close()
        raise ValueError(
            "None of this file's column headers match the expected Ordini "
            "ELVY headers (CLIENTE, ARTICOLO, COLORE, ...) — is this the "
            "right file?"
        )

    if ws.max_row > 1:
        ws.delete_rows(2, ws.max_row - 1)

    for row_offset, row_data in enumerate(ordini_rows):
        row_idx = 2 + row_offset
        for col_idx, attr in col_attr.items():
            value = getattr(row_data, attr, None)
            cell = ws.cell(row=row_idx, column=col_idx)
            cell.value = value
            if isinstance(value, datetime):
                cell.number_format = "DD/MM/YYYY"

    safe_save_workbook(wb, target_path, keep_backup=False)
    wb.close()
    return len(ordini_rows)


_FILATO_HEADER_TO_ATTR = {
    "articolo": "articolo",
    "titolo": "titolo",
    "partita": "partita",
    "rocche": "rocce",
    "rocce": "rocce",  # backwards compatibility with older exports
    "peso": "peso",
    "تحضير خام": "label",
    # the Filato x Tinturia master's own headers
    "partita.gg": "partita",
    "عدد": "rocce",
    "وزن": "peso",
    "custom": "label",
}


def _partita_text(value) -> str:
    """A Partita read from Excel: a number (159806, or 159806.0) is shown without a decimal part."""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value or "")


def read_filato_tinturia_sheet(source_path: Path, missing_ok: bool = False) -> list[RawYarnMatch]:
    """Read an existing 'Filato x Tinturia' sheet back into RawYarnMatch rows.

    missing_ok: the workbook only gets that sheet when raw-yarn stock was
    matched.  With no stock (or nothing matched) there is simply no sheet --
    callers that extract the Filato file pass missing_ok=True and get an empty
    list, which writes a header-only file (clearing stale rows from a previous
    order) instead of failing the whole conversion."""
    import openpyxl  # local import: this module doesn't need openpyxl otherwise

    wb = openpyxl.load_workbook(source_path, data_only=True)
    try:
        if "Filato x Tinturia" not in wb.sheetnames:
            if missing_ok:
                return []
            raise ValueError(f"{source_path.name} has no \"Filato x Tinturia\" sheet.")
        ws = wb["Filato x Tinturia"]

        header_cells = next(ws.iter_rows(min_row=1, max_row=1))
        col_attr: dict[int, str] = {}
        for cell in header_cells:
            if cell.value is None:
                continue
            attr = _FILATO_HEADER_TO_ATTR.get(str(cell.value).strip().lower())
            if attr:
                col_attr[cell.column] = attr

        rows: list[RawYarnMatch] = []
        for row_idx in range(2, ws.max_row + 1):
            values = {
                attr: ws.cell(row=row_idx, column=col_idx).value
                for col_idx, attr in col_attr.items()
            }
            if not any(v not in (None, "") for v in values.values()):
                continue
            rows.append(RawYarnMatch(
                articolo=str(values.get("articolo") or ""),
                titolo=str(values.get("titolo") or ""),
                partita=_partita_text(values.get("partita")),
                rocce=float(values.get("rocce") or 0),
                peso=float(values.get("peso") or 0),
                label=str(values.get("label") or "تحضير خام"),
            ))
        return rows
    finally:
        wb.close()


def update_existing_filato_file(target_path: Path, matches: list[RawYarnMatch]) -> int:
    """
    Same transfer logic as update_existing_ordini_file(): open the existing
    file at *target_path*, match its header row (any sheet/order, matched
    by header TEXT) to Articolo/Titolo/Partita/Rocce/Peso/تحضير خام, clear
    every data row from row 2 down, write *matches* starting at row 2, save.
    Returns the number of rows written.
    """
    import openpyxl  # local import: this module doesn't need openpyxl otherwise

    wb = openpyxl.load_workbook(target_path)
    ws = wb.active

    header_cells = next(ws.iter_rows(min_row=1, max_row=1))
    col_attr: dict[int, str] = {}
    for cell in header_cells:
        if cell.value is None:
            continue
        attr = _FILATO_HEADER_TO_ATTR.get(str(cell.value).strip().lower())
        if attr:
            col_attr[cell.column] = attr

    if not col_attr:
        wb.close()
        raise ValueError(
            "None of this file's column headers match the expected Filato x "
            "Tinturia headers (Articolo, Titolo, Partita, Rocce, Peso, تحضير خام) "
            "— is this the right file?"
        )

    if ws.max_row > 1:
        ws.delete_rows(2, ws.max_row - 1)

    for row_offset, match in enumerate(matches):
        row_idx = 2 + row_offset
        for col_idx, attr in col_attr.items():
            ws.cell(row=row_idx, column=col_idx).value = getattr(match, attr, None)

    safe_save_workbook(wb, target_path, keep_backup=False)
    wb.close()
    return len(matches)


def export_ordini_full(target_path: Path, ordini_rows: list) -> int:
    """
    Write the "EXCEL PER ORDINE VENDITA EGITTO" workbook at *target_path*,
    formatted exactly like the master file (exporters/master_formats.py): header,
    fonts, column widths, a real date / number / text type per column, the Excel
    table and the duplicate highlighting.

    Always writes only THIS run's ordini_rows -- if *target_path* already
    exists (e.g. it's a shared path another client's Ordine Kamal/Ordine
    ELVY run also extracts into), its old content is cleared first so a new
    order's rows never end up mixed in with a previous, unrelated order's
    rows. If the file doesn't exist yet, it's created. Returns the number
    of rows written.
    """
    import openpyxl  # local import: this module doesn't need openpyxl otherwise
    from exporters.excel_exporter import ORDINI_ELVY_COLUMNS, apply_column_widths, freeze_and_filter, write_data, write_header
    from exporters.master_formats import apply_erp_master_format

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "ORDINE VENDITA EGITTO"
    ws.sheet_view.rightToLeft = False
    write_header(ws, ORDINI_ELVY_COLUMNS)
    write_data(ws, ORDINI_ELVY_COLUMNS, ordini_rows)
    if not apply_erp_master_format(ws):   # never expected: keep the generic styling rather than fail
        apply_column_widths(ws, ORDINI_ELVY_COLUMNS)
        freeze_and_filter(ws, ORDINI_ELVY_COLUMNS)

    target_path.parent.mkdir(parents=True, exist_ok=True)
    safe_save_workbook(wb, target_path, keep_backup=False)
    wb.close()
    return len(ordini_rows)


def export_filato_full(
    target_path: Path,
    matches: list["RawYarnMatch"],
) -> int:
    """
    Write the "Filato x Tinturia" workbook at *target_path*, formatted exactly like the
    master file (exporters/master_formats.py): the master's headers, a real number / text type
    per column, the Excel table, the duplicate highlighting and the four empty "complete from
    another raw yarn" columns.

    Always writes only THIS run's matches -- if *target_path* already
    exists (e.g. Ordine Kamal and Ordine ELVY are both pointed at the same
    shared Filato folder, or this same order is re-extracted), its old
    content is cleared first, so a previous order's raw-yarn rows never
    linger next to a new order's rows (the warehouse would otherwise see
    stale lots that were already pulled for an order days ago, mixed in
    with what's actually needed now). If the file doesn't exist yet, it's
    created. Returns the number of rows written.
    """
    import openpyxl  # local import: this module doesn't need openpyxl otherwise
    from exporters.master_formats import write_filato_master_sheet

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Filato x Tinturia"
    ws.sheet_view.rightToLeft = False
    write_filato_master_sheet(ws, matches)

    target_path.parent.mkdir(parents=True, exist_ok=True)
    safe_save_workbook(wb, target_path, keep_backup=False)
    wb.close()
    return len(matches)


@dataclass
class RawYarnMatch:
    """One row assigned for the "Filato x Tinturia" summary sheet."""
    articolo: str = ""
    titolo: str = ""
    partita: str = ""
    rocce: float = 0.0
    peso: float = 0.0
    label: str = "تحضير خام"


_WAITING_TOKEN_RE = re.compile(r"PG-X(?:\([^)]*\))?", re.IGNORECASE)


def with_partita(commento: str, partita: str) -> str:
    """Replace the waiting token of a Commento -- "PG-X" or "PG-X(<lot>)" -- by "PG-<partita>"."""
    return _WAITING_TOKEN_RE.sub(f"PG-{partita}", commento or "", count=1)


def match_by_lot(
    ordini_rows: list["OrdiniElvyRow"],
    magazino_summary: pd.DataFrame,
    lotti_summary: pd.DataFrame | None,
    codes_map: dict | None = None,
) -> list[RawYarnMatch]:
    """First step of the raw-yarn matching: search Magazino Filato by the customer's LOT.

    A row that is still waiting for raw yarn ("PG-X" in its Commento) and carries the
    lot written in its PDF takes the batch of the same raw article whose Lotto (from the
    Lotti file) is that lot and which is in stock -- "PG-X(<lot>)-PO-..." becomes
    "PG-<partita>-PO-...".  Rows without a lot, or whose lot is not in stock for their
    article, are left alone for the by-article step (match_raw_yarn) that follows.
    Returns the batches assigned, for the "Filato x Tinturia" sheet.
    """
    if (
        magazino_summary is None or magazino_summary.empty
        or lotti_summary is None or lotti_summary.empty
    ):
        return []

    partitas_by_lot: dict[str, list[str]] = {}
    for _, r in lotti_summary.iterrows():
        key = clean_text(r["lotto"]).casefold()
        if key:
            partitas_by_lot.setdefault(key, []).append(str(r["partita"]).strip())

    stock: dict[str, dict] = {}
    for _, r in magazino_summary.iterrows():
        stock[str(r["partita"]).strip()] = {
            "articolo": str(r["articolo"]).strip().upper(),
            "rocche": float(r["mag_rocche"]),
            "peso": float(r["mag_peso"]),
        }

    matches: list[RawYarnMatch] = []
    for row in ordini_rows:
        lot = clean_text(getattr(row, "lot", "")).casefold()      # Kamal rows have no lot
        if not lot or "PG-X" not in (row.commento or "").upper():
            continue
        articolo_g = raw_articolo_for(clean_text(row.articolo_delta).upper())
        candidates = [
            p for p in partitas_by_lot.get(lot, [])
            if p in stock and stock[p]["articolo"] == articolo_g and stock[p]["rocche"] > 0
        ]
        if not candidates:
            continue
        # The batch with the most stock left; stock already given to an earlier row is deducted.
        partita = max(candidates, key=lambda p: stock[p]["rocche"])
        batch = stock[partita]
        need = min(float(row.quantity_cones or 0), batch["rocche"])
        peso_used = batch["peso"] * (need / batch["rocche"]) if batch["rocche"] else 0.0
        batch["peso"] = max(batch["peso"] - peso_used, 0.0)
        batch["rocche"] = max(batch["rocche"] - need, 0.0)
        row.commento = with_partita(row.commento, partita)
        matches.append(RawYarnMatch(
            articolo=articolo_g,
            titolo=(codes_map or {}).get(finished_articolo_for(articolo_g), ""),
            partita=partita,
            rocce=round(need, 2),
            peso=round(peso_used, 2),
        ))
    return matches


def _stock_after(magazino_summary: pd.DataFrame, matches: list[RawYarnMatch]) -> pd.DataFrame:
    """A copy of the stock with what ``matches`` took removed (empty batches dropped)."""
    stock = magazino_summary.copy()
    stock["partita"] = stock["partita"].astype(str).str.strip()
    for match in matches:
        mask = stock["partita"] == str(match.partita).strip()
        stock.loc[mask, "mag_rocche"] = (stock.loc[mask, "mag_rocche"].astype(float) - float(match.rocce)).clip(lower=0)
        stock.loc[mask, "mag_peso"] = (stock.loc[mask, "mag_peso"].astype(float) - float(match.peso)).clip(lower=0)
    return stock[stock["mag_rocche"].astype(float) > 0]


def match_raw_yarn(
    ordini_rows: list["OrdiniElvyRow"],
    magazino_summary: pd.DataFrame,
    codes_map: dict | None = None,
    quantity_attr: str = "quantity_cones",
    lotti_summary: pd.DataFrame | None = None,
) -> list[RawYarnMatch]:
    """
    Fills in the Partita number in place of "X" in "PG-X-..." for rows
    that can be covered by available raw yarn, and returns the list of
    batches actually assigned (for the "Filato x Tinturia" export sheet).

    magazino_summary: output of magazino_logic.summarize_by_partita()
      (columns: articolo, partita, mag_rocche, mag_peso) -- articolo here
      is the raw (G-prefixed) code.
    codes_map: optional {articolo_filato: titolo} lookup (Articoli.xlsx),
      used only to fill in the Titolo column of the returned matches.
    quantity_attr: the OrdiniElvyRow attribute to use for requested raw-yarn
      quantity (default: quantity_cones). Kamal rows use peso_kg.

    Matching rule (as specified): group the order rows still needing raw
    yarn ("PG-X" in commento) by their G-code Articolo. For each group, if
    a single available batch covers the group's total quantity, assign that
    batch's Partita to every row in the group. Otherwise, try to cover
    each row individually with the smallest batch that fits it, leaving
    any row that can't be covered as "PG-X".
    """
    if magazino_summary is None or magazino_summary.empty:
        return []

    # Step 1 -- by the customer's lot (needs Lotti).  What it hands out is deducted from the
    # stock the by-article step below sees, so one batch is never given twice.
    lot_matches = match_by_lot(ordini_rows, magazino_summary, lotti_summary, codes_map)
    if lot_matches:
        magazino_summary = _stock_after(magazino_summary, lot_matches)
        if magazino_summary.empty:
            return lot_matches

    batch_capacity_attr = "rocche" if quantity_attr == "quantity_cones" else "peso"

    pool: dict[str, list[dict]] = {}
    for _, r in magazino_summary.iterrows():
        pool.setdefault(str(r["articolo"]), []).append(
            {"partita": str(r["partita"]), "rocche": float(r["mag_rocche"]), "peso": float(r["mag_peso"])}
        )

    groups: dict[str, list[int]] = {}
    for i, row in enumerate(ordini_rows):
        if "PG-X" not in (row.commento or ""):
            continue
        articolo_c = clean_text(row.articolo_delta).upper()
        if not articolo_c.startswith("C"):
            continue
        articolo_g = raw_articolo_for(articolo_c)
        if not articolo_g.startswith("G"):
            continue
        groups.setdefault(articolo_g, []).append(i)

    matches: list[RawYarnMatch] = []

    def _assign(idxs, batch, quantity_used, art_g):
        """Assign a raw-yarn batch to the order rows idxs: replace PG-X in their Commento by PG-<partita>, compute the weight and cones used from the batch (by cones or by weight, depending on batch_capacity_attr) and record a RawYarnMatch."""
        for i in idxs:
            ordini_rows[i].commento = with_partita(ordini_rows[i].commento, batch["partita"])
        articolo_c_for_lookup = finished_articolo_for(art_g)
        titolo = (codes_map or {}).get(articolo_c_for_lookup, "")
        if batch_capacity_attr == "rocche":
            peso_used = batch["peso"] * (quantity_used / batch["rocche"]) if batch["rocche"] else 0.0
            rocce_used = quantity_used
        else:
            peso_used = quantity_used
            rocce_used = batch["rocche"] * (quantity_used / batch["peso"]) if batch.get("peso") else 0.0
        matches.append(RawYarnMatch(
            articolo=art_g,
            titolo=titolo,
            partita=batch["partita"],
            rocce=round(rocce_used, 2),
            peso=round(peso_used, 2),
        ))

    for articolo_g, idxs in groups.items():
        batches = pool.get(articolo_g, [])
        if not batches:
            continue
        total_needed = sum(getattr(ordini_rows[i], quantity_attr, 0) or 0 for i in idxs)

        candidates = sorted(
            (b for b in batches if b.get(batch_capacity_attr, 0) >= total_needed),
            key=lambda b: b.get(batch_capacity_attr, 0),
        )
        if candidates:
            batch = candidates[0]
            _assign(idxs, batch, total_needed, articolo_g)
            batches.remove(batch)
            continue

        for i in idxs:
            row = ordini_rows[i]
            need = getattr(row, quantity_attr, 0) or 0
            fit = sorted(
                (b for b in batches if b.get(batch_capacity_attr, 0) >= need),
                key=lambda b: b.get(batch_capacity_attr, 0),
            )
            if fit:
                batch = fit[0]
                _assign([i], batch, need, articolo_g)
                batches.remove(batch)
            # else: leave as PG-X -- nothing in stock covers this row yet

    return lot_matches + matches
