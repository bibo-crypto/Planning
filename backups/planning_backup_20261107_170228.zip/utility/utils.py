"""
utils.py — Shared utilities, logging setup, and helper functions.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import re
import sys
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Writable data directory
# ---------------------------------------------------------------------------

def _migrate_legacy_dir(old_dir: Path, new_dir: Path) -> None:
    """Carry settings/logs/cache from a previous app-data folder name over."""
    try:
        if not old_dir.is_dir() or old_dir == new_dir:
            return
        if not new_dir.exists():
            old_dir.rename(new_dir)
            return
        for child in list(old_dir.iterdir()):
            target = new_dir / child.name
            if not target.exists():
                shutil.move(str(child), str(target))
        try:
            old_dir.rmdir()  # only succeeds when nothing is left
        except OSError:
            pass
    except OSError:
        pass


def _get_app_data_dir() -> Path:
    """
    Return a directory the app is guaranteed to be able to write to.

    When frozen (built with PyInstaller) and installed under a protected
    location such as ``C:\\Program Files\\...``, a standard (non-admin) user
    account cannot create files there — writing the log file raises
    ``PermissionError: [Errno 13]``. To avoid that, frozen builds write to
    the current user's per-user AppData folder instead, which is always
    writable regardless of where the app itself is installed.

    When running from source (not frozen), logs/settings stay in a local
    "logs"/"settings" folder next to this file, for easy access while
    developing.  Using the file location instead of the current working
    directory keeps the app stable when launched from a shortcut or another
    directory.
    """
    override = os.environ.get("PLANNING_DATA_DIR", "").strip()
    if override and not getattr(sys, "frozen", False):
        # Source checkouts only (the packaged EXE ignores it): the test-suite uses this so it never
        # reads or writes the real settings/data/cache.
        override_dir = Path(override)
        override_dir.mkdir(parents=True, exist_ok=True)
        return override_dir
    if getattr(sys, "frozen", False):
        base = os.environ.get("LOCALAPPDATA") or str(Path.home())
        new_dir = Path(base) / "Planning"
        # One-time migration from the app's earlier names: "Planing" (the
        # misspelt one) and, before that, "Delta Dyeing PO Converter".  The
        # old folder is renamed when the new one does not exist yet; when it
        # does (e.g. a startup-error log was written there first) only the
        # entries that are missing are moved over -- nothing is overwritten.
        for old_dir in (Path(base) / "Planing", Path(base) / "Delta Dyeing PO Converter"):
            _migrate_legacy_dir(old_dir, new_dir)
        return new_dir
    # utils.py lives one level under the project root now (utility/utils.py),
    # so go up one extra parent to keep dev-mode logs/settings/situazione in
    # the same repo-root location they were in before the folder reorg.
    return Path(__file__).resolve().parent.parent


APP_DATA_DIR = _get_app_data_dir()

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

LOG_DIR = APP_DATA_DIR / "logs"
LOG_FILE = LOG_DIR / "converter.log"


def setup_logging() -> logging.Logger:
    """Configure and return the application-wide logger."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("converter")
    logger.setLevel(logging.DEBUG)

    if logger.handlers:
        # Already configured (e.g., called a second time in tests)
        return logger

    formatter = logging.Formatter(
        "%(asctime)s  %(levelname)-8s  %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # File handler — always DEBUG
    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)

    # Console handler — INFO and above
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(formatter)

    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger


logger = setup_logging()


# ---------------------------------------------------------------------------
# Text / value helpers
# ---------------------------------------------------------------------------

def clean_text(value: Any) -> str:
    """Strip and normalise whitespace in a string-like value."""
    if value is None:
        return ""
    text = str(value).strip()
    # Collapse internal whitespace to single spaces
    return re.sub(r"\s+", " ", text)


def parse_number(value: Any) -> float | None:
    """
    Try to parse *value* as a float.
    Returns None when the value is not numeric rather than raising.

    A real number (int/float, e.g. a cell read from Excel) is already a number:
    only TEXT needs the separator guessing below.  Going through str() first
    turned 1.234 into 1234.0 (a lone "." before exactly three digits looks like
    a thousands separator in text).
    """
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        number = float(value)
        return None if number != number else number      # NaN -> None
    text = clean_text(value)
    if not text:
        return None

    # Accept both common formats: 1,234.56 and 1.234,56.  The last
    # separator is treated as the decimal separator when both are present;
    # a lone separator followed by exactly three digits is treated as a
    # thousands separator.
    text = re.sub(r"[^0-9+\-.,]", "", text)
    if "," in text and "." in text:
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")
        else:
            text = text.replace(",", "")
    elif "," in text:
        tail = text.rsplit(",", 1)[1]
        text = text.replace(",", "") if len(tail) == 3 else text.replace(",", ".")
    elif "." in text:
        tail = text.rsplit(".", 1)[1]
        if len(tail) == 3 and text.count(".") == 1:
            text = text.replace(".", "")
    try:
        return float(text)
    except (ValueError, TypeError):
        return None


def divide_pos(raw_pos: Any) -> int | None:
    """
    Convert a raw POS value (e.g. 10, 20, 30 …) to the display value
    by dividing by 10.  Returns None if the value cannot be parsed.
    """
    num = parse_number(raw_pos)
    if num is None:
        return None
    return int(round(num / 10))


def find_pdfs(path: Path) -> list[Path]:
    """
    Return a sorted list of PDF files found at *path*.
    *path* may be a single PDF file or a directory.
    """
    if path.is_file() and path.suffix.lower() == ".pdf":
        return [path]
    if path.is_dir():
        return sorted(path.glob("*.pdf"))
    return []


def make_output_path(pdf_path: Path, output_dir: Path) -> Path:
    """Derive the Excel output path for a given PDF input path."""
    return output_dir / (pdf_path.stem + ".xlsx")


# ---------------------------------------------------------------------------
# Article description splitting
# ---------------------------------------------------------------------------

# Matches: "<yarn> Nm <nm> Ne <ne> <dye type ...> Lot : <lot>"
# e.g. "100% Cotton Pima Blend Nm 170/2 Ne 100/2 Vat Griege Lot : 52_LOT 1251B.3"
RE_ARTICLE_DESCRIPTION = re.compile(
    r"^(?P<yarn>.*?)\s*"
    r"Nm\s*(?P<nm>\S+)\s*"
    r"Ne\s*(?P<ne>\S+)\s*"
    r"(?P<dye>.+?)\s*"
    r"Lot\b\s*:?\s*(?P<lot>.*)$",      # the lot may be empty: "... Vat Griege Lot :"
    re.IGNORECASE,
)

# Colour/state words that ride along next to the dye type (e.g. "Vat
# Griege") but aren't part of the dye type itself, so they're dropped.
ARTICLE_DYE_FILLER_WORDS = {"griege", "grey", "gray", "raw"}


def split_article_description(text: str) -> dict[str, str]:
    """
    Split a raw "Article Description" line into its component fields.

    Expected source pattern::

        <yarn composition> Nm <nm value> Ne <ne value> <dye type> [Griege] Lot : <lot>

    Example
    -------
    >>> split_article_description(
    ...     "100% Cotton Pima Blend Nm 170/2 Ne 100/2 Vat Griege Lot : 52_LOT 1251B.3"
    ... )
    {'yarn': '100% Cotton Pima Blend', 'nm': '170/2', 'ne': '100/2',
     'dye_type': 'Vat', 'lot': '52_LOT 1251B.3'}

    The text after "Lot :" is the lot; when nothing follows it the lot stays empty
    (the other fields are still read).

    If the text doesn't match the expected pattern (unexpected PDF layout,
    OCR noise, etc.), all fields come back empty so the caller can fall
    back to showing the original, unsplit text — nothing is guessed.
    """
    empty = {"yarn": "", "nm": "", "ne": "", "dye_type": "", "lot": ""}

    text = clean_text(text)
    if not text:
        return empty

    match = RE_ARTICLE_DESCRIPTION.match(text)
    if not match:
        return empty

    dye_words = [
        w for w in match.group("dye").split()
        if w.lower() not in ARTICLE_DYE_FILLER_WORDS
    ]
    dye_type = " ".join(dye_words) if dye_words else match.group("dye").strip()

    return {
        "yarn": match.group("yarn").strip(),
        "nm": match.group("nm").strip(),
        "ne": match.group("ne").strip(),
        "dye_type": dye_type,
        "lot": match.group("lot").strip(" :-"),     # nothing (or just punctuation) after "Lot :" = no lot
    }


# ---------------------------------------------------------------------------
# Persistent settings (simple JSON file next to the application)
# ---------------------------------------------------------------------------

SETTINGS_FILE = APP_DATA_DIR / "settings" / "prefs.json"

def load_settings() -> dict[str, object]:
    """
    Load persisted settings from ``settings/prefs.json``.
    Returns an empty mapping when no settings file exists yet.

    Paths and checkbox values are optional, so callers already handle missing
    keys safely with ``dict.get``.  Keeping this function free of obsolete
    feature defaults prevents settings for removed UI controls from growing
    back on every launch.
    """
    settings: dict[str, object] = {}
    try:
        if SETTINGS_FILE.is_file():
            on_disk = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            if isinstance(on_disk, dict):
                settings.update(on_disk)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not load settings: %s", exc)
    return settings


def save_settings(settings: dict[str, object]) -> None:
    """
    Persist *settings* to ``settings/prefs.json``.
    Creates the directory if needed; silently skips on error.
    """
    try:
        from utility.atomic import atomic_write_text
        atomic_write_text(SETTINGS_FILE, json.dumps(settings, indent=2, ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not save settings: %s", exc)


def keep_window_on_top(window) -> None:
    """Keep a Tk child window above the main application until it is closed."""
    try:
        window.attributes("-topmost", True)
        window.lift()
    except Exception:  # noqa: BLE001
        # Some non-Windows window managers do not support ``-topmost``.
        try:
            window.lift()
        except Exception as _ignored:
            logger.debug("utility.utils.keep_window_on_top: ignored %r", _ignored)


def bind_escape_to_close(window, close_command=None) -> None:
    """Make Escape close a Toplevel (dialog, ticket, report window...) the
    same as clicking its own Close/X button -- applied once, right after
    creating any such window, so every sub-window in the app gets this for
    free instead of each one needing its own binding.

    close_command defaults to window.destroy; pass the window's own
    close handler instead when it does more than just destroy (e.g.
    prompts to save, releases a lock) so Escape goes through the exact
    same path as its Close button, not a shortcut around it."""
    window.bind("<Escape>", lambda _event, cmd=close_command or window.destroy: cmd())


def lazy_call(module_path: str, function_name: str):
    """Return a callable that imports `module_path` on first use and then
    calls `function_name` from it, instead of importing it eagerly.

    Several tabs (Ordine Kamal, Ordine MED, ...) only need their heavy
    pipeline/exporter modules -- which transitively pull in pandas,
    openpyxl, pdfplumber -- once the user actually clicks Convert, not to
    draw the tab's widgets. Importing those eagerly at module load time
    means building the tab pays that cost during app startup instead of
    when the work is actually requested; wrapping each name with this
    (or LazyModule below, for `module.func()`-style access) defers it to
    first real use.
    """
    def call(*args, **kwargs):
        import importlib
        module = importlib.import_module(module_path)
        return getattr(module, function_name)(*args, **kwargs)
    return call


class LazyModule:
    """Attribute-access proxy that imports `module_path` on first attribute
    access and caches it -- for code that uses `module.func(...)` or a
    plain `module.CONSTANT` rather than importing individual names. See
    lazy_call() above for the reasoning."""
    def __init__(self, module_path: str):
        self._module_path = module_path
        self._module = None

    def __getattr__(self, name):
        if self._module is None:
            import importlib
            self._module = importlib.import_module(self._module_path)
        return getattr(self._module, name)
